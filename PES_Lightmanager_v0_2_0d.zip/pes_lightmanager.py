bl_info = {
    "name": "PES Lightmanager for PES 2020 / 2021",
    "blender": (2, 80, 0),
    "category": "Scene",
}

import bpy
import math
import os
import shutil
import re
import textwrap
import subprocess
import sys
import codecs
import xml.etree.ElementTree as ET
import bpy.utils.previews
import addon_utils
from pathlib import Path
from mathutils import Quaternion
from bpy_extras.io_utils import ImportHelper
from glob import glob
# Specify the package you want to install
package_name = "Pillow"

# Install the package using subprocess
try:
    # Path to the Python executable bundled with Blender
    blender_python_executable = bpy.app.binary_path_python
    subprocess.check_call([blender_python_executable, '-m', 'pip', 'install', package_name])
    print(f"Successfully installed {package_name}")
except subprocess.CalledProcessError as e:
    print(f"Failed to install {package_name}. Error: {e}")
except AttributeError:
    blender_python_executable = next((Path(sys.prefix)/"bin").glob("python*"))
    subprocess.check_call([blender_python_executable, '-m', 'pip', 'install', package_name])

# Now you can import the Pillow module
from PIL import Image

icons_collection = None

class SpotlightValuePropertyGroup(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    addr: bpy.props.StringProperty(name="HEX Address")
    transform: bpy.props.StringProperty(name="HEX Address (transform)")
    color: bpy.props.StringProperty(name="Color")
    lumen: bpy.props.FloatProperty(name="Power (lumen)")
    umbraAngle: bpy.props.FloatProperty(name="Size (umbraAngle)")
    penumbraAngle: bpy.props.FloatProperty(name="Penumbra Angle")
    temperature: bpy.props.FloatProperty(name="Temperature")
    transform_translation: bpy.props.StringProperty(name="Transform Translation")
    transform_rotation_quat: bpy.props.StringProperty(name="Transform Rotation Quaternion")
    enabled: bpy.props.StringProperty(name="Enabled?")
    isBounced: bpy.props.StringProperty(name="Bounce Light?")
    castShadow: bpy.props.StringProperty(name="Cast Shadow?")
    show_details: bpy.props.BoolProperty(name="Show Details", default=False)
    invalidLight: bpy.props.StringProperty(name="WARNING: This is an invalid light. Select all invalid lights and fix them inside Tools.")

class OBJECT_OT_my_operator(bpy.types.Operator):
    bl_idname = "object.my_operator"
    bl_label = "Select SpotLights for Export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Clear previous spotlight values
        context.scene.spotlight_values.clear()

        # Initialize counters
        selected_spotlights_amount = 0
        total_spotlights_amount = 0

        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object is a spotlight
            if obj.type == 'LIGHT' and obj.data.type == 'SPOT':
                total_spotlights_amount += 1

                # Check if the spotlight is selected
                if obj.select_get():
                    selected_spotlights_amount += 1

                    # Check if the custom properties exist on the object
                    if all(prop in obj for prop in ["addr", "enable", "castShadow", "isBounced", "transform"]):
                        # Access the custom property values
                        addr_value = obj["addr"]
                        enable_value = "true" if obj["enable"] == 1 else "false"
                        cast_shadow_value = "true" if obj["castShadow"] == 1 else "false"
                        is_bounced_value = "true" if obj["isBounced"] == 1 else "false"
                        temperature_value = obj["temperature"]
                        transform_value = obj["transform"]

                    # Get the RGB color values
                    color = obj.data.color
                    r_value, g_value, b_value = [round(channel, 5) for channel in color[:3]]
                    color_value = f'<value r=\"{r_value}\" g=\"{g_value}\" b=\"{b_value}\" a=\"1\" />'

                    # Get the Power (lumen)
                    lumen_value = obj.data.energy
                    lumen_value = lumen_value * 15

                    # Get the Size (umbraAngle) and Blend value from light data
                    light_data = obj.data
                    umbra_angle_value = round(math.degrees(light_data.spot_size))
                    blend_value = light_data.spot_blend
                    blend_value = round(1.0 - blend_value, 3)

                    # Calculate penumbraAngle
                    penumbra_angle_value = round(umbra_angle_value * blend_value)

                    # Extract translation and rotation components from the transform matrix
                    transform_translation = obj.matrix_world.translation
                    transform_rotation = obj.matrix_world.to_quaternion()

                    # Round the rotation components
                    transform_rotation_w = round(transform_rotation.w, 5)
                    transform_rotation_x = round(transform_rotation.x, 5)
                    transform_rotation_y = round(transform_rotation.y, 5)
                    transform_rotation_z = round(transform_rotation.z, 5)

                    # Round the translation components
                    transform_translation_x = round(transform_translation.x, 5)
                    transform_translation_y = round(transform_translation.y, 5)
                    transform_translation_z = round(transform_translation.z, 5)

                    # Switch X, Y, Z, W for rotation
                    transform_rotation_formatted = f'<value x="{transform_rotation_x}" y="{transform_rotation_z}" z="{-transform_rotation_y}" w="{transform_rotation_w}" />'

                    # Switch X, Y, Z for translation
                    transform_translation_formatted = f'<value x="{transform_translation_x}" y="{transform_translation_z}" z="{-transform_translation_y}" w="0" />'

                    # Print the values alongside the object name
                    print(f"Object: '{obj.name}'")
                    print(f"addr: 0x00{addr_value}, transform: 0x00{transform_value}, enable: {enable_value}, castShadow: {cast_shadow_value}, isBounced: {is_bounced_value}")
                    print(f"Color: <value r=\"{r_value}\" g=\"{g_value}\" b=\"{b_value}\" a=\"1\" />")
                    print(f"Power (lumen): {lumen_value}")
                    print(f"Size (umbraAngle): {umbra_angle_value}")
                    print(f"Penumbra Angle: {penumbra_angle_value}")
                    print(f"Temperature: {temperature_value}")
                    print(f"Transform Translation: {transform_translation_formatted}")
                    print(f"Transform Rotation Quaternion: {transform_rotation_formatted}")
                    print("---------------------------")

                    # Append individual values to the scene property list
                    spotlight_values_entry = context.scene.spotlight_values.add()
                    spotlight_values_entry.object_name = obj.name
                    spotlight_values_entry.addr = f'0x00{addr_value}'
                    spotlight_values_entry.transform = f'0x00{transform_value}'
                    spotlight_values_entry.transform_translation = transform_translation_formatted
                    spotlight_values_entry.transform_rotation_quat = transform_rotation_formatted
                    spotlight_values_entry.color = color_value
                    spotlight_values_entry.lumen = lumen_value
                    spotlight_values_entry.umbraAngle = umbra_angle_value
                    spotlight_values_entry.penumbraAngle = penumbra_angle_value
                    spotlight_values_entry.temperature = temperature_value
                    spotlight_values_entry.castShadow = cast_shadow_value
                    spotlight_values_entry.isBounced = is_bounced_value
                    spotlight_values_entry.enabled = enable_value
                else:
                    # Print a message if any of the custom properties are missing
                    print(f"Custom properties are missing on object '{obj.name}'.")
            else:
                # Print a message if the object is not a spotlight
                print(f"Object '{obj.name}' is not a spotlight.")
        
        # Get the selected objects in the active scene
        selected_objects = bpy.context.selected_objects

        # Check if all selected objects are Light objects
        all_lights = all(obj.type == 'LIGHT' for obj in selected_objects)

        if all_lights:
            selected_objects_count = len(selected_objects)
            
            if selected_objects_count == 1:
                self.report({'INFO'}, f"{selected_objects_count} Spotlight selected.")
            elif selected_objects_count > 1:
                self.report({'INFO'}, f"{selected_objects_count} Spotlights selected.")
            else:
                self.report({'INFO'}, "No Spotlights selected.")
        else:
            self.report({'ERROR'}, "Not all selected objects are lights. Please select only light objects.")
        
        bpy.types.Scene.selected_spotlights_amount = bpy.props.IntProperty()
        bpy.types.Scene.total_spotlights_amount = bpy.props.IntProperty()
        
        # Update the scene properties
        context.scene.selected_spotlights_amount = selected_spotlights_amount
        context.scene.total_spotlights_amount = total_spotlights_amount

        return {'FINISHED'}
        
# Function to run GzsTool.exe with the exported XML file path
def run_gzs_tool(xml_file_path):
    # Get the directory of the uploaded XML file
    xml_file_directory = os.path.dirname(xml_file_path)

    # Go back 7 directories from the XML file directory
    parent_directory = os.path.abspath(os.path.join(xml_file_directory, "..\\..\\..\\..\\..\\..\\.."))

    # Find all files ending with ".fpkd.xml" in the specified directory
    fpkd_files = glob(os.path.join(parent_directory, "*.fpkd.xml"))

    # Run GzsTool.exe with each found .fpkd.xml file
    gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")
    
    if os.path.exists(gzs_tool_path):
        for fpkd_file in fpkd_files:
            command2 = [gzs_tool_path, fpkd_file]
            subprocess.run(command2, check=True)
            print(f"GzsTool.exe executed for file: {fpkd_file}")
    else:
        print("GzsTool.exe not found. Make sure the path is correct.")

class OBJECT_OT_upload_xml(bpy.types.Operator, ImportHelper):
    bl_idname = "object.upload_xml"
    bl_label = "Upload .fpkd or .xml"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".xml; .fpkd"

    def execute(self, context):
        file_ext = os.path.splitext(self.filepath)[1].lower()

        if file_ext == '.xml':
            # Set the uploaded XML file name to a custom property
            context.scene.uploaded_xml_name = os.path.basename(self.filepath)

            # Set the directory property to the directory of the uploaded file
            context.scene.uploaded_xml_directory = os.path.dirname(self.filepath)

            self.report({'INFO'}, f"Uploaded XML: {self.filepath}")
        elif file_ext == '.fpkd':
            # Set the uploaded FPKD file name to a custom property
            context.scene.uploaded_fpkd_name = os.path.basename(self.filepath)

            # Set the directory property to the directory of the uploaded file
            context.scene.uploaded_fpkd_directory = os.path.dirname(self.filepath)

            # Extract using GzsTool.exe
            gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")
            if os.path.exists(gzs_tool_path):
                # Run GzsTool.exe to extract the .fpkd file
                command = [gzs_tool_path, self.filepath]
                subprocess.run(command, check=True)
                self.report({'INFO'}, f"Extracted FPKD: {self.filepath}")

                # Get the directory where the FPKD was extracted
                extracted_folder = os.path.join(context.scene.uploaded_fpkd_directory, f"{context.scene.uploaded_fpkd_name.replace('.fpkd', '_fpkd')}")

                # Navigate to the 'Assets/pes16/model/bg' folder inside the extracted folder
                model_folder = os.path.join(extracted_folder, "Assets", "pes16", "model", "bg")

                # Find all subdirectories in the 'bg' folder
                subdirectories = [d for d in os.listdir(model_folder) if os.path.isdir(os.path.join(model_folder, d))]

                if subdirectories:
                    # Assuming there's only one subdirectory, navigate to it
                    subdirectory = subdirectories[0]
                    subdirectory_path = os.path.join(model_folder, subdirectory)

                    # Navigate to the 'light' folder inside the subdirectory
                    light_folder = os.path.join(subdirectory_path, "light")

                    # Find all .fox2 files in the 'light' folder
                    fox2_files = [f for f in os.listdir(light_folder) if f.lower().endswith('.fox2')]

                    if len(fox2_files) == 1:
                        # Run FoxTool.exe to convert .fox2 to .xml
                        fox_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "FoxTool", "FoxTool.exe")
                        if os.path.exists(fox_tool_path):
                            fox2_file_path = os.path.join(light_folder, fox2_files[0])
                            command = [fox_tool_path, fox2_file_path]
                            subprocess.run(command, check=True)

                            # Set the uploaded XML file name and directory
                            # Set the uploaded XML file name by appending ".xml" to the found .fox2 file name
                            context.scene.uploaded_xml_name = os.path.splitext(fox2_files[0])[0] + ".fox2.xml"

                            # Set the directory property to the directory where the .fox2 file is located
                            context.scene.uploaded_xml_directory = light_folder

                            self.report({'INFO'}, f"Converted to XML: {fox2_file_path}")
                        else:
                            self.report({'ERROR'}, "FoxTool.exe not found. Make sure the path is correct.")
                    else:
                        self.report({'ERROR'}, "Expected exactly one .fox2 file in the 'light' folder.")
                else:
                    self.report({'ERROR'}, "No subdirectories found in 'model/bg'.")
            else:
                self.report({'ERROR'}, "GzsTool.exe not found. Make sure the path is correct.")

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
        
class OBJECT_OT_save_xml(bpy.types.Operator):
    bl_idname = "object.save_xml"
    bl_label = "Export Lights"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Enable the button only when there is an uploaded XML file
        return getattr(context.scene, 'uploaded_xml_name', None) is not None

    def execute(self, context):
    
        # Check if there is an uploaded XML
        if getattr(context.scene, 'uploaded_xml_name', None):
            # Construct the full file path
            file_path = os.path.join(context.scene.uploaded_xml_directory, context.scene.uploaded_xml_name)

            # Load the XML content
            with open(file_path, 'r') as file:
                xml_content = file.readlines()

            # Check if the XML already contains the specified key
            if any('key="EXT_Light_' in line for line in xml_content):
                self.report({'ERROR'}, "This file already has converted lights. Please click on revert and try exporting again.")
                return {'CANCELLED'}
                
            xml_file_name = context.scene.uploaded_xml_name  # Replace with the actual XML file name
            xml_file_path = os.path.join(context.scene.uploaded_xml_directory, xml_file_name)

            # Create a backup before editing
            self.create_backup(context, xml_file_path)

            # Find the line number where the "dataList" property starts
            try:
                start_data_list = next(i for i, line in enumerate(xml_content) if '<property name="dataList"' in line) + 1
            except StopIteration:
                self.report({'ERROR'}, "Could not find the specified line in the XML file. (IN DATALIST)")
                return {'CANCELLED'}

            # Find the line number where the "dataList" property ends
            try:
                end_data_list = xml_content.index('        </property>\n', start_data_list)
            except ValueError:
                self.report({'ERROR'}, "Could not find the specified line in the XML file.")
                return {'CANCELLED'}

            # Insert the initial line before the "dataList" property
            xml_content.insert(start_data_list, '          <value key="ExtraLights">0x00100000</value>\n')

            # Iterate through all spotlights in the scene
            for obj in bpy.context.scene.objects:
                # Check if the object is a spotlight with a name starting with "EXT_Light_"
                if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_"):
                    # Get the object name and address
                    object_name = obj.name
                    address = f'0x00{obj["addr"]}' if "addr" in obj else "UNKNOWN"

                    # Insert new lines after the last occurrence for each spotlight within "dataList" property
                    xml_content.insert(end_data_list, f'          <value key="{object_name}">{address}</value>\n')

            # Find the line number where "</fox>" starts
            start_fox = None
            for i, line in enumerate(xml_content):
                if line.strip().startswith('</fox>'):
                    start_fox = i
                    break

            if start_fox is None:
                # Print lines for debugging
                print("XML Content:")
                for i, line in enumerate(xml_content):
                    print(f"{i}: {line}")

                print("Could not find the specified line in the XML file. (FOX2-START)")
                self.report({'ERROR'}, "Could not find the specified line in the XML file. (FOX2-START)")
                return {'CANCELLED'}

            # Find the line number where "</fox>" ends
            end_fox = None
            for i, line in reversed(list(enumerate(xml_content))):
                if line.strip().startswith('</fox>'):
                    end_fox = i
                    break

            if end_fox is None:
                print("Could not find the specified line in the XML file. (FOX2-END)")
                self.report({'ERROR'}, "Could not find the specified line in the XML file. (FOX2-END)")
                return {'CANCELLED'}

            # Get the addresses of the spotlights
            spotlight_addresses = [f'0x00{obj["addr"]}' if "addr" in obj else "UNKNOWN" for obj in bpy.context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_")]

            # Insert the Locator Entity code two lines before "</fox>"
            xml_content.insert(end_fox - 1, '    <entity class="Locator" classVersion="0" addr="0x00100000" unknown1="320" unknown2="0">\n')
            xml_content.insert(end_fox, '      <staticProperties>\n')
            xml_content.insert(end_fox + 1, '        <property name="name" type="String" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 2, '          <value>ExtraLights</value>\n')
            xml_content.insert(end_fox + 3, '        </property>\n')
            xml_content.insert(end_fox + 4, '        <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 5, '          <value>0x00000100</value>\n')
            xml_content.insert(end_fox + 6, '        </property>\n')
            xml_content.insert(end_fox + 7, '        <property name="parent" type="EntityHandle" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 8, '          <value>0x00000000</value>\n')
            xml_content.insert(end_fox + 9, '        </property>\n')
            xml_content.insert(end_fox + 10, '        <property name="transform" type="EntityPtr" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 11, f'          <value>0x00100001</value>\n')
            xml_content.insert(end_fox + 12, '        </property>\n')
            xml_content.insert(end_fox + 13, '        <property name="shearTransform" type="EntityPtr" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 14, '          <value>0x00000000</value>\n')
            xml_content.insert(end_fox + 15, '        </property>\n')
            xml_content.insert(end_fox + 16, '        <property name="pivotTransform" type="EntityPtr" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 17, '''          <value>0x00000000</value>
        </property>\n''')
            xml_content.insert(end_fox + 18, f'        <property name="children" type="EntityHandle" container="List" arraySize="{len(spotlight_addresses) + 1}">\n')
            xml_content.insert(end_fox + 20, '        </property>\n')
            xml_content.insert(end_fox + 21, '        <property name="flags" type="uint32" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 22, '          <value>6</value>\n')
            xml_content.insert(end_fox + 23, '        </property>\n')
            xml_content.insert(end_fox + 24, '        <property name="size" type="float" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 25, '          <value>1</value>\n')
            xml_content.insert(end_fox + 26, '        </property>\n')
            xml_content.insert(end_fox + 27, '      </staticProperties>\n')
            xml_content.insert(end_fox + 28, '      <dynamicProperties />\n')
            xml_content.insert(end_fox + 29, '    </entity>\n')
            xml_content.insert(end_fox + 30, '    <entity class="TransformEntity" classVersion="0" addr="0x00100001" unknown1="96" unknown2="0">\n')
            xml_content.insert(end_fox + 31, '      <staticProperties>\n')
            xml_content.insert(end_fox + 32, '        <property name="owner" type="EntityHandle" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 33, '          <value>0x00100000</value>\n')
            xml_content.insert(end_fox + 34, '        </property>\n')
            xml_content.insert(end_fox + 35, '        <property name="transform_scale" type="Vector3" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 36, '          <value x="1" y="1" z="1" w="0" />\n')
            xml_content.insert(end_fox + 37, '        </property>\n')
            xml_content.insert(end_fox + 38, '        <property name="transform_rotation_quat" type="Quat" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 39, '          <value x="0" y="0" z="0" w="1" />\n')
            xml_content.insert(end_fox + 40, '        </property>\n')
            xml_content.insert(end_fox + 41, '        <property name="transform_translation" type="Vector3" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 42, '          <value x="0" y="0" z="0" w="0" />\n')
            xml_content.insert(end_fox + 43, '        </property>\n')
            xml_content.insert(end_fox + 44, '      </staticProperties>\n')
            xml_content.insert(end_fox + 45, '      <dynamicProperties />\n')
            xml_content.insert(end_fox + 46, '    </entity>\n')

            # Find the line number where the last </entity> ends
            try:
                end_entity = next(i for i, line in enumerate(reversed(xml_content)) if '</entity>' in line)
            except StopIteration:
                print("Could not find the specified line in the XML file.")
                self.report({'ERROR'}, "Could not find the specified line in the XML file.")
                return {'CANCELLED'}

            # Get the addresses of the spotlights
            spotlight_addresses = [f'0x00{obj["addr"]}' if "addr" in obj else "UNKNOWN" for obj in bpy.context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_")]

            # Remove the unwanted </entities> line
            xml_content.pop(end_fox + 19)

            # Insert the children values with correct indentation
            indentation = ' ' * 10  # Adjust the number of spaces based on your XML structure
            for address in spotlight_addresses:
                xml_content.insert(end_fox + 19, f'{indentation}<value>{address}</value>\n')
                
            # Count the SpotLights with the name "EXT_Light_"
            spotlight_amount = sum(1 for obj in bpy.context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_"))
            
            # Find the line number where the Locator Entity code ends
            end_locator_entity = start_fox + 47 + spotlight_amount # Assuming the Locator Entity code has 32 lines
            
            # Set the updated indentation to 4 spaces
            indentation = ' ' * 4
            print(f"Total: '{bpy.context.scene.spotlight_values}'.")
            
            # Find and remove </entities> and </fox> at the end of the XML document
            entities_index = None
            fox_index = None

            for i, line in enumerate(reversed(xml_content)):
                if '</entities>' in line:
                    entities_index = len(xml_content) - i - 1
                elif '</fox>' in line:
                    fox_index = len(xml_content) - i - 1

            # Remove </entities> and </fox> lines if found
            if entities_index is not None:
                del xml_content[entities_index]
            if fox_index is not None:
                del xml_content[fox_index]
            
            # Iterate through each spotlight value and insert the corresponding XML code
            for values in bpy.context.scene.spotlight_values:
                # XML code for SpotLight entity
                spot_light_xml = f'''{indentation}<entity class="SpotLight" classVersion="16" addr="{values.addr}" unknown1="560" unknown2="0">
{indentation}  <staticProperties>
{indentation}    <property name="name" type="String" container="StaticArray" arraySize="1">
{indentation}      <value>{values.object_name}</value>
{indentation}    </property>
{indentation}    <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">
{indentation}      <value>0x00000100</value>
{indentation}    </property>
{indentation}    <property name="parent" type="EntityHandle" container="StaticArray" arraySize="1">
{indentation}      <value>0x00100000</value>
{indentation}    </property>
{indentation}    <property name="transform" type="EntityPtr" container="StaticArray" arraySize="1">
{indentation}      <value>{values.transform}</value>
{indentation}    </property>
{indentation}    <property name="shearTransform" type="EntityPtr" container="StaticArray" arraySize="1">
{indentation}      <value>0x00000000</value>
{indentation}    </property>
{indentation}    <property name="pivotTransform" type="EntityPtr" container="StaticArray" arraySize="1">
{indentation}      <value>0x00000000</value>
{indentation}    </property>
{indentation}    <property name="children" type="EntityHandle" container="List" />
{indentation}    <property name="flags" type="uint32" container="StaticArray" arraySize="1">
{indentation}      <value>6</value>
{indentation}    </property>
{indentation}    <property name="lightArea" type="EntityLink" container="StaticArray" arraySize="1">
{indentation}      <value packagePathHash="0xB8A0BF169F98" archivePathHash="0xB8A0BF169F98" nameInArchiveHash="0xB8A0BF169F98">0x00000000</value>
{indentation}    </property>
{indentation}    <property name="enable" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>{values.enabled}</value>
{indentation}    </property>
{indentation}    <property name="lookAtPoint" type="EntityLink" container="StaticArray" arraySize="1">
{indentation}      <value packagePathHash="0xB8A0BF169F98" archivePathHash="0xB8A0BF169F98" nameInArchiveHash="0xB8A0BF169F98">0x00000000</value>
{indentation}    </property>
{indentation}    <property name="reachPoint" type="Vector3" container="StaticArray" arraySize="1">
{indentation}      <value x="0" y="-5" z="0" w="0" />
{indentation}    </property>
{indentation}    <property name="innerRange" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>5</value>
{indentation}    </property>
{indentation}    <property name="outerRange" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>70</value>
{indentation}    </property>
{indentation}    <property name="color" type="Color" container="StaticArray" arraySize="1">
          {values.color}
{indentation}    </property>
{indentation}    <property name="temperature" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.temperature}</value>
{indentation}    </property>
{indentation}    <property name="colorDeflection" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0.01</value>
{indentation}    </property>
{indentation}    <property name="lumen" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.lumen}</value>
{indentation}    </property>
{indentation}    <property name="lightSize" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>20</value>
{indentation}    </property>
{indentation}    <property name="umbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.umbraAngle}</value>
{indentation}    </property>
{indentation}    <property name="penumbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.penumbraAngle}</value>
{indentation}    </property>
{indentation}    <property name="attenuationExponent" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>1.2</value>
{indentation}    </property>
{indentation}    <property name="shadowUmbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>120</value>
{indentation}    </property>
{indentation}    <property name="shadowPenumbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>120</value>
{indentation}    </property>
{indentation}    <property name="shadowAttenuationExponent" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>1.2</value>
{indentation}    </property>
{indentation}    <property name="dimmer" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="shadowBias" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="viewBias" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>-25</value>
{indentation}    </property>
{indentation}    <property name="powerScale" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>4</value>
{indentation}    </property>
{indentation}    <property name="LodFarSize" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="LodNearSize" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="LodShadowDrawRate" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>1</value>
{indentation}    </property>
{indentation}    <property name="lodRadiusLevel" type="int32" container="StaticArray" arraySize="1">
{indentation}      <value>7</value>
{indentation}    </property>
{indentation}    <property name="lodFadeType" type="uint8" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="castShadow" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>{values.castShadow}</value>
{indentation}    </property>
{indentation}    <property name="isBounced" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>{values.isBounced}</value>
{indentation}    </property>
{indentation}    <property name="showObject" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>true</value>
{indentation}    </property>
{indentation}    <property name="showRange" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>true</value>
{indentation}    </property>
{indentation}    <property name="isDebugLightVolumeBound" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>false</value>
{indentation}    </property>
{indentation}    <property name="useAutoDimmer" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>false</value>
{indentation}    </property>
{indentation}    <property name="hasSpecular" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>false</value>
{indentation}    </property>
{indentation}  </staticProperties>
{indentation}  <dynamicProperties />
{indentation}</entity>
{indentation}<entity class="TransformEntity" classVersion="0" addr="{values.transform}" unknown1="96" unknown2="0">
{indentation}  <staticProperties>
{indentation}    <property name="owner" type="EntityHandle" container="StaticArray" arraySize="1">
{indentation}      <value>{values.addr}</value>
{indentation}    </property>
{indentation}    <property name="transform_scale" type="Vector3" container="StaticArray" arraySize="1">
{indentation}      <value x="1" y="1" z="1" w="0" />
{indentation}    </property>
{indentation}    <property name="transform_rotation_quat" type="Quat" container="StaticArray" arraySize="1">
          {values.transform_rotation_quat}
{indentation}    </property>
{indentation}    <property name="transform_translation" type="Vector3" container="StaticArray" arraySize="1">
          {values.transform_translation}
{indentation}    </property>
{indentation}  </staticProperties>
{indentation}  <dynamicProperties />
{indentation}</entity>
'''

                # Insert the spotlight XML code right after the Locator Entity
                xml_content.insert(end_locator_entity, spot_light_xml)
                
                # Update the end_locator_entity position for the next iteration
                end_locator_entity += 36  # Assuming the spotlight XML code has 36 lines
                
            # Append </entities> and </fox> back at the very end of the script
            xml_content.append('  </entities>\n')
            xml_content.append('</fox>')

            # Write the modified content back to the file
            with open(file_path, 'w') as file:
                file.writelines(xml_content)

            # Run FoxTool.exe with the exported XML file
            fox_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "FoxTool", "FoxTool.exe")
            if os.path.exists(fox_tool_path):
                xml_file_path = bpy.path.abspath(file_path)
                command = [
                    fox_tool_path,
                    xml_file_path
                ]

                subprocess.run(command, check=True)
                self.report({'INFO'}, f"Saved XML: {xml_file_name}, Converted to FPKD (Ready to use ingame)")
                # Run GzsTool.exe with the exported XML file path
                run_gzs_tool(xml_file_path)
            else:
                self.report({'ERROR'}, "FoxTool.exe not found. Make sure the path is correct.")

        return {'FINISHED'}
        
    def create_backup(self, context, xml_file_path):
    
        xml_file_name = context.scene.uploaded_xml_name  # Replace with the actual XML file name
        xml_file_path = os.path.join(context.scene.uploaded_xml_directory, xml_file_name)
    
        backup_path = bpy.path.abspath(os.path.join(context.scene.uploaded_xml_directory, "backup"))
        print(f"Saving Backup at: {backup_path}")
        os.makedirs(backup_path, exist_ok=True)

        # Backup the XML file
        shutil.copy(xml_file_path, os.path.join(backup_path, f"{xml_file_name}_backup.xml"))
        print("Backup created successfully.")
        
class OBJECT_OT_RevertXMLOperator(bpy.types.Operator):
    bl_idname = "object.revert_xml_operator"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}  # Include in toolbar and make it square

    def execute(self, context):
        # Get the path to the XML file
        xml_file_name = context.scene.uploaded_xml_name  # Replace with the actual XML file name
        xml_file_path = os.path.join(context.scene.uploaded_xml_directory, xml_file_name)

        # Get the path to the backup XML file
        backup_path = bpy.path.abspath(os.path.join(context.scene.uploaded_xml_directory, "backup"))
        backup_file_path = os.path.join(backup_path, f"{xml_file_name}_backup.xml")

        # Revert the XML file from the backup
        shutil.copy(backup_file_path, xml_file_path)
        
        self.report({'INFO'}, f"Revert successful: {xml_file_name}")

        return {'FINISHED'}
        
    def draw(self, context):
        layout = self.layout
        layout.operator("object.revert_xml_operator", icon='FILE_REFRESH')

class OBJECT_OT_CustomImageOperator(bpy.types.Operator):
    bl_idname = "object.custom_image_operator"
    bl_label = "Custom Image Operator"
    
    def execute(self, context):
        # This function is called when the operator is executed
        return {'FINISHED'}

    def draw(self, context):
        # This function is responsible for drawing the UI elements for the operator
        layout = self.layout
        custom_icon = icons_collection.get("titleimg")

        if custom_icon:
            layout.image(custom_icon.icon_id, icon_value=custom_icon.icon_id, size=(400, 200))  # Adjust size as needed
        else:
            layout.label(text="Icon not found")
            
class OBJECT_OT_OpenToolsOperator(bpy.types.Operator):
    bl_idname = "object.open_tools"
    bl_label = ""
    bl_options = {'INTERNAL'}
    
    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Select Tool:")
        # Add buttons for selecting functions
        layout.operator("object.function1_operator")
        layout.operator("object.function2_operator")
        layout.operator("object.function3_operator")

        # Add a gap
        layout.separator()

        # Add the "Add Objects" button
        layout.operator("object.function4_operator")

class MySceneProperties(bpy.types.PropertyGroup):
    temperature_checked: bpy.props.BoolProperty(name="Temperature Checked", default=False)
    castShadow_checked: bpy.props.BoolProperty(name="castShadow Checked", default=False)
    isBounced_checked: bpy.props.BoolProperty(name="isBounced Checked", default=False)
    enable_checked: bpy.props.BoolProperty(name="enable Checked", default=False)
    power_checked: bpy.props.BoolProperty(name="power Checked", default=False)
    new_spotlight_umbraAngle_checked: bpy.props.BoolProperty(name="new_spotlight_umbraAngle Checked", default=False)
    new_spotlight_penumbraAngle_checked: bpy.props.BoolProperty(name="new_spotlight_penumbraAngle Checked", default=False)
    spotlight_color_checked: bpy.props.BoolProperty(name="spotlight_color Checked", default=False)
    add_spotlight_rotation_checked: bpy.props.BoolProperty(name="add_spotlight_rotation Checked", default=False)

class OBJECT_OT_Function1Operator(bpy.types.Operator):
    bl_idname = "object.function1_operator"
    bl_label = "Bulk Edit SpotLights"

    def execute(self, context):
        # Replace with your actual function logic for function1
        self.report({'INFO'}, "Applying data to selected SpotLights")

        # Invoke the operator to apply properties to selected SpotLights
        bpy.ops.object.apply_properties_to_selected()

        return {'FINISHED'}

    def invoke(self, context, event):
        # Open a new popup for function1
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

        # You should have a return statement here, for example:
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        # Add UI elements for function1
        layout.label(text="")
        layout.operator("object.function1_execute_operator", text="")

        # Additional properties for the new SpotLight
        self.custom_prop(layout, context.scene, "temperature", "Temperature", "temperature_checked")
        self.custom_prop(layout, context.scene, "castShadow", "Cast Shadow", "castShadow_checked")
        self.custom_prop(layout, context.scene, "isBounced", "Bounce Lights", "isBounced_checked")
        self.custom_prop(layout, context.scene, "enable", "Enabled", "enable_checked")
        self.custom_prop(layout, context.scene, "power", "Power", "power_checked")
        self.custom_prop(layout, context.scene, "new_spotlight_umbraAngle", "Umbra Angle", "new_spotlight_umbraAngle_checked")
        self.custom_prop(layout, context.scene, "new_spotlight_penumbraAngle", "Penumbra Angle", "new_spotlight_penumbraAngle_checked")

        # Color property
        self.custom_prop(layout, context.scene, "spotlight_color", "Color", "spotlight_color_checked")

        # Separator
        layout.separator()

        # Text label for rotation
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", "Rotation:", "add_spotlight_rotation_checked")

    def custom_prop(self, layout, scene, prop_name, label, checked_prop_name):
        row = layout.row()
        row.prop(scene.my_properties, checked_prop_name, text="", icon='CHECKBOX_HLT' if getattr(scene.my_properties, checked_prop_name) else 'CHECKBOX_DEHLT', emboss=False)
        row.prop(scene, prop_name, text=label)

class OBJECT_OT_Function1ExecuteOperator(bpy.types.Operator):
    bl_idname = "object.function1_execute_operator"
    bl_label = "Execute Function 1"

    def invoke(self, context, event):
        # Replace with your actual function logic for function1
        self.report({'INFO'}, "Executing Function 1")

        # Invoke the operator to apply properties to selected SpotLights
        bpy.ops.object.apply_properties_to_selected('INVOKE_DEFAULT')

        return {'FINISHED'}

class OBJECT_OT_Function2Operator(bpy.types.Operator):
    bl_idname = "object.function2_operator"
    bl_label = "Mirror SpotLights"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):

        # Open a new popup for function2
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        # Add UI elements for function2
        layout.operator("object.function2_execute_operator", text="Mirror SpotLights")
        layout.prop(context.window_manager, "mirror_x", text="Mirror X")
        layout.prop(context.window_manager, "mirror_y", text="Mirror Y")

class WindowManager(bpy.types.WindowManager):
    mirror_x: bpy.props.BoolProperty(name="Mirror X", default=False)
    mirror_y: bpy.props.BoolProperty(name="Mirror Y", default=False)

class OBJECT_OT_Function2ExecuteOperator(bpy.types.Operator):
    bl_idname = "object.function2_execute_operator"
    bl_label = "Mirror SpotLights"

    def execute(self, context):
        mirror_x = getattr(context.window_manager, "mirror_x", False)
        mirror_y = getattr(context.window_manager, "mirror_y", False)

        selected_spotlights = [obj for obj in bpy.context.selected_objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT']

        if not selected_spotlights:
            self.report({'ERROR'}, "No spotlights selected.")
            return {'CANCELLED'}

        # Ensure that the selected spotlights have names starting with "EXT_Light_"
        selected_spotlights = [spotlight for spotlight in selected_spotlights if spotlight.name.startswith("EXT_Light_")]

        # Find the next available SpotID
        existing_spot_ids = {int(spotlight.name.split("_")[-1]) for spotlight in selected_spotlights}
        next_spot_id = 0

        while next_spot_id in existing_spot_ids:
            next_spot_id += 1
            if next_spot_id > 999:
                self.report({'ERROR'}, "SpotLight limit (1000) reached.")
                return {'CANCELLED'}

        # Iterate over selected spotlights
        if mirror_x and mirror_y:
            self.report({'INFO'}, "Only select one Axis to mirror at a time")
            return {'FINISHED'}
        if not mirror_x and not mirror_y:
            self.report({'INFO'}, "No changes made.")
        else:
            for spotlight in selected_spotlights:
                original_location = spotlight.location.copy()
                original_rotation = spotlight.rotation_quaternion.copy()

                # Ensure spot_light["addr"] is present and add 200
                addr = spotlight.get("addr", 0)
                addr = f"200{next_spot_id:03}"

                # Ensure spot_light["transform"] is present and add 200
                transform = spotlight.get("transform", 0)
                transform = f"201{next_spot_id:03}"

                # Create a copy of the spotlight
                new_spotlight = spotlight.copy()
                new_spotlight.data = spotlight.data.copy()
                bpy.context.collection.objects.link(new_spotlight)

                # Update the name of the new spotlight with the next SpotID
                new_spotlight.name = f"EXT_Light_{next_spot_id:03}"

                # Set custom properties for the new spotlight
                new_spotlight["addr"] = addr
                new_spotlight["castShadow"] = spotlight.get("castShadow")
                new_spotlight["enable"] = spotlight.get("enable")
                new_spotlight["isBounced"] = spotlight.get("isBounced")
                new_spotlight["temperature"] = spotlight.get("temperature")
                new_spotlight["transform"] = transform

                # Increment next_spot_id for the next spotlight
                next_spot_id += 1

                # Apply Position and Rotation
                if mirror_x and not mirror_y:
                    spotlight.location.x = -original_location.x
                    spotlight.rotation_quaternion.x = -original_rotation.x
                    spotlight.rotation_quaternion.w = -original_rotation.w
                    self.report({'INFO'}, "Mirroring SpotLights - On the X Axis")
                if mirror_y and not mirror_x:
                    spotlight.location.y = -original_location.y
                    spotlight.rotation_quaternion.y = -original_rotation.y
                    spotlight.rotation_quaternion.w = -original_rotation.w
                    self.report({'INFO'}, "Mirroring SpotLights - On the Y Axis")
                # Check and handle dot in the light name
                match = re.match(r'(.*)\.(\d+)$', spotlight.name)
                if match:
                    base_name, index = match.groups()
                    new_index = int(index) + 1
                    new_name = f"{base_name}.{new_index:03}"
                    spotlight.name = new_name
            
        return {'FINISHED'}

class OBJECT_OT_Function3Operator(bpy.types.Operator):
    bl_idname = "object.function3_operator"
    bl_label = "Fix SpotLights"
    
    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        # Open a new popup for function3
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        # Your original text
        original_text = "Use this tool on SpotLights which have not been imported using the (Add SpotLight) button."

        # Set the desired width for wrapping
        width = 55  # Adjust this based on your layout width

        # Wrap the text
        wrapped_text = textwrap.fill(original_text, width=width)

        # Create the layout with the wrapped text
        box = layout.box()
        for line in wrapped_text.split('\n'):
            row = box.row(align=True)
            row.alignment = 'EXPAND'
            row.label(text=line)
            # Reduce spacing between rows
            row.scale_y = 0.6  # Adjust this value to your liking
        layout.operator("object.function3_execute_operator", text="Fix currently selected SpotLights")

class OBJECT_OT_Function3ExecuteOperator(bpy.types.Operator):
    bl_idname = "object.function3_execute_operator"
    bl_label = "Handle Duplicate SpotIDs"

    def execute(self, context):
        # Step 1: Filter SpotLights
        selected_spotlights = [
            obj for obj in bpy.context.selected_objects
            if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and (not obj.name.startswith("EXT_Light_") or '.' in obj.name)
        ]

        # Step 2: Check and Add Custom Properties
        for spot_light in selected_spotlights:
            for prop_name in ["addr", "castShadow", "enable", "isBounced", "temperature", "transform"]:
                if prop_name not in spot_light:
                    spot_light[prop_name] = spot_light.get(prop_name, None)  # Keep existing value or set default
            
            # Step 3: Set Value Limits
            spot_light["_RNA_UI"] = {
                "addr": {"min": 200000, "max": 200999},
                "castShadow": {"min": 0, "max": 1},
                "enable": {"min": 0, "max": 1},
                "isBounced": {"min": 0, "max": 1},
                "temperature": {"min": 1000, "max": 40000},
                "transform": {"min": 201000, "max": 201999},
            }
        
        # Step 4: Rename SpotLights
        existing_names = {obj.name for obj in bpy.context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_")}

        for i, spot_light in enumerate(selected_spotlights):
            new_name = f"EXT_Light_{i:03d}"
            while new_name in existing_names:
                i += 1
                new_name = f"EXT_Light_{i:03d}"

            spot_light.name = new_name
            existing_names.add(new_name)
            
            # Step 5: Assign Default Values and Align addr and transform
            spot_id = int(spot_light.name.split("_")[-1])  # Extract the last part of the SpotID
            spot_light["addr"] = 200000 + spot_id
            spot_light["castShadow"] = 0
            spot_light["enable"] = 1
            spot_light["isBounced"] = 0
            spot_light["temperature"] = 5000
            spot_light["transform"] = 201000 + spot_id

        self.report({'INFO'}, "Duplicate SpotIDs have been handled.")
        return {'FINISHED'}

apply_texture_updater_value = "Select Texture for Flag Material"

def update_custom_path(self, context):
    self.layout.prop(context.scene, "custom_export_path", text="Export Path:")

class CustomPathOperator(bpy.types.Operator):
    bl_idname = "object.custom_path_operator"
    bl_label = "Select .fpk"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='DIR_PATH', update=update_custom_path)

    def execute(self, context):
        # Update the custom property with the selected file path
        context.scene.custom_export_path = self.filepath
        # Reopen the "Add Objects" popup using popup_menu()
        context.scene.uploaded_stadium_directory = self.filepath
        bpy.ops.object.function4_operator('INVOKE_DEFAULT')
        return {'FINISHED'}

    def invoke(self, context, event):
        # Open file browser
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class OBJECT_OT_Function4Operator(bpy.types.Operator):
    bl_idname = "object.function4_operator"
    bl_label = "Export Dynamic Objects (Flags and Trees)"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=300)  # Adjust width as needed

    def draw(self, context):
        layout = self.layout
        layout.label(text=context.scene.addOBJ_label_text)

        # Add buttons for selecting objects to add
        layout.operator("object.add_waving_flag_c_operator", text="+ Waving Flag (Large)")
        layout.operator("object.add_waving_flag_a_operator", text="+ Waving Flag (Medium)")
        layout.operator("object.add_waving_flag_d_operator", text="+ Waving Flag (Small)")
        layout.operator("object.add_waving_flag_execute_operator", text=f"{apply_texture_updater_value}")
        
        # Add a separator line
        layout.separator()

        # Add another button
        layout.operator("object.add_tree_a0_operator", text="+ Tree (Type a0)")
        layout.operator("object.add_tree_b0_operator", text="+ Tree (Type b0)")
        
        # Add a separator line
        layout.separator()
        
        # Your original text
        original_text2 = "Navigate to a folder called standsFlag inside your stadium. Select your (flagarea_st000.fpk) file for export."

        # Set the desired width for wrapping
        width = 55  # Adjust this based on your layout width

        # Wrap the text
        wrapped_text = textwrap.fill(original_text2, width=width)

        # Create the layout with the wrapped text
        box = layout.box()
        for line in wrapped_text.split('\n'):
            row = box.row(align=True)
            row.alignment = 'EXPAND'
            row.label(text=line)
            # Reduce spacing between rows
            row.scale_y = 0.6  # Adjust this value to your liking
        
        # Automatically populated "Export Path" field
        layout.operator("object.custom_path_operator", text="Select File")
        
        layout.prop(context.scene, "uploaded_stadium_directory", text="Export Path:")
        
        # Add a separator line
        layout.separator()
        
        layout.operator("object.export_objects_operator", text="Export to FLAGAREA")

# Define a function to count the number of directory levels in a path
def count_directory_levels(path):
    return path.count(os.path.sep)

class OBJECT_OT_ExportObjectsOperator(bpy.types.Operator):
    bl_idname = "object.export_objects_operator"
    bl_label = "Export Objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    new_fpk_path = ""  # Define at the class level
    new_fpkd_path = ""  # Define at the class level

    def execute(self, context):
        # Check if the export path is valid
        if self.check_export_path(context):
            # Call your export function
            self.export_objects(context)

        return {'FINISHED'}

    def check_export_path(self, context):
        global command
        global command2
        # Get the file path
        file_path = bpy.context.scene.uploaded_stadium_directory
        directory, file_name = os.path.split(file_path)

        # Check if "\standsFlag\#Win\" is in the directory string, and file ends with ".fpk"
        if os.path.sep + "standsFlag" + os.path.sep + "#Win" + os.path.sep in file_path and file_name.lower().endswith(".fpk"):
            # Check if the file size is greater than 48 bytes
            if os.path.getsize(file_path) > 48:
                
                gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")
                self.command = [gzs_tool_path, bpy.context.scene.uploaded_stadium_directory]
                self.command2 = [gzs_tool_path, bpy.context.scene.uploaded_stadium_directory + "d"]
                self.new_fpk_path = file_path
                self.new_fpkd_path = file_path + "d"
                return True

            else:
                # Look for "st0[00-99]" in the directory string
                match = re.search(r'st0(\d{2})', directory)
                if match:
                    self.report({'INFO'}, "Your .FPK is empty, replacing with a template.")
                    # Extract the stadium ID
                    stadiumID = match.group(1)

                    script_path = os.path.dirname(os.path.realpath(__file__))

                    # Create paths for the template files
                    template_fpk_path = os.path.join(script_path, "resources-peslightmanager", "Templates", "flagarea_.fpk")
                    template_fpkd_path = os.path.join(script_path, "resources-peslightmanager", "Templates", "flagarea_.fpkd")

                    # Delete existing .fpk and .fpkd files in the directory
                    for filename in os.listdir(directory):
                        if filename.lower().endswith(('.fpk', '.fpkd')):
                            file_path = os.path.join(directory, filename)
                            os.remove(file_path)

                    # Copy template .fpk and .fpkd files to the directory
                    shutil.copy(template_fpk_path, directory)
                    shutil.copy(template_fpkd_path, directory)

                    # Rename the copied files
                    new_fpk_name = f"flagarea_st0{stadiumID}.fpk"
                    new_fpkd_name = f"flagarea_st0{stadiumID}.fpkd"

                    # Full paths to the copied files
                    copied_fpk_path = os.path.join(directory, "flagarea_.fpk")
                    copied_fpkd_path = os.path.join(directory, "flagarea_.fpkd")

                    # Full paths to the new names
                    self.new_fpk_path = os.path.join(directory, new_fpk_name)
                    self.new_fpkd_path = os.path.join(directory, new_fpkd_name)

                    # Rename the copied files to the new names
                    os.rename(copied_fpk_path, self.new_fpk_path)
                    os.rename(copied_fpkd_path, self.new_fpkd_path)
                    
                    gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")
                    self.command = [gzs_tool_path, self.new_fpk_path]
                    self.command2 = [gzs_tool_path, self.new_fpkd_path]
                    return True

                else:
                    self.report({'ERROR'}, "Unable to find stadium ID in the directory string.")
        else:
            self.report({'ERROR'}, "Please select a valid .fpk file inside your standsFlag folder.")

        return False

    def insert_object_files(self, context):
        script_path = os.path.dirname(os.path.realpath(__file__))
        # Replace all "." with "_"
        add_object_files_to_path = self.new_fpk_path.replace(".", "_")

        # Initialize file path
        common_folder = add_object_files_to_path

        # Calculate how many directories to go down
        num_directories_to_go_up = 5

        # Define a mapping of folder names to replace
        folder_mapping = {
            os.path.basename(common_folder): "Assets",
            "Assets": "pes16",
            "pes16": "model",
            "model": "bg",
            "bg": "common"
            # Add more entries as needed
        }

        # Go down directories and create "common" folder
        for _ in range(num_directories_to_go_up):
            common_folder = os.path.join(common_folder, folder_mapping.get(os.path.basename(common_folder), ""))
        buffer_common_folder = common_folder
        common_folder = add_object_files_to_path
        os.makedirs(buffer_common_folder, exist_ok=True)

        # Inside "common", create "cornerflag" folder
        self.cornerflag_folder = os.path.join(buffer_common_folder, "cornerflag")
        self.grab_model_files = os.path.join(buffer_common_folder, "cornerflag")
        os.makedirs(self.cornerflag_folder, exist_ok=True)
        
        # Check if self.cornerflag_folder has any files
        if any(os.scandir(self.cornerflag_folder)):
            # If there are files, delete them
            for file in os.listdir(self.cornerflag_folder):
                file_path = os.path.join(self.cornerflag_folder, file)
                try:
                    os.remove(file_path)
                except Exception as e:
                    print(f"Error deleting file: {file_path}, Error: {e}")

        # List of flag files to copy
        object_files = [
            "dml_mobH_audi_flagbearer_01_mob_prop_teamflag_home01.gani",
            "mob_prop_teamflag_anim_skel.ask",
            "mob_prop_teamflag_home01.fmdl",
            "mob_prop_teamflag_home01.skl",
            "mob_prop_teamflag_render_skel.ask",
            "mob_prop_teamflag_skel.frig",
            "standsFlagA_0000.fmdl",
            "standsFlagC_0000.fmdl",
            "standsFlagD_0000.fmdl"
        ]

        # Copy flag files to "cornerflag" folder
        for file_name in object_files:
            source_file_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", file_name)
            target_file_path = os.path.join(self.cornerflag_folder, file_name)
            shutil.copy(source_file_path, target_file_path)
        
        # List of tree files to copy
        object_files = [
            "va_tree001_a0.fmdl",
            "va_tree001_b0.fmdl"
        ]
        
        # Copy tree files to "cornerflag" folder
        for file_name in object_files:
            source_file_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", file_name)
            target_file_path = os.path.join(self.cornerflag_folder, file_name)
            shutil.copy(source_file_path, target_file_path)
            
        self.cornerflag_folder = None   
        
        # Initialize file path
        for _ in range(4):
            add_object_files_to_path = os.path.dirname(add_object_files_to_path)
        common_folder = add_object_files_to_path

        # Calculate how many directories to go down this time
        num_directories_to_go_up = 5

        # Define a mapping of folder names to replace
        folder_mapping = {
            os.path.basename(common_folder): "common",
            "common": "standsFlag",
            "standsFlag": "sourceimages",
            "sourceimages": "tga",
            "tga": "#windx11"
            # Add more entries as needed
        }

        # Go down directories and create flag texture folder
        for _ in range(num_directories_to_go_up):
            common_folder = os.path.join(common_folder, folder_mapping.get(os.path.basename(common_folder), ""))
        self.cornerflag_folder = common_folder
        common_folder = add_object_files_to_path
        os.makedirs(self.cornerflag_folder, exist_ok=True)
        
        # List of object files to copy
        texture_files = [
            "_bsm.dds",
            "_bsm.ftex",
            "flag_mask00.ftex",
            "flag_mask01.ftex",
            "flag_mask02.ftex",
            "flag_mask03.ftex",
            "flag_mask04.ftex",
            "flag_mtl.ftex",
            "flag_nrm.ftex",
            "flag_nrm_nomip.ftex",
            "flag_srm.ftex",
            "pes2019_anim_Mid_A01_pos_nomip.ftex",
            "pes2019_anim_Mid_A01_rot_nomip.ftex",
            "pes2019_Midle_B02_pos_nomip.ftex",
            "pes2019_Midle_B02_rot_nomip.ftex",
            "pes2019_Small_A01_pos_nomip.ftex",
            "pes2019_Small_A01_rot_nomip.ftex",
            "pes2019_Small_B01_pos_nomip.ftex",
            "pes2019_Small_B01_rot_nomip.ftex"
        ]

        # Copy object files to "cornerflag" folder
        for file_name in texture_files:
            source_file_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", "textures", file_name)
            target_file_path = os.path.join(self.cornerflag_folder)
            shutil.copy(source_file_path, target_file_path)

        self.reorder_objects(context)

    def reorder_objects(self, context):
        all_flag_objects = [
            obj for obj in bpy.context.scene.objects
            if obj.name.startswith("VA_FLAG_")
        ]
        
        all_tree_a0_objects = [
            obj for obj in bpy.context.scene.objects
            if obj.name.startswith("VA_TREE_A0")
        ]
        
        all_tree_b0_objects = [
            obj for obj in bpy.context.scene.objects
            if obj.name.startswith("VA_TREE_B0")
        ]

        # Step 1: Extract existing object_ids
        existing_flag_ids = {obj.name for obj in bpy.context.scene.objects if obj.name.startswith("VA_FLAG_")}
        existing_tree_a0_ids = {obj.name for obj in bpy.context.scene.objects if obj.name.startswith("VA_TREE_A0")}
        existing_tree_b0_ids = {obj.name for obj in bpy.context.scene.objects if obj.name.startswith("VA_TREE_B0")}

        # Step 2: Iterate over selected flag objects and rename
        for i, obj in enumerate(all_flag_objects):
            new_name = f"VA_FLAG_{i:04d}"
            while i in existing_flag_ids:
                i += 1
                new_name = f"VA_FLAG_{i:04d}"
            
            obj.name = new_name
            existing_flag_ids.add(i)

            # Step 3: Update custom properties for flag object
            obj["addr"] = 300000 + i
            obj["transform"] = 310000 + i
            obj["texture_id"] = f"{0:04d}"
            debug_objaddr = 300000 + i
            debug_objtransform = 310000 + i
            debug_texture_id = obj["texture_id"]
            print(f"Object Name: {new_name}; Object Address: {debug_objaddr}; Object Transform: {debug_objtransform}; Texture ID: {debug_texture_id}")
        
        # Step 2: Iterate over selected tree a0 objects and rename
        for i, obj in enumerate(all_tree_a0_objects):
            object_type = obj.get("objectType") 
            new_name = f"VA_TREE_A0_{i:04d}"
            while i in existing_tree_a0_ids:
                i += 1
                new_name = f"VA_TREE_A0_{i:04d}"
            
            obj.name = new_name
            existing_tree_a0_ids.add(i)

            # Step 3: Update custom properties for tree object
            obj["addr"] = 400000 + i
            obj["transform"] = 410000 + i
            debug_objaddr = 400000 + i
            debug_objtransform = 410000 + i
            print(f"Object Name: {new_name}; Object Address: {debug_objaddr}; Object Transform: {debug_objtransform}; Object Type: {object_type}")
            
        # Step 2: Iterate over selected tree b0 objects and rename
        for i, obj in enumerate(all_tree_b0_objects):
            object_type = obj.get("objectType") 
            new_name = f"VA_TREE_B0_{i:04d}"
            while i in existing_tree_b0_ids:
                i += 1
                new_name = f"VA_TREE_B0_{i:04d}"
            
            obj.name = new_name
            existing_tree_b0_ids.add(i)

            # Step 3: Update custom properties for tree object
            obj["addr"] = 500000 + i
            obj["transform"] = 510000 + i
            debug_objaddr = 500000 + i
            debug_objtransform = 510000 + i
            print(f"Object Name: {new_name}; Object Address: {debug_objaddr}; Object Transform: {debug_objtransform}; Object Type: {object_type}")
            
        self.search_and_assign_texture_ids(context)
            
    def search_and_assign_texture_ids(self, context):
        # Step 1: Get all flag objects in the scene
        all_flag_objects = [
            obj for obj in bpy.context.scene.objects
            if obj.name.startswith("VA_FLAG_")
        ]

        # Step 2: Create a mapping between texture paths and texture IDs
        self.texture_id_mapping = {}

        # Flag to check if flag objects are found
        flag_objects_found = False

        # Step 3: Iterate over flag objects
        for flag_obj in all_flag_objects:
            # Flag objects are found, set the flag to True
            flag_objects_found = True

            # Step 4: Iterate over material slots in the object
            for slot in flag_obj.material_slots:
                # Check if the slot name starts with "flag_material"
                if slot.name.startswith("flag_material") and slot.material:
                    flag_material = slot.material

                    # Step 5: Iterate over texture slots in the material
                    for slot in flag_material.node_tree.nodes:
                        if slot.type == 'TEX_IMAGE':
                            # Get the texture image from the texture slot
                            texture_image = slot.image

                            # Check if the texture image is not None
                            if texture_image:
                                # Get the texture path and name
                                texture_path = bpy.path.abspath(texture_image.filepath)
                                texture_name = texture_image.name

                            # Step 6: Check if the texture_path is already mapped to a texture_id
                            if texture_path not in self.texture_id_mapping:
                                # If not, assign the next available texture_id
                                next_texture_id = len(self.texture_id_mapping)
                                self.texture_id_mapping[texture_path] = f"{next_texture_id:04d}"

                                # Step 7: Print or use the texture_id
                                print(f"Object Name: {flag_obj.name}")
                                print(f"Texture Name: {texture_name}")
                                print(f"Texture Path: {texture_path}")
                                print(f"Assigned Texture ID: {next_texture_id:04d}")
                                flag_obj["texture_id"] = f"{next_texture_id:04d}"

                                # Step 8: Assign the texture_id or perform other actions as needed
                                # You can use the next_texture_id to assign it to the object or perform any other logic.
                            else:
                                # If the texture_path is already mapped, use the existing texture_id
                                existing_texture_id = self.texture_id_mapping[texture_path]
                                print(f"Object Name: {flag_obj.name}")
                                print(f"Texture Name: {texture_name}")
                                print(f"Texture Path: {texture_path}")
                                print(f"Existing Texture ID: {existing_texture_id}")
                                flag_obj["texture_id"] = f"{existing_texture_id}"

                                # Step 9: Assign the existing_texture_id or perform other actions as needed
                                # You can use the existing_texture_id to assign it to the object or perform any other logic.

        # Check if flag objects are found
        if flag_objects_found:
            self.create_textures(context, self.cornerflag_folder, self.grab_model_files)
        else:
            self.pack_fpk(context)

    def resize_dds_top_anchor(self, input_path, output_path, x_factor, y_factor, allowed_sizes):
        # Load the image
        img = Image.open(input_path)

        # Get the original width and height
        width, height = img.size

        # Calculate the new width and height based on distortion factors
        new_width = int(width * x_factor)
        new_height = int(height * y_factor)

        # Create a new image with white background
        distorted_img = Image.new("RGBA", (new_width, new_height), (255, 255, 255, 255))

        # Calculate the position to paste the original image, anchored to the top
        paste_x = (new_width - width) // 2
        paste_y = 0  # Anchored to the top

        # Paste the original image onto the new image
        distorted_img.paste(img, (paste_x, paste_y))
        
        # Calculate the new size for both width and height based on the maximum dimension
        max_dimension = max(width, height)
        new_size = max([size for size in allowed_sizes if size <= max_dimension])

        # Set the aspect ratio to 1:1 using the closest allowed size
        final_size = min(allowed_sizes, key=lambda x: abs(x - new_size))
        final_img = distorted_img.resize((final_size, final_size), Image.ANTIALIAS)

        # Save the resized image
        final_img.save(output_path)

    def create_textures(self, context, cornerflag_folder, grab_model_files):
        for blender_texture, current_texture_id in self.texture_id_mapping.items():
            # Copy the file from blender_texture to cornerflag_folder
            source_file_path = blender_texture
            target_file_path = os.path.join(cornerflag_folder, f"{current_texture_id}_bsm.dds")
            
            shutil.copy(source_file_path, target_file_path)
            
            # Allowed sizes
            allowed_sizes = [4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
            
            input_file_path = source_file_path
            output_file_path = target_file_path
            
            self.resize_dds_top_anchor(input_file_path, output_file_path, x_factor=1, y_factor=1.4545, allowed_sizes=allowed_sizes)
            
            # Duplicate model files for each current_texture_id
            for current_texture_id in range(len(self.texture_id_mapping)):
                model_files_to_find = [
                    f"standsFlagA_{current_texture_id:04d}.fmdl",
                    f"standsFlagC_{current_texture_id:04d}.fmdl",
                    f"standsFlagD_{current_texture_id:04d}.fmdl"
                ]

                for model_file_to_find in model_files_to_find:
                    source_model_path = os.path.join(grab_model_files, model_file_to_find)
                    target_model_path = os.path.join(grab_model_files, f"{model_file_to_find[:-9]}{current_texture_id + 1:04d}.fmdl")

                    # Check if the source model file exists
                    if os.path.exists(source_model_path):

                        # Read and edit the content of the file in binary mode
                        with open(source_model_path, 'rb') as file:
                            content = file.read()

                            # Use regular expression to find the 4 digits before "_bsm.tga"
                            pattern = re.compile(rb'(\d{4})_bsm.tga')
                            match = pattern.search(content)

                            if match:
                                # Replace the 4 digits with the new value
                                start, end = match.span(1)
                                replacement = f'{current_texture_id:04d}'.encode('utf-8')
                                content = content[:start] + replacement + content[end:]

                                # Output the modified content to the file
                                with open(source_model_path, 'wb') as output_file:
                                    output_file.write(content)

                        if not os.path.exists(target_model_path):
                            # Duplicate and rename the model file
                            try:
                                with open(source_model_path, 'rb') as source_file:
                                    model_content = source_file.read()
                                    with open(target_model_path, 'wb') as target_file:
                                        target_file.write(model_content)
                            except Exception as e:
                                print(f"Error duplicating model file: {source_model_path} -> {target_model_path}, Error: {e}")
                    else:
                        print(f"Source model file not found: {source_model_path}")
                        
            self.pack_fpk(context)

    def pack_fpk(self, context):
        # Define pack_fpk_xml_path
        pack_fpk_xml_path = f"{self.new_fpk_path}.xml"

        # Define file_fpk_locator
        file_fpk_locator = self.new_fpk_path.replace(".", "_")
        
        # Split self.new_fpk_path into file path and file name
        file_path, replace_fpk_st000 = os.path.split(self.new_fpk_path)

        # Gather file paths
        entries = []
        for root, dirs, files in os.walk(file_fpk_locator):
            for file in files:
                # Create relative path with forward slashes
                relative_path = os.path.relpath(os.path.join(root, file), file_fpk_locator).replace("\\", "/")

                # Add entry
                entries.append(f'<Entry FilePath="/{relative_path}" />')

        # Create XML content
        xml_content = (
            '<?xml version="1.0"?>\n'
            '<ArchiveFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
            'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xsi:type="FpkFile" Name="' + replace_fpk_st000 + '" FpkType="Fpk">\n'
            '  <Entries>\n'
            '    ' + '\n    '.join(entries) + '\n'
            '  </Entries>\n'
            '  <References />\n'
            '</ArchiveFile>\n'
        )

        # Write XML content to file
        with open(pack_fpk_xml_path, 'w') as xml_file:
            xml_file.write(xml_content)

        # Run GzsTool.exe to pack the .fpk file
        gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")
        self.command3 = [gzs_tool_path, pack_fpk_xml_path]

        # Check if GzsTool.exe exists
        if os.path.exists(gzs_tool_path):
            # Run GzsTool.exe to pack the .fpk file
            try:
                subprocess.run(self.command3, check=True)
                self.fox2_exporter(context)
            except subprocess.CalledProcessError as e:
                self.report({'ERROR'}, f"Packing .FPK failed with error: {e}")
        else:
            self.report({'ERROR'}, "GzsTool.exe not found")

    def fox2_exporter(self, context):
        # Print out the self.new_fpkd_path value
        print(f"FOX2 Exporter - New FPKD Path: {self.new_fpkd_path}")
        
        self.fox2_location_for_import = self.new_fpkd_path.replace(".", "_")

        # Navigate to \Assets\pes16\model\bg\st0[00-99]\standsFlag
        for i in range(100):
            potential_directory = os.path.join(self.fox2_location_for_import, "Assets", "pes16", "model", "bg", f"st0{i:02d}", "standsFlag")
            if os.path.exists(potential_directory):
                self.fox2_location_for_import = potential_directory
                break

        # Search for .fox2 file dynamically
        fox2_files = [file for file in os.listdir(self.fox2_location_for_import) if file.endswith(".fox2")]

        # Check if there is exactly one .fox2 file
        if len(fox2_files) == 1:
            fox2_file_name = fox2_files[0]
            self.fox2_location_for_import = os.path.join(self.fox2_location_for_import, fox2_file_name)
            
            # Run FoxTool.exe to convert .fox2 to .xml
            fox_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "FoxTool", "FoxTool.exe")

            if os.path.exists(fox_tool_path):
                # Check if FoxTool.exe exists
                command = [fox_tool_path, self.fox2_location_for_import]
                try:
                    subprocess.run(command, check=True)
                    self.edit_fox2_xml(context, self.fox2_location_for_import)
                except subprocess.CalledProcessError as e:
                    self.report({'ERROR'}, f"Running FoxTool.exe failed with error: {e}")
            else:
                self.report({'ERROR'}, "FoxTool.exe not found")
        elif len(fox2_files) == 0:
            print(f"FOX2 Exporter - No .fox2 file found in the specified path.")
        else:
            print(f"FOX2 Exporter - Multiple .fox2 files found. Please specify a unique criterion.")

    def create_backup(self, context, fox2_location_for_import):
        # Split xml_file_path into fox2_xml_file_path and fox2_xml_file_name
        fox2_xml_file_path, fox2_xml_file_name = os.path.split(fox2_location_for_import)

        # Create a backup folder
        backup_flagarea_path = bpy.path.abspath(os.path.join(fox2_xml_file_path, "backup"))
        print(f"Saving Backup at: {backup_flagarea_path}")
        os.makedirs(backup_flagarea_path, exist_ok=True)

        # Form the source and target paths for the XML file
        xml_file_path = os.path.join(fox2_xml_file_path, f"{fox2_xml_file_name}.xml")
        target_backup_path = os.path.join(backup_flagarea_path, f"{fox2_xml_file_name}_backup.xml")

        # Check if the backup folder already exists
        if os.path.exists(target_backup_path):
            # Revert the XML file from the backup
            try:
                with codecs.open(target_backup_path, 'r', encoding='utf-8') as source_file:
                    xml_content = source_file.read()

                    with codecs.open(xml_file_path, 'w', encoding='utf-8') as target_file:
                        target_file.write(xml_content)

                print("XML file reverted from backup successfully.")
            except Exception as e:
                print(f"Error reverting XML file from backup: {xml_file_path}, Error: {e}")
        else:
            print("No existing backup found.")

        # Backup the XML file with explicit encoding
        try:
            with codecs.open(xml_file_path, 'r', encoding='utf-8') as source_file:
                xml_content = source_file.read()

                with codecs.open(target_backup_path, 'w', encoding='utf-8') as target_file:
                    target_file.write(xml_content)

            print("Backup created successfully.")
        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error creating backup for XML file: {xml_file_path}, Error: {e}")

    def insert_lines_before_classes(self, xml_file_path):
        try:
            # Read the content of the XML file with explicit encoding
            with codecs.open(xml_file_path, 'r', encoding='utf-8') as xml_file:
                xml_content = xml_file.read()

                # Check if the desired string is present in the XML content
                if "</classes>" in xml_content:
                    # Insert the specified lines before </classes>
                    lines_to_insert = [
                        '  <class name="StadiumAnime" super="" version="3" />',
                        '    <class name="StadiumModel" super="" version="3" />',
                        '    <class name="TransformEntity" super="" version="0" />'
                    ]

                    # Insert the lines before </classes>
                    modified_xml_content = xml_content.replace("</classes>", "\n".join(lines_to_insert) + "\n  </classes>")

                    # Write the modified content back to the XML file with explicit encoding
                    with codecs.open(xml_file_path, 'w', encoding='utf-8') as modified_xml_file:
                        modified_xml_file.write(modified_xml_content)

        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading or modifying XML file: {xml_file_path}, Error: {e}")

    def insert_lines_inside_DataList(self, xml_file_path):
        try:
            # Read the content of the XML file
            with open(xml_file_path, 'r') as xml_file:
                xml_content = xml_file.read()

                # Find the index of the string '<property name="dataList"'
                index_data_list = xml_content.find('<property name="dataList"')

                if index_data_list != -1:
                    # Move the index to the end of '<property name="dataList"' line
                    index_data_list = xml_content.find('\n', index_data_list) + 1

                    # Move two lines down
                    index_insert = xml_content.find('\n', index_data_list)
                    index_insert = xml_content.find('\n', index_insert) + 1

                    # Combine all objects into a single list
                    all_objects = [
                        obj for obj in bpy.context.scene.objects
                        if obj.name.startswith("VA_FLAG_") or obj.name.startswith("VA_TREE_A0") or obj.name.startswith("VA_TREE_B0")
                    ]

                    # Insert the specified lines for each object
                    lines_to_insert = [
                        f'          <value key="{obj.name}">0x00{obj["addr"]}</value>' for obj in all_objects
                    ]

                    # Insert the lines after '<property name="dataList"'
                    modified_xml_content = (
                        xml_content[:index_insert] +
                        '\n'.join(lines_to_insert) + "\n" +
                        xml_content[index_insert:]
                    )

                    # Write the modified content back to the XML file
                    with open(xml_file_path, 'w') as modified_xml_file:
                        modified_xml_file.write(modified_xml_content)


        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading or modifying XML file: {xml_file_path}, Error: {e}")
            
    def insert_StadiumAnime(self, xml_file_path):
        try:
            # Read the content of the XML file
            with open(xml_file_path, 'r') as xml_file:
                xml_content = xml_file.read()

                # Find the index of the string '<property name="dataList"'
                index_data_list = xml_content.find('<property name="dataList"')

                if index_data_list != -1:
                    # Move the index to the end of '<property name="dataList"' line
                    index_data_list = xml_content.find('\n', index_data_list) + 1

                    # Move two lines down
                    index_insert = xml_content.find('\n', index_data_list)
                    index_insert = xml_content.find('\n', index_insert) + 1

                    # Insert the specified lines for each object
                    lines_to_insert = [
                        '          <value key="StadiumAnime_Flags">0x00001488</value>'
                    ]

                    # Insert the lines after '<property name="dataList"'
                    modified_xml_content = (
                        xml_content[:index_insert] +
                        '\n'.join(lines_to_insert) + "\n" +
                        xml_content[index_insert:]
                    )

                    # Write the modified content back to the XML file
                    with open(xml_file_path, 'w') as modified_xml_file:
                        modified_xml_file.write(modified_xml_content)


        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading or modifying XML file: {xml_file_path}, Error: {e}")            

    def get_data_set_value(self, xml_file_path):
        try:
            # Read the content of the XML file
            with open(xml_file_path, 'r') as xml_file:
                xml_content = xml_file.read()

                # Find the first occurrence of the string 'addr="'
                index_addr = xml_content.find('addr="')

                if index_addr != -1:
                    # Move to the end of 'addr="' and get the next 10 characters
                    index_start = index_addr + len('addr="')
                    self.dataSet = xml_content[index_start:index_start + 10]


        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading XML file: {xml_file_path}, Error: {e}")

    def insert_lines_for_flag_objects(self, xml_file_path):
        try:
            # Read the content of the XML file
            with open(xml_file_path, 'r') as xml_file:
                xml_content = xml_file.read()

                # Find the index of the string '</entities>'
                index_entities = xml_content.find('</entities>')

                if index_entities != -1:
                    # Move one index back to the start of '</entities>'
                    index_insert = index_entities - 1

                    # Combine all objects into a single list
                    flag_objects = [
                        obj for obj in bpy.context.scene.objects
                        if obj.name.startswith("VA_FLAG_")
                    ]

                    # Define the lines to insert for each flag_object
                    lines_to_insert_entities = []

                    for obj in flag_objects:

                        # Determine scale, location, and rotation attributes
                        object_scale_x = obj.scale.x
                        object_scale_y = obj.scale.y
                        object_scale_z = obj.scale.z

                        object_transform_translation_x = obj.location.x
                        object_transform_translation_y = obj.location.y
                        object_transform_translation_z = obj.location.z

                        object_transform_rotation_quat_w = obj.rotation_quaternion.w
                        object_transform_rotation_quat_x = obj.rotation_quaternion.x
                        object_transform_rotation_quat_y = obj.rotation_quaternion.y
                        object_transform_rotation_quat_z = obj.rotation_quaternion.z
                        
                        # Determine model_file based on texture_id and objectType
                        print(f"{obj['texture_id']}")
                        if obj["objectType"] == 0:
                            model_file = f"/Assets/pes16/model/bg/common/cornerflag/standsFlagA_{obj['texture_id']}.fmdl"
                        elif obj["objectType"] == 1:
                            object_scale_x = object_scale_x / 1.5
                            object_scale_y = object_scale_y / 1.5
                            object_scale_z = object_scale_z / 1.5
                            model_file = f"/Assets/pes16/model/bg/common/cornerflag/standsFlagC_{obj['texture_id']}.fmdl"
                        elif obj["objectType"] == 2:
                            object_scale_x = object_scale_x * 1.2
                            object_scale_y = object_scale_y * 1.2
                            object_scale_z = object_scale_z * 1.2
                            model_file = f"/Assets/pes16/model/bg/common/cornerflag/standsFlagD_{obj['texture_id']}.fmdl"
                        else:
                            # Default value if objectType is not one of the expected values
                            model_file = "/Assets/pes16/model/bg/common/cornerflag/standsFlagA_ERRO.fmdl"
                        
                        # Round attributes
                        object_scale_x = round(object_scale_x, 2)
                        object_scale_y = round(object_scale_y, 2)
                        object_scale_z = round(object_scale_z, 2)

                        object_transform_translation_x = round(object_transform_translation_x, 4)
                        object_transform_translation_y = round(object_transform_translation_y, 4)
                        object_transform_translation_z = round(object_transform_translation_z, 4)

                        object_transform_rotation_quat_w = round(object_transform_rotation_quat_w, 4)
                        object_transform_rotation_quat_x = round(object_transform_rotation_quat_x, 4)
                        object_transform_rotation_quat_y = round(object_transform_rotation_quat_y, 4)
                        object_transform_rotation_quat_z = round(object_transform_rotation_quat_z, 4)
                         
                        lines_to_insert_entities.extend([
                            f'    <entity class="StadiumModel" classVersion="3" addr="0x00{obj["addr"]}" unknown1="400" unknown2="0">',
                            '      <staticProperties>',
                            f'        <property name="name" type="String" container="StaticArray" arraySize="1">',
                            f'          <value>{obj.name}</value>',
                            '        </property>',
                            '        <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">',
                            f'          <value>{self.dataSet}</value>',
                            '        </property>',
                            '        <property name="parent" type="EntityHandle" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="transform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            f'          <value>0x00{obj["transform"]}</value>',
                            '        </property>',
                            '        <property name="shearTransform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="pivotTransform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="children" type="EntityHandle" container="List" />',
                            '        <property name="flags" type="uint32" container="StaticArray" arraySize="1">',
                            '          <value>7</value>',
                            '        </property>',
                            f'        <property name="modelFile" type="FilePtr" container="StaticArray" arraySize="1">',
                            f'          <value>{model_file}</value>',
                            '        </property>',
                            '        <property name="isIsolated" type="bool" container="StaticArray" arraySize="1">',
                            '          <value>false</value>',
                            '        </property>',
                            '        <property name="isDynamic" type="bool" container="StaticArray" arraySize="1">',
                            '          <value>true</value>',
                            '        </property>',
                            '        <property name="lodFarSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>-1</value>',
                            '        </property>',
                            '        <property name="lodNearSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>-1</value>',
                            '        </property>',
                            '        <property name="lodPolygonSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>1</value>',
                            '        </property>',
                            '        <property name="color" type="Color" container="StaticArray" arraySize="1">',
                            '          <value r="1" g="1" b="1" a="1" />',
                            '        </property>',
                            '        <property name="drawRejectionLevel" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>8</value>',
                            '        </property>',
                            '        <property name="drawMode" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '        <property name="rejectFarRangeShadowCast" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>2</value>',
                            '        </property>',
                            '        <property name="direction" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>5</value>',
                            '        </property>',
                            '        <property name="kind" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>2</value>',
                            '        </property>',
                            '        <property name="demoGroup" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '        <property name="customBits" type="uint32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '      </staticProperties>',
                            '      <dynamicProperties />',
                            '    </entity>',
                            f'    <entity class="TransformEntity" classVersion="0" addr="0x00{obj["transform"]}" unknown1="96" unknown2="0">',
                            '      <staticProperties>',
                            '        <property name="owner" type="EntityHandle" container="StaticArray" arraySize="1">',
                            f'          <value>0x00{obj["addr"]}</value>',
                            '        </property>',
                            '        <property name="transform_scale" type="Vector3" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_scale_x}" y="{object_scale_y}" z="{object_scale_z}" w="0" />',
                            '        </property>',
                            '        <property name="transform_rotation_quat" type="Quat" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_transform_rotation_quat_x}" y="{object_transform_rotation_quat_z}" z="{-object_transform_rotation_quat_y}" w="{object_transform_rotation_quat_w}" />',
                            '        </property>',
                            '        <property name="transform_translation" type="Vector3" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_transform_translation_x}" y="{object_transform_translation_z}" z="{-object_transform_translation_y}" w="0" />',
                            '        </property>',
                            '      </staticProperties>',
                            '      <dynamicProperties />',
                            '    </entity>'
                        ])

                    # Insert the lines after '</entities>'
                    modified_xml_content_entities = (
                        xml_content[:index_insert] +
                        '\n'.join(lines_to_insert_entities) + "\n" +
                        xml_content[index_insert:]
                    )

                    # Write the modified content back to the XML file
                    with open(xml_file_path, 'w') as modified_xml_file:
                        modified_xml_file.write(modified_xml_content_entities)


        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading or modifying XML file: {xml_file_path}, Error: {e}")

    def insert_lines_for_tree_a0_objects(self, xml_file_path):
        try:
            # Read the content of the XML file
            with open(xml_file_path, 'r') as xml_file:
                xml_content = xml_file.read()

                # Find the index of the string '</entities>'
                index_entities = xml_content.find('</entities>')

                if index_entities != -1:
                    # Move one index back to the start of '</entities>'
                    index_insert = index_entities - 1

                    # Combine all objects into a single list
                    tree_objects = [
                        obj for obj in bpy.context.scene.objects
                        if obj.name.startswith("VA_TREE_A0")
                    ]

                    # Define the lines to insert for each flag_object
                    lines_to_insert_entities = []

                    for obj in tree_objects:
                         
                        # Determine scale, location, and rotation attributes
                        object_scale_x = obj.scale.x
                        object_scale_y = obj.scale.y
                        object_scale_z = obj.scale.z

                        object_transform_translation_x = obj.location.x
                        object_transform_translation_y = obj.location.y
                        object_transform_translation_z = obj.location.z

                        object_transform_rotation_quat_w = obj.rotation_quaternion.w
                        object_transform_rotation_quat_x = obj.rotation_quaternion.x
                        object_transform_rotation_quat_y = obj.rotation_quaternion.y
                        object_transform_rotation_quat_z = obj.rotation_quaternion.z
                        
                        # Round attributes
                        object_scale_x = round(object_scale_x, 2)
                        object_scale_y = round(object_scale_y, 2)
                        object_scale_z = round(object_scale_z, 2)

                        object_transform_translation_x = round(object_transform_translation_x, 4)
                        object_transform_translation_y = round(object_transform_translation_y, 4)
                        object_transform_translation_z = round(object_transform_translation_z, 4)

                        object_transform_rotation_quat_w = round(object_transform_rotation_quat_w, 4)
                        object_transform_rotation_quat_x = round(object_transform_rotation_quat_x, 4)
                        object_transform_rotation_quat_y = round(object_transform_rotation_quat_y, 4)
                        object_transform_rotation_quat_z = round(object_transform_rotation_quat_z, 4)
                         
                        lines_to_insert_entities.extend([
                            f'    <entity class="StadiumModel" classVersion="3" addr="0x00{obj["addr"]}" unknown1="400" unknown2="0">',
                            '      <staticProperties>',
                            f'        <property name="name" type="String" container="StaticArray" arraySize="1">',
                            f'          <value>{obj.name}</value>',
                            '        </property>',
                            '        <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">',
                            f'          <value>{self.dataSet}</value>',
                            '        </property>',
                            '        <property name="parent" type="EntityHandle" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="transform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            f'          <value>0x00{obj["transform"]}</value>',
                            '        </property>',
                            '        <property name="shearTransform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="pivotTransform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="children" type="EntityHandle" container="List" />',
                            '        <property name="flags" type="uint32" container="StaticArray" arraySize="1">',
                            '          <value>7</value>',
                            '        </property>',
                            '        <property name="modelFile" type="FilePtr" container="StaticArray" arraySize="1">',
                            '          <value>/Assets/pes16/model/bg/common/cornerflag/va_tree001_a0.fmdl</value>',
                            '        </property>',
                            '        <property name="isIsolated" type="bool" container="StaticArray" arraySize="1">',
                            '          <value>false</value>',
                            '        </property>',
                            '        <property name="isDynamic" type="bool" container="StaticArray" arraySize="1">',
                            '          <value>true</value>',
                            '        </property>',
                            '        <property name="lodFarSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>-1</value>',
                            '        </property>',
                            '        <property name="lodNearSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>-1</value>',
                            '        </property>',
                            '        <property name="lodPolygonSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>1</value>',
                            '        </property>',
                            '        <property name="color" type="Color" container="StaticArray" arraySize="1">',
                            '          <value r="1" g="1" b="1" a="1" />',
                            '        </property>',
                            '        <property name="drawRejectionLevel" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>8</value>',
                            '        </property>',
                            '        <property name="drawMode" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '        <property name="rejectFarRangeShadowCast" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>2</value>',
                            '        </property>',
                            '        <property name="direction" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>5</value>',
                            '        </property>',
                            '        <property name="kind" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>2</value>',
                            '        </property>',
                            '        <property name="demoGroup" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '        <property name="customBits" type="uint32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '      </staticProperties>',
                            '      <dynamicProperties />',
                            '    </entity>',
                            f'    <entity class="TransformEntity" classVersion="0" addr="0x00{obj["transform"]}" unknown1="96" unknown2="0">',
                            '      <staticProperties>',
                            '        <property name="owner" type="EntityHandle" container="StaticArray" arraySize="1">',
                            f'          <value>0x00{obj["addr"]}</value>',
                            '        </property>',
                            '        <property name="transform_scale" type="Vector3" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_scale_x}" y="{object_scale_y}" z="{object_scale_z}" w="0" />',
                            '        </property>',
                            '        <property name="transform_rotation_quat" type="Quat" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_transform_rotation_quat_x}" y="{object_transform_rotation_quat_z}" z="{-object_transform_rotation_quat_y}" w="{object_transform_rotation_quat_w}" />',
                            '        </property>',
                            '        <property name="transform_translation" type="Vector3" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_transform_translation_x}" y="{object_transform_translation_z}" z="{-object_transform_translation_y}" w="0" />',
                            '        </property>',
                            '      </staticProperties>',
                            '      <dynamicProperties />',
                            '    </entity>'
                        ])

                    # Insert the lines after '</entities>'
                    modified_xml_content_entities = (
                        xml_content[:index_insert] +
                        '\n'.join(lines_to_insert_entities) + "\n " +
                        xml_content[index_insert:]
                    )

                    # Write the modified content back to the XML file
                    with open(xml_file_path, 'w') as modified_xml_file:
                        modified_xml_file.write(modified_xml_content_entities)


        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading or modifying XML file: {xml_file_path}, Error: {e}")

    def insert_lines_for_tree_b0_objects(self, xml_file_path):
        try:
            # Read the content of the XML file
            with open(xml_file_path, 'r') as xml_file:
                xml_content = xml_file.read()

                # Find the index of the string '</entities>'
                index_entities = xml_content.find('</entities>')

                if index_entities != -1:
                    # Move one index back to the start of '</entities>'
                    index_insert = index_entities - 1

                    # Combine all objects into a single list
                    tree_objects = [
                        obj for obj in bpy.context.scene.objects
                        if obj.name.startswith("VA_TREE_B0")
                    ]

                    # Define the lines to insert for each flag_object
                    lines_to_insert_entities = []

                    for obj in tree_objects:
                         
                        # Determine scale, location, and rotation attributes
                        object_scale_x = obj.scale.x
                        object_scale_y = obj.scale.y
                        object_scale_z = obj.scale.z

                        object_transform_translation_x = obj.location.x
                        object_transform_translation_y = obj.location.y
                        object_transform_translation_z = obj.location.z

                        object_transform_rotation_quat_w = obj.rotation_quaternion.w
                        object_transform_rotation_quat_x = obj.rotation_quaternion.x
                        object_transform_rotation_quat_y = obj.rotation_quaternion.y
                        object_transform_rotation_quat_z = obj.rotation_quaternion.z
                        
                        # Round attributes
                        object_scale_x = round(object_scale_x, 2)
                        object_scale_y = round(object_scale_y, 2)
                        object_scale_z = round(object_scale_z, 2)

                        object_transform_translation_x = round(object_transform_translation_x, 4)
                        object_transform_translation_y = round(object_transform_translation_y, 4)
                        object_transform_translation_z = round(object_transform_translation_z, 4)

                        object_transform_rotation_quat_w = round(object_transform_rotation_quat_w, 4)
                        object_transform_rotation_quat_x = round(object_transform_rotation_quat_x, 4)
                        object_transform_rotation_quat_y = round(object_transform_rotation_quat_y, 4)
                        object_transform_rotation_quat_z = round(object_transform_rotation_quat_z, 4)
                         
                        lines_to_insert_entities.extend([
                            f'   <entity class="StadiumModel" classVersion="3" addr="0x00{obj["addr"]}" unknown1="400" unknown2="0">',
                            '      <staticProperties>',
                            f'        <property name="name" type="String" container="StaticArray" arraySize="1">',
                            f'          <value>{obj.name}</value>',
                            '        </property>',
                            '        <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">',
                            f'          <value>{self.dataSet}</value>',
                            '        </property>',
                            '        <property name="parent" type="EntityHandle" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="transform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            f'          <value>0x00{obj["transform"]}</value>',
                            '        </property>',
                            '        <property name="shearTransform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="pivotTransform" type="EntityPtr" container="StaticArray" arraySize="1">',
                            '          <value>0x00000000</value>',
                            '        </property>',
                            '        <property name="children" type="EntityHandle" container="List" />',
                            '        <property name="flags" type="uint32" container="StaticArray" arraySize="1">',
                            '          <value>7</value>',
                            '        </property>',
                            '        <property name="modelFile" type="FilePtr" container="StaticArray" arraySize="1">',
                            '          <value>/Assets/pes16/model/bg/common/cornerflag/va_tree001_b0.fmdl</value>',
                            '        </property>',
                            '        <property name="isIsolated" type="bool" container="StaticArray" arraySize="1">',
                            '          <value>false</value>',
                            '        </property>',
                            '        <property name="isDynamic" type="bool" container="StaticArray" arraySize="1">',
                            '          <value>true</value>',
                            '        </property>',
                            '        <property name="lodFarSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>-1</value>',
                            '        </property>',
                            '        <property name="lodNearSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>-1</value>',
                            '        </property>',
                            '        <property name="lodPolygonSize" type="float" container="StaticArray" arraySize="1">',
                            '          <value>1</value>',
                            '        </property>',
                            '        <property name="color" type="Color" container="StaticArray" arraySize="1">',
                            '          <value r="1" g="1" b="1" a="1" />',
                            '        </property>',
                            '        <property name="drawRejectionLevel" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>8</value>',
                            '        </property>',
                            '        <property name="drawMode" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '        <property name="rejectFarRangeShadowCast" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>2</value>',
                            '        </property>',
                            '        <property name="direction" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>5</value>',
                            '        </property>',
                            '        <property name="kind" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>2</value>',
                            '        </property>',
                            '        <property name="demoGroup" type="int32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '        <property name="customBits" type="uint32" container="StaticArray" arraySize="1">',
                            '          <value>0</value>',
                            '        </property>',
                            '      </staticProperties>',
                            '      <dynamicProperties />',
                            '    </entity>',
                            f'    <entity class="TransformEntity" classVersion="0" addr="0x00{obj["transform"]}" unknown1="96" unknown2="0">',
                            '      <staticProperties>',
                            '        <property name="owner" type="EntityHandle" container="StaticArray" arraySize="1">',
                            f'          <value>0x00{obj["addr"]}</value>',
                            '        </property>',
                            '        <property name="transform_scale" type="Vector3" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_scale_x}" y="{object_scale_y}" z="{object_scale_z}" w="0" />',
                            '        </property>',
                            '        <property name="transform_rotation_quat" type="Quat" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_transform_rotation_quat_x}" y="{object_transform_rotation_quat_z}" z="{-object_transform_rotation_quat_y}" w="{object_transform_rotation_quat_w}" />',
                            '        </property>',
                            '        <property name="transform_translation" type="Vector3" container="StaticArray" arraySize="1">',
                            f'          <value x="{object_transform_translation_x}" y="{object_transform_translation_z}" z="{-object_transform_translation_y}" w="0" />',
                            '        </property>',
                            '      </staticProperties>',
                            '      <dynamicProperties />',
                            '    </entity>'
                        ])

                    # Insert the lines after '</entities>'
                    modified_xml_content_entities = (
                        xml_content[:index_insert] +
                        '\n'.join(lines_to_insert_entities) + "\n " +
                        xml_content[index_insert:]
                    )

                    # Write the modified content back to the XML file
                    with open(xml_file_path, 'w') as modified_xml_file:
                        modified_xml_file.write(modified_xml_content_entities)


        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading or modifying XML file: {xml_file_path}, Error: {e}")

    def insert_lines_after_entities(self, xml_file_path):
        try:
            # Read the content of the XML file
            with open(xml_file_path, 'r') as xml_file:
                xml_content = xml_file.read()

                # Find the index of the string '</entities>'
                index_entities = xml_content.find('</entities>')

                if index_entities != -1:
                    # Move one index back to the start of '</entities>'
                    index_insert = index_entities - 1

                    # Define the lines to insert after '</entities>'
                    lines_to_insert_entities = [
                        '   <entity class="StadiumAnime" classVersion="3" addr="0x00001488" unknown1="280" unknown2="0">',
                        '      <staticProperties>',
                        '        <property name="name" type="String" container="StaticArray" arraySize="1">',
                        '          <value>StadiumAnime_Flags</value>',
                        '        </property>',
                        '        <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">',
                        f'          <value>{self.dataSet}</value>',
                        '        </property>',
                        '        <property name="animationGroup" type="int32" container="StaticArray" arraySize="1">',
                        '          <value>10</value>',
                        '        </property>',
                        '        <property name="animeFiles" type="FilePtr" container="DynamicArray" arraySize="1">',
                        '          <value>/Assets/pes16/model/bg/common/cornerflag/dml_mobH_audi_flagbearer_01_mob_prop_teamflag_home01.gani</value>',
                        '        </property>',
                        '        <property name="anmSklFile" type="FilePtr" container="StaticArray" arraySize="1">',
                        '          <value>/Assets/pes16/model/bg/common/cornerflag/mob_prop_teamflag_anim_skel.ask</value>',
                        '        </property>',
                        '        <property name="renderSklFile" type="FilePtr" container="StaticArray" arraySize="1">',
                        '          <value>/Assets/pes16/model/bg/common/cornerflag/mob_prop_teamflag_render_skel.ask</value>',
                        '        </property>',
                        '        <property name="rigFile" type="FilePtr" container="StaticArray" arraySize="1">',
                        '          <value>/Assets/pes16/model/bg/common/cornerflag/mob_prop_teamflag_skel.frig</value>',
                        '        </property>',
                        '        <property name="sklFile" type="FilePtr" container="StaticArray" arraySize="1">',
                        '          <value>/Assets/pes16/model/bg/common/cornerflag/mob_prop_teamflag_home01.skl</value>',
                        '        </property>',
                        '        <property name="models" type="EntityPtr" container="DynamicArray" arraySize="2">',
                    ]

                    # Insert the lines for each obj["addr"] in flag_objects
                    flag_objects = [
                        obj for obj in bpy.context.scene.objects
                        if obj.name.startswith("VA_FLAG_")
                    ]
                    for obj in flag_objects:
                        lines_to_insert_entities.append(f'          <value>0x00{obj["addr"]}</value>')
                        
                    # Complete the remaining lines
                    lines_to_insert_entities += [
                        '        </property>',
                        '      </staticProperties>',
                        '      <dynamicProperties />',
                        '    </entity>'
                    ]

                    # Insert the lines after '</entities>'
                    modified_xml_content_entities = (
                        xml_content[:index_insert] +
                        '\n'.join(lines_to_insert_entities) + "\n" +
                        xml_content[index_insert:]
                    )

                    # Write the modified content back to the XML file
                    with open(xml_file_path, 'w') as modified_xml_file:
                        modified_xml_file.write(modified_xml_content_entities)


        except FileNotFoundError:
            print(f"XML file not found: {xml_file_path}")
        except Exception as e:
            print(f"Error reading or modifying XML file: {xml_file_path}, Error: {e}")

    def edit_fox2_xml(self, context, fox2_location_for_import):
        xml_file_path = f"{fox2_location_for_import}.xml"
        # Create a backup before making modifications
        self.create_backup(context, fox2_location_for_import)

        # Insert lines before </classes>
        self.insert_lines_before_classes(xml_file_path)
        
        # Insert lines inside <entity class="DataList">
        self.insert_lines_inside_DataList(xml_file_path)
        
        # Insert StadiumAnime Handler inside <entity class="DataList">
        self.insert_StadiumAnime(xml_file_path)

        # Get data
        self.get_data_set_value(xml_file_path)

        # Insert lines after </entities>
        self.insert_lines_after_entities(xml_file_path)
        
        # Insert lines for all flag objects
        self.insert_lines_for_flag_objects(xml_file_path)
        
        # Insert lines for all tree "a0" objects
        self.insert_lines_for_tree_a0_objects(xml_file_path)
        
        # Insert lines for all tree "b0" objects
        self.insert_lines_for_tree_b0_objects(xml_file_path)
        
        # Finalizing the file like packing all .dds files and the .fpkd
        self.finalizing(xml_file_path)
        
    def finalizing(self, xml_file_path):
        fox_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "FoxTool", "FoxTool.exe")

        # Check if FoxTool.exe exists
        if not os.path.exists(fox_tool_path):
            print("Error: FoxTool.exe not found.")
            return

        try:
            # Run FoxTool.exe with xml_file_path
            command = [fox_tool_path, xml_file_path]
            subprocess.run(command, check=True)

            print("Operation completed successfully.")

            # Go back 7 directories from xml_file_path
            fpkd_to_repack = os.path.abspath(os.path.join(xml_file_path, "../../../../../../../.."))
            print("fpkd_to_repack:", fpkd_to_repack)

            # Look for a .xml file starting with the name "flagarea_" and ending with ".fpkd.xml"
            fpkd_to_repack_found = None
            for file_name in os.listdir(fpkd_to_repack):
                if file_name.startswith("flagarea_") and file_name.endswith(".fpkd.xml"):
                    fpkd_to_repack_found = os.path.join(fpkd_to_repack, file_name)
                    break

            if fpkd_to_repack_found:
                print("Found .fpkd file:", fpkd_to_repack_found)

                # Get the path to GzsTool.exe
                gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")

                # Check if GzsTool.exe exists
                if os.path.exists(gzs_tool_path):
                    # Run GzsTool.exe to extract the .fpkd file
                    try:
                        command2 = [gzs_tool_path, fpkd_to_repack_found]
                        subprocess.run(command2, check=True)
                        print("GzsTool operation completed successfully.")
                        self.convert_dds()
                    except subprocess.CalledProcessError as e:
                        print(f"Error running GzsTool.exe: {e}")
                else:
                    print("Error: GzsTool.exe not found.")
            else:
                print("Error: .fpkd file not found in the specified directory.")

        except subprocess.CalledProcessError as e:
            print(f"Error running FoxTool.exe: {e}")

    def convert_dds(self):
        # Get the path to FtexTool.exe
        ftex_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "FtexTool", "FtexTool.exe")

        # Ensure ftex_tool_path exists
        if os.path.exists(ftex_tool_path):
            self.report({'INFO'}, "Object files inserted successfully.")
            # Iterate over files in the cornerflag_folder
            for file_name in os.listdir(self.cornerflag_folder):
                if file_name.lower().endswith("_bsm.dds"):
                    file_path = os.path.join(self.cornerflag_folder, file_name)

                    # Construct the command
                    command3 = [ftex_tool_path, "-f", "0", file_path]

                    # Run the command
                    try:
                        subprocess.run(command3, check=True)
                    except subprocess.CalledProcessError as e:
                        print(f"Error running FtexTool.exe on {file_path}: {e}")
        else:
            print("FtexTool.exe not found.")

    def extract_fpkd(self, context):
        # Get the path to GzsTool.exe
        gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")

        # Check if GzsTool.exe exists
        if os.path.exists(gzs_tool_path):
            # Run GzsTool.exe to extract the .fpkd file
            try:
                subprocess.run(self.command, check=True)
                subprocess.run(self.command2, check=True)
                
                # Call insert_object_files with new_fpk_path
                self.insert_object_files(context)
            except subprocess.CalledProcessError as e:
                self.report({'ERROR'}, f"Extraction failed with error: {e}")
        else:
            self.report({'ERROR'}, "GzsTool.exe not found")

    def export_objects(self, context):
        # Extract using GzsTool.exe
        self.extract_fpkd(context)

def draw_func(self, context):
    layout = self.layout
    layout.operator("object.export_objects_operator", text="Export to FLAGAREA")

class OBJECT_OT_AddTreeA0Operator(bpy.types.Operator):
    bl_idname = "object.add_tree_a0_operator"
    bl_label = apply_texture_updater_value

    def execute(self, context):
        # Get the path to the tree model
        script_path = os.path.dirname(os.path.realpath(__file__))
        tree_model_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "va_tree_a0.obj")

        # Check if the file exists
        if not os.path.isfile(tree_model_path):
            self.report({'ERROR'}, "Tree model file not found.")
            return {'CANCELLED'}
            
        # Check if there is a selected object
        selected_object = bpy.context.active_object

        # Check if the "Objects" collection exists, create it if not
        objects_collection = bpy.data.collections.get("Objects")
        if not objects_collection:
            objects_collection = bpy.data.collections.new("Objects")
            bpy.context.scene.collection.children.link(objects_collection)
            
        # Select the "Objects" collection
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["Objects"]

        # Import the tree model
        bpy.ops.import_scene.obj(filepath=tree_model_path)

        # Find the imported object
        imported_object = bpy.context.selected_objects[0] if bpy.context.selected_objects else None
        
        material_name = imported_object.active_material.name

        if imported_object and imported_object.type == 'MESH':
            # Set the object name to "VA_TREE_A0_[0000-9999]" without duplicates
            base_name = "VA_TREE_A0_{:04d}"
            new_name = base_name.format(0)
            while new_name in bpy.data.objects:
                new_name = base_name.format(int(new_name[-4:]) + 1)
            imported_object.name = new_name
            
            # Set rotation mode to quaternions (if possible)
            try:
                imported_object.rotation_mode = 'QUATERNION'
            except AttributeError:
                # If an AttributeError occurs, the object might be None or lack the rotation_mode attribute
                print("Unable to set rotation mode to quaternions. Skipping...")

            # Set the location of the imported object to the active object's location
            active_object = bpy.context.active_object
            if active_object:
                imported_object.location = active_object.location
                imported_object.rotation_quaternion = active_object.rotation_quaternion

            # Set up material nodes for the object
            material = imported_object.data.materials[0] if imported_object.data.materials else bpy.data.materials.new(name="TreeMaterial")
            imported_object.data.materials[0] = material

            material.use_nodes = True
            nodes = material.node_tree.nodes

            # Find existing "Image Texture" nodes and delete them
            image_nodes_to_remove = [node for node in nodes if node.type == 'TEX_IMAGE']
            for node in image_nodes_to_remove:
                nodes.remove(node)

            # Add a new "Image Texture" node
            texture_node = nodes.new(type='ShaderNodeTexImage')
            texture_node.location = (0, 0)

            # Iterate over all materials in the object
            for material in imported_object.data.materials:
                # Set blend mode to 'CLIP' (Alpha Clip)
                material.blend_method = 'CLIP'
            
                # Set up material nodes for the object
                nodes = material.node_tree.nodes

                # Find existing "Image Texture" node or add a new one
                texture_node = None
                for node in nodes:
                    if node.type == 'TEX_IMAGE' and node.image:
                        texture_node = node
                        break

                if texture_node is not None:
                    # Remove existing links to the texture node
                    for link in material.node_tree.links:
                        if link.to_node == texture_node:
                            material.node_tree.links.remove(link)

                    # Remove the existing "Image Texture" node
                    nodes.remove(texture_node)

                # Add a new "Image Texture" node
                texture_node = nodes.new(type='ShaderNodeTexImage')
                texture_node.location = (0, 0)

                # Set the texture path based on the material
                if material.name.startswith("cm059_h_tree018"):
                    texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "tree_tex_001.dds")
                elif material.name.startswith("cm004_bg_tree002_cmem"):
                    texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "tree_tex_002.dds")
                elif material.name.startswith("cm059_h_tree017"):
                    texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "tree_tex_003.dds")

                # Check if the image exists or needs to be created
                image = bpy.data.images.get(texture_path)
                if not image:
                    image = bpy.data.images.load(texture_path)

                # Assign the image to the node
                texture_node.image = image

                # Set the filepath for the node's image
                if texture_node.image:
                    texture_node.image.filepath = texture_path

                # Connect the texture node to the Principled BSDF shader
                principled_bsdf_node = None
                for node in nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        principled_bsdf_node = node
                        break

                if principled_bsdf_node is not None:
                    # Connect the texture node to the shader node
                    material.node_tree.links.new(texture_node.outputs["Color"], principled_bsdf_node.inputs["Base Color"])
                    material.node_tree.links.new(texture_node.outputs["Alpha"], principled_bsdf_node.inputs["Alpha"])

            # Set custom properties directly on the object
            object_id = int(imported_object.name[-4:])
            imported_object["addr"] = 400000 + object_id
            imported_object["transform"] = 410000 + object_id
            imported_object["dataSet"] = 0x02D72BD0
            imported_object["objectType"] = "A0"
            
            message_info1 = imported_object["addr"]
            message_info2 = imported_object["transform"]
            
            hex_dataSet = hex(imported_object["dataSet"])[2:]  # Remove '0x' prefix
            message_info3 = hex_dataSet
            
            message_info4 = imported_object["objectType"]
            
            # Set the imported object as the active object
            bpy.context.view_layer.objects.active = imported_object

            # Use the selected_texture_name and selected_texture_path as needed
            print(f"Selected Texture: {context.scene.addOBJ_tex_filename}")
            print(f"Selected Texture Path: {context.scene.addOBJ_tex_filepath}")
            
            print(f'''Initializing Values addr="{message_info1}", transform="{message_info2}", dataset= "0x0{message_info3}", objectType="{message_info4}"''')

        return {'FINISHED'}
        
class OBJECT_OT_AddTreeB0Operator(bpy.types.Operator):
    bl_idname = "object.add_tree_b0_operator"
    bl_label = apply_texture_updater_value

    def execute(self, context):
        # Get the path to the tree model
        script_path = os.path.dirname(os.path.realpath(__file__))
        tree_model_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "va_tree_b0.obj")

        # Check if the file exists
        if not os.path.isfile(tree_model_path):
            self.report({'ERROR'}, "Tree model file not found.")
            return {'CANCELLED'}
            
        # Check if there is a selected object
        selected_object = bpy.context.active_object

        # Check if the "Objects" collection exists, create it if not
        objects_collection = bpy.data.collections.get("Objects")
        if not objects_collection:
            objects_collection = bpy.data.collections.new("Objects")
            bpy.context.scene.collection.children.link(objects_collection)
            
        # Select the "Objects" collection
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["Objects"]

        # Import the tree model
        bpy.ops.import_scene.obj(filepath=tree_model_path)

        # Find the imported object
        imported_object = bpy.context.selected_objects[0] if bpy.context.selected_objects else None
        
        material_name = imported_object.active_material.name

        if imported_object and imported_object.type == 'MESH':
            # Set the object name to "VA_TREE_B0_[0000-9999]" without duplicates
            base_name = "VA_TREE_B0_{:04d}"
            new_name = base_name.format(0)
            while new_name in bpy.data.objects:
                new_name = base_name.format(int(new_name[-4:]) + 1)
            imported_object.name = new_name
            
            # Set rotation mode to quaternions (if possible)
            try:
                imported_object.rotation_mode = 'QUATERNION'
            except AttributeError:
                # If an AttributeError occurs, the object might be None or lack the rotation_mode attribute
                print("Unable to set rotation mode to quaternions. Skipping...")

            # Set the location of the imported object to the active object's location
            active_object = bpy.context.active_object
            if active_object:
                imported_object.location = active_object.location
                imported_object.rotation_quaternion = active_object.rotation_quaternion

            # Set up material nodes for the object
            material = imported_object.data.materials[0] if imported_object.data.materials else bpy.data.materials.new(name="TreeMaterial")
            imported_object.data.materials[0] = material

            material.use_nodes = True
            nodes = material.node_tree.nodes

            # Find existing "Image Texture" nodes and delete them
            image_nodes_to_remove = [node for node in nodes if node.type == 'TEX_IMAGE']
            for node in image_nodes_to_remove:
                nodes.remove(node)

            # Add a new "Image Texture" node
            texture_node = nodes.new(type='ShaderNodeTexImage')
            texture_node.location = (0, 0)

            # Iterate over all materials in the object
            for material in imported_object.data.materials:
                # Set blend mode to 'CLIP' (Alpha Clip)
                material.blend_method = 'CLIP'
            
                # Set up material nodes for the object
                nodes = material.node_tree.nodes

                # Find existing "Image Texture" node or add a new one
                texture_node = None
                for node in nodes:
                    if node.type == 'TEX_IMAGE' and node.image:
                        texture_node = node
                        break

                if texture_node is not None:
                    # Remove existing links to the texture node
                    for link in material.node_tree.links:
                        if link.to_node == texture_node:
                            material.node_tree.links.remove(link)

                    # Remove the existing "Image Texture" node
                    nodes.remove(texture_node)

                # Add a new "Image Texture" node
                texture_node = nodes.new(type='ShaderNodeTexImage')
                texture_node.location = (0, 0)

                # Set the texture path based on the material
                if material.name.startswith("cm059_h_tree018"):
                    texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "tree_tex_001.dds")
                elif material.name.startswith("cm004_bg_tree002_cmem"):
                    texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "tree_tex_002.dds")
                elif material.name.startswith("cm059_h_tree017"):
                    texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_tree", "tree_tex_003.dds")

                # Check if the image exists or needs to be created
                image = bpy.data.images.get(texture_path)
                if not image:
                    image = bpy.data.images.load(texture_path)

                # Assign the image to the node
                texture_node.image = image

                # Set the filepath for the node's image
                if texture_node.image:
                    texture_node.image.filepath = texture_path

                # Connect the texture node to the Principled BSDF shader
                principled_bsdf_node = None
                for node in nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        principled_bsdf_node = node
                        break

                if principled_bsdf_node is not None:
                    # Connect the texture node to the shader node
                    material.node_tree.links.new(texture_node.outputs["Color"], principled_bsdf_node.inputs["Base Color"])
                    material.node_tree.links.new(texture_node.outputs["Alpha"], principled_bsdf_node.inputs["Alpha"])

            # Set custom properties directly on the object
            object_id = int(imported_object.name[-4:])
            imported_object["addr"] = 500000 + object_id
            imported_object["transform"] = 510000 + object_id
            imported_object["dataSet"] = 0x02D72BD0
            imported_object["objectType"] = "B0"
            
            message_info1 = imported_object["addr"]
            message_info2 = imported_object["transform"]
            
            hex_dataSet = hex(imported_object["dataSet"])[2:]  # Remove '0x' prefix
            message_info3 = hex_dataSet
            
            message_info4 = imported_object["objectType"]
            
            # Set the imported object as the active object
            bpy.context.view_layer.objects.active = imported_object

            # Use the selected_texture_name and selected_texture_path as needed
            print(f"Selected Texture: {context.scene.addOBJ_tex_filename}")
            print(f"Selected Texture Path: {context.scene.addOBJ_tex_filepath}")
            
            print(f'''Initializing Values addr="{message_info1}", transform="{message_info2}", dataset= "0x0{message_info3}", objectType="{message_info4}"''')

        return {'FINISHED'}

class OBJECT_OT_AddWavingFlagAOperator(bpy.types.Operator):
    bl_idname = "object.add_waving_flag_a_operator"
    bl_label = apply_texture_updater_value
    
    # Set default flag .dds if imported without texture       
    script_path = os.path.dirname(os.path.realpath(__file__))
    default_texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", "default_flag.dds")
    
    print(f"{default_texture_path}")

    def execute(self, context):
        # Get the path to the flag model
        script_path = os.path.dirname(os.path.realpath(__file__))
        flag_model_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", "flagmodel.obj")

        # Check if the file exists
        if not os.path.isfile(flag_model_path):
            self.report({'ERROR'}, "Flag model file not found.")
            return {'CANCELLED'}
            
        # Check if there is a selected object
        selected_object = bpy.context.active_object

        # Check if the "Objects" collection exists, create it if not
        objects_collection = bpy.data.collections.get("Objects")
        if not objects_collection:
            objects_collection = bpy.data.collections.new("Objects")
            bpy.context.scene.collection.children.link(objects_collection)
            
        # Select the "Objects" collection
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["Objects"]

        # Import the flag model
        bpy.ops.import_scene.obj(filepath=flag_model_path)

        # Find the imported object
        imported_object = bpy.context.selected_objects[0] if bpy.context.selected_objects else None

        if imported_object and imported_object.type == 'MESH':
            # Set the object name to "VA_FLAG_[0000-9999]" without duplicates
            base_name = "VA_FLAG_{:04d}"
            new_name = base_name.format(0)
            while new_name in bpy.data.objects:
                new_name = base_name.format(int(new_name[-4:]) + 1)
            imported_object.name = new_name
            
            # Set rotation mode to quaternions (if possible)
            try:
                imported_object.rotation_mode = 'QUATERNION'
            except AttributeError:
                # If an AttributeError occurs, the object might be None or lack the rotation_mode attribute
                print("Unable to set rotation mode to quaternions. Skipping...")

            # Set the location of the imported object to the active object's location
            active_object = bpy.context.active_object
            if active_object:
                imported_object.location = active_object.location
                imported_object.rotation_quaternion = active_object.rotation_quaternion

            # Set up material nodes for the object
            material = imported_object.data.materials[0] if imported_object.data.materials else bpy.data.materials.new(name="FlagMaterial")
            imported_object.data.materials[0] = material

            material.use_nodes = True
            nodes = material.node_tree.nodes

            # Find existing "Image Texture" node or add a new one
            texture_node = None
            for node in nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    texture_node = node
                    break

            if texture_node is not None:
                # Remove existing links to the texture node
                for link in material.node_tree.links:
                    if link.to_node == texture_node:
                        material.node_tree.links.remove(link)

                # Remove the existing "Image Texture" node
                nodes.remove(texture_node)

            # Add a new "Image Texture" node
            texture_node = nodes.new(type='ShaderNodeTexImage')
            texture_node.location = (0, 0)
            
            default_texture_path = os.path.join(context.scene.addOBJ_tex_filepath, context.scene.addOBJ_tex_filename)

            # Check if the default texture file exists
            if os.path.isfile(default_texture_path):
                texture = bpy.data.images.load(default_texture_path)
                texture_node.image = texture

            # Connect the "Image Texture" node to the "Base Color" input
            shader_node = None
            for node in nodes:
                if node.type == 'BSDF_PRINCIPLED':
                    shader_node = node
                    break

            if shader_node is not None:
                # Connect the texture node to the shader node
                material.node_tree.links.new(texture_node.outputs["Color"], shader_node.inputs["Base Color"])

            # Set custom properties directly on the object
            object_id = int(imported_object.name[-4:])
            imported_object["addr"] = 300000 + object_id
            imported_object["transform"] = 310000 + object_id
            imported_object["dataSet"] = 0x02D72BD0
            imported_object["objectType"] = 0
            
            message_info1 = imported_object["addr"]
            message_info2 = imported_object["transform"]
            
            hex_dataSet = hex(imported_object["dataSet"])[2:]  # Remove '0x' prefix
            message_info3 = hex_dataSet
            
            message_info4 = imported_object["objectType"]
            
            imported_object.scale = (0.7, 0.7, 0.7)
            
            # Set the imported object as the active object
            bpy.context.view_layer.objects.active = imported_object            

            # Use the selected_texture_name and selected_texture_path as needed
            print(f"Selected Texture: {context.scene.addOBJ_tex_filename}")
            print(f"Selected Texture Path: {context.scene.addOBJ_tex_filepath}")
            
            print(f'''Initializing Values addr="{message_info1}", transform="{message_info2}", dataset= "0x0{message_info3}", objectType="{message_info4}"''')

        return {'FINISHED'}
        
class OBJECT_OT_AddWavingFlagCOperator(bpy.types.Operator):
    bl_idname = "object.add_waving_flag_c_operator"
    bl_label = apply_texture_updater_value
    
    # Set default flag .dds if imported without texture       
    script_path = os.path.dirname(os.path.realpath(__file__))
    default_texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", "default_flag.dds")
    
    print(f"{default_texture_path}")

    def execute(self, context):
        # Get the path to the flag model
        script_path = os.path.dirname(os.path.realpath(__file__))
        flag_model_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", "flagmodel.obj")

        # Check if the file exists
        if not os.path.isfile(flag_model_path):
            self.report({'ERROR'}, "Flag model file not found.")
            return {'CANCELLED'}
            
        # Check if there is a selected object
        selected_object = bpy.context.active_object

        # Check if the "Objects" collection exists, create it if not
        objects_collection = bpy.data.collections.get("Objects")
        if not objects_collection:
            objects_collection = bpy.data.collections.new("Objects")
            bpy.context.scene.collection.children.link(objects_collection)
            
        # Select the "Objects" collection
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["Objects"]

        # Import the flag model
        bpy.ops.import_scene.obj(filepath=flag_model_path)

        # Find the imported object
        imported_object = bpy.context.selected_objects[0] if bpy.context.selected_objects else None

        if imported_object and imported_object.type == 'MESH':
            # Set the object name to "VA_FLAG_[0000-9999]" without duplicates
            base_name = "VA_FLAG_{:04d}"
            new_name = base_name.format(0)
            while new_name in bpy.data.objects:
                new_name = base_name.format(int(new_name[-4:]) + 1)
            imported_object.name = new_name
            
            # Set rotation mode to quaternions (if possible)
            try:
                imported_object.rotation_mode = 'QUATERNION'
            except AttributeError:
                # If an AttributeError occurs, the object might be None or lack the rotation_mode attribute
                print("Unable to set rotation mode to quaternions. Skipping...")

            # Set the location of the imported object to the active object's location
            active_object = bpy.context.active_object
            if active_object:
                imported_object.location = active_object.location
                imported_object.rotation_quaternion = active_object.rotation_quaternion

            # Set up material nodes for the object
            material = imported_object.data.materials[0] if imported_object.data.materials else bpy.data.materials.new(name="FlagMaterial")
            imported_object.data.materials[0] = material

            material.use_nodes = True
            nodes = material.node_tree.nodes

            # Find existing "Image Texture" node or add a new one
            texture_node = None
            for node in nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    texture_node = node
                    break

            if texture_node is not None:
                # Remove existing links to the texture node
                for link in material.node_tree.links:
                    if link.to_node == texture_node:
                        material.node_tree.links.remove(link)

                # Remove the existing "Image Texture" node
                nodes.remove(texture_node)

            # Add a new "Image Texture" node
            texture_node = nodes.new(type='ShaderNodeTexImage')
            texture_node.location = (0, 0)
            
            default_texture_path = os.path.join(context.scene.addOBJ_tex_filepath, context.scene.addOBJ_tex_filename)

            # Check if the default texture file exists
            if os.path.isfile(default_texture_path):
                texture = bpy.data.images.load(default_texture_path)
                texture_node.image = texture

            # Connect the "Image Texture" node to the "Base Color" input
            shader_node = None
            for node in nodes:
                if node.type == 'BSDF_PRINCIPLED':
                    shader_node = node
                    break

            if shader_node is not None:
                # Connect the texture node to the shader node
                material.node_tree.links.new(texture_node.outputs["Color"], shader_node.inputs["Base Color"])

            # Set custom properties directly on the object
            object_id = int(imported_object.name[-4:])
            imported_object["addr"] = 300000 + object_id
            imported_object["transform"] = 310000 + object_id
            imported_object["dataSet"] = 0x02D72BD0
            imported_object["objectType"] = 1
            
            message_info1 = imported_object["addr"]
            message_info2 = imported_object["transform"]
            
            hex_dataSet = hex(imported_object["dataSet"])[2:]  # Remove '0x' prefix
            message_info3 = hex_dataSet
            
            message_info4 = imported_object["objectType"]
            
            imported_object.scale = (0.7 * 1.5, 0.7 * 1.5, 0.7 * 1.5)
            
            # Set the imported object as the active object
            bpy.context.view_layer.objects.active = imported_object

            # Use the selected_texture_name and selected_texture_path as needed
            print(f"Selected Texture: {context.scene.addOBJ_tex_filename}")
            print(f"Selected Texture Path: {context.scene.addOBJ_tex_filepath}")
            
            print(f'''Initializing Values addr="{message_info1}", transform="{message_info2}", dataset= "0x0{message_info3}", objectType="{message_info4}"''')

        return {'FINISHED'}
        
class OBJECT_OT_AddWavingFlagDOperator(bpy.types.Operator):
    bl_idname = "object.add_waving_flag_d_operator"
    bl_label = apply_texture_updater_value
    
    # Set default flag .dds if imported without texture       
    script_path = os.path.dirname(os.path.realpath(__file__))
    default_texture_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", "default_flag.dds")
    
    print(f"{default_texture_path}")

    def execute(self, context):
        # Get the path to the flag model
        script_path = os.path.dirname(os.path.realpath(__file__))
        flag_model_path = os.path.join(script_path, "resources-peslightmanager", "Objects", "va_flag_001", "flagmodel.obj")

        # Check if the file exists
        if not os.path.isfile(flag_model_path):
            self.report({'ERROR'}, "Flag model file not found.")
            return {'CANCELLED'}

        # Check if there is a selected object
        selected_object = bpy.context.active_object

        # Check if the "Objects" collection exists, create it if not
        objects_collection = bpy.data.collections.get("Objects")
        if not objects_collection:
            objects_collection = bpy.data.collections.new("Objects")
            bpy.context.scene.collection.children.link(objects_collection)

        # Select the "Objects" collection
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["Objects"]

        # Import the flag model
        bpy.ops.import_scene.obj(filepath=flag_model_path, filter_glob="*.obj;*.mtl")

        # Find the imported object
        imported_object = bpy.context.selected_objects[0] if bpy.context.selected_objects else None

        if imported_object and imported_object.type == 'MESH':
            # Set the object name to "VA_FLAG_[0000-9999]" without duplicates
            base_name = "VA_FLAG_{:04d}"
            new_name = base_name.format(0)
            while new_name in bpy.data.objects:
                new_name = base_name.format(int(new_name[-4:]) + 1)
            imported_object.name = new_name

            # Set rotation mode to quaternions (if possible)
            try:
                imported_object.rotation_mode = 'QUATERNION'
            except AttributeError:
                # If an AttributeError occurs, the object might be None or lack the rotation_mode attribute
                print("Unable to set rotation mode to quaternions. Skipping...")

            # Set the location of the imported object to the active object's location
            active_object = bpy.context.active_object
            if active_object:
                imported_object.location = active_object.location
                imported_object.rotation_quaternion = active_object.rotation_quaternion

            # Set the location of the imported object to the active object's location
            active_object = bpy.context.active_object
            if active_object:
                imported_object.location = active_object.location

            # Set up material nodes for the object
            material = imported_object.data.materials[0] if imported_object.data.materials else bpy.data.materials.new(name="FlagMaterial")
            imported_object.data.materials[0] = material

            material.use_nodes = True
            nodes = material.node_tree.nodes

            # Find existing "Image Texture" node or add a new one
            texture_node = None
            for node in nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    texture_node = node
                    break

            if texture_node is not None:
                # Remove existing links to the texture node
                for link in material.node_tree.links:
                    if link.to_node == texture_node:
                        material.node_tree.links.remove(link)

                # Remove the existing "Image Texture" node
                nodes.remove(texture_node)

            # Add a new "Image Texture" node
            texture_node = nodes.new(type='ShaderNodeTexImage')
            texture_node.location = (0, 0)
            
            default_texture_path = os.path.join(context.scene.addOBJ_tex_filepath, context.scene.addOBJ_tex_filename)

            # Check if the default texture file exists
            if os.path.isfile(default_texture_path):
                texture = bpy.data.images.load(default_texture_path)
                texture_node.image = texture

            # Connect the "Image Texture" node to the "Base Color" input
            shader_node = None
            for node in nodes:
                if node.type == 'BSDF_PRINCIPLED':
                    shader_node = node
                    break

            if shader_node is not None:
                # Connect the texture node to the shader node
                material.node_tree.links.new(texture_node.outputs["Color"], shader_node.inputs["Base Color"])

            # Set custom properties directly on the object
            object_id = int(imported_object.name[-4:])
            imported_object["addr"] = 300000 + object_id
            imported_object["transform"] = 310000 + object_id
            imported_object["dataSet"] = 0x02D72BD0
            imported_object["objectType"] = 2
            
            message_info1 = imported_object["addr"]
            message_info2 = imported_object["transform"]
            
            hex_dataSet = hex(imported_object["dataSet"])[2:]  # Remove '0x' prefix
            message_info3 = hex_dataSet
            
            message_info4 = imported_object["objectType"]
            
            imported_object.scale = (0.7 / 1.2, 0.7 / 1.2, 0.7 / 1.2)
            
            # Set the imported object as the active object
            bpy.context.view_layer.objects.active = imported_object

            # Use the selected_texture_name and selected_texture_path as needed
            print(f"Selected Texture: {context.scene.addOBJ_tex_filename}")
            print(f"Selected Texture Path: {context.scene.addOBJ_tex_filepath}")
            
            print(f'''Initializing Values addr="{message_info1}", transform="{message_info2}", dataset= "0x0{message_info3}", objectType="{message_info4}"''')

        return {'FINISHED'}
        
def update_texture_properties(self, context):
    # Trigger a redraw of the UI when texture properties are updated
    self.tag_redraw()

class OBJECT_OT_Function4ExecuteOperator(bpy.types.Operator):
    bl_idname = "object.add_waving_flag_execute_operator"
    bl_label = "Select Texture for Flag Material"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext2 = ".dds"
    filepath: bpy.props.StringProperty(subtype='FILE_PATH', options={'HIDDEN'}, update=update_texture_properties)

    def execute(self, context):
        context.scene.addOBJ_label_text = f"Current Flag Texture Selected: {context.scene.addOBJ_tex_filename}"
        file_ext2 = os.path.splitext(self.filepath)[1].lower()

        if file_ext2 == self.filename_ext2:
            # Set the uploaded texture file name to a custom property
            context.scene.addOBJ_tex_filename = os.path.basename(self.filepath)

            # Set the directory property to the directory of the uploaded file
            context.scene.addOBJ_tex_filepath = os.path.dirname(self.filepath)

            self.report({'INFO'}, f"Uploaded Texture: {self.filepath}")

            # Apply the texture to all currently selected objects
            selected_objects = bpy.context.selected_objects
            for obj in selected_objects:
                self.apply_texture_to_object(context, context.scene, obj)

            apply_texture_updater_value = context.scene.addOBJ_tex_filename

            # Reopen the "Add Objects" popup using popup_menu()
            bpy.ops.object.function4_operator('INVOKE_DEFAULT')

            context.scene.addOBJ_label_text = f"Current Flag Texture Selected: {context.scene.addOBJ_tex_filename}"

            print(context.scene.addOBJ_label_text)

        return {'FINISHED'}

    def invoke(self, context, event):
        # Open file browser
        wm = context.window_manager
        wm.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout

        # Display selected texture information
        layout.label(text=f"Uploaded Texture: {context.scene.addOBJ_tex_filename}")
        layout.prop(context.scene, "addOBJ_tex_filepath", text="Export Path:")
        
    def apply_texture_to_object(self, context, scene, obj):
        if obj and obj.type == 'MESH':
            # Check if the object has the custom property "objectType" with a value of 3 or 4
            object_type = obj.get("objectType")
            if object_type in ["A0", "B0"]:
                # Display a warning message and exit the method
                self.report({'WARNING'}, "You cannot apply textures to trees.")
                return
            # Set up material nodes for the object
            material = obj.data.materials[0] if obj.data.materials else bpy.data.materials.new(name="FlagMaterial")
            obj.data.materials[0] = material

            material.use_nodes = True
            nodes = material.node_tree.nodes

            # Find existing "Image Texture" node or add a new one
            texture_node = None
            for node in nodes:
                if node.type == 'TEX_IMAGE' and node.image:
                    texture_node = node
                    break

            if texture_node is not None:
                # Remove existing links to the texture node
                for link in material.node_tree.links:
                    if link.to_node == texture_node:
                        material.node_tree.links.remove(link)

                # Remove the existing "Image Texture" node
                nodes.remove(texture_node)

            # Add a new "Image Texture" node
            texture_node = nodes.new(type='ShaderNodeTexImage')
            texture_node.location = (-1000, 0)

            default_texture_path = os.path.join(scene.addOBJ_tex_filepath, scene.addOBJ_tex_filename)

            # Check if the default texture file exists
            if os.path.isfile(default_texture_path):
                texture = bpy.data.images.load(default_texture_path)
                texture_node.image = texture

            # Connect the "Image Texture" node to the "Base Color" input
            shader_node = None
            for node in nodes:
                if node.type == 'BSDF_PRINCIPLED':
                    shader_node = node
                    break

            if shader_node is not None:
                # Connect the texture node to the shader node
                material.node_tree.links.new(texture_node.outputs["Color"], shader_node.inputs["Base Color"])
        
def update_texture_filename(self, context):
    context.scene.addOBJ_label_text = f"Current Flag Texture Selected: {context.scene.addOBJ_tex_filename}"

class OBJECT_OT_ChangeSpotlightOperator(bpy.types.Operator):
    bl_idname = "object.change_spotlight"
    bl_label = "Change Spotlight"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        # Run your update functions here
        self.update_properties_from_selected(context)
        self.update_location_from_selected(context)
        self.update_rotation_from_selected(context)

        # Invoke the dialog
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=600)

    def draw(self, context):
        layout = self.layout

        # Display the input field for SpotID
        layout.prop(context.scene, "spot_id_input")

        # Separator
        layout.separator()

        # Checkbox to apply properties from selected SpotLight
        layout.prop(context.scene, "apply_properties_from_selected", text="Apply properties from currently selected SpotLight", toggle=False)

        # Additional properties for the new SpotLight
        self.custom_prop(layout, context.scene, "temperature", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "castShadow", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "isBounced", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "enable", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "power", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "new_spotlight_umbraAngle", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "new_spotlight_penumbraAngle", not context.scene.update_properties_checked)

        # Color property
        self.custom_prop(layout, context.scene, "spotlight_color", text="Color", enable=not context.scene.update_color_checked)

        # Separator
        layout.separator()

        # Text label for rotation
        layout.label(text="Rotation:")
        layout.prop(context.scene, "apply_rotation_from_selected", text="Apply rotation from currently selected SpotLight", toggle=False)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=0, text="W", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=1, text="X", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=2, text="Y", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=3, text="Z", enable=not context.scene.update_rotation_checked)

        # Separator
        layout.separator()

        # Button to apply changes
        layout.operator("object.apply_changes_operator", text="Apply Changes")

    def custom_prop(self, layout, scene, prop_name, enable=True, **kwargs):
        row = layout.row()
        row.prop(scene, prop_name, **kwargs)
        if not enable:
            row.enabled = False

    def update_properties_from_selected(self, context):
        print("Updating properties from selected - 2")
        if context.scene.apply_properties_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.temperature = selected_spotlight["temperature"]
                context.scene.castShadow = selected_spotlight["castShadow"]
                context.scene.isBounced = selected_spotlight["isBounced"]
                context.scene.enable = selected_spotlight["enable"]
                context.scene.power = selected_spotlight.data.energy
                context.scene.new_spotlight_umbraAngle = math.degrees(selected_spotlight.data.spot_size)
                context.scene.new_spotlight_penumbraAngle = selected_spotlight.data.spot_blend
                context.scene.spotlight_color = selected_spotlight.data.color

    def update_location_from_selected(self, context):
        print("Updating location from selected - 2")
        if context.scene.apply_location_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.add_spotlight_location[0] = selected_spotlight.location.x
                context.scene.add_spotlight_location[1] = selected_spotlight.location.y
                context.scene.add_spotlight_location[2] = selected_spotlight.location.z

    def update_rotation_from_selected(self, context):
        print("Updating rotation from selected - 2")
        if context.scene.apply_rotation_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.add_spotlight_rotation[0] = selected_spotlight.rotation_quaternion[0]
                context.scene.add_spotlight_rotation[1] = selected_spotlight.rotation_quaternion[1]
                context.scene.add_spotlight_rotation[2] = selected_spotlight.rotation_quaternion[2]
                context.scene.add_spotlight_rotation[3] = selected_spotlight.rotation_quaternion[3]

class OBJECT_OT_ApplyPropertiesToSelectedOperator(bpy.types.Operator):
    bl_idname = "object.apply_properties_to_selected"
    bl_label = "Apply Properties to Selected SpotLights"

    def execute(self, context):
        # Get the selected objects
        selected_objects = bpy.context.selected_objects
        
        for spot_light in selected_objects:
            if spot_light.type == 'LIGHT' and spot_light.data.type == 'SPOT':
                # Set custom properties for the SpotLight
                if context.scene.my_properties.temperature_checked:
                    spot_light["temperature"] = context.scene.temperature

                if context.scene.my_properties.castShadow_checked:
                    spot_light["castShadow"] = context.scene.castShadow

                if context.scene.my_properties.enable_checked:
                    spot_light["enable"] = context.scene.enable

                # Convert radians to degrees
                umbra_angle_degrees = math.degrees(context.scene.new_spotlight_umbraAngle)
                penumbra_angle_degrees = math.degrees(context.scene.new_spotlight_penumbraAngle)

                if context.scene.my_properties.new_spotlight_umbraAngle_checked:
                    # Set spot shape size (Spot Size) - convert from degrees to radians
                    spot_light.data.spot_size = math.radians(context.scene.new_spotlight_umbraAngle)

                if context.scene.my_properties.new_spotlight_penumbraAngle_checked:
                    # Set spot blend using new_spotlight_penumbraAngle (converted to degrees)
                    spot_light.data.spot_blend = context.scene.new_spotlight_penumbraAngle

                if context.scene.my_properties.power_checked:
                    # Set power to the user-input value
                    spot_light.data.energy = context.scene.power

                if context.scene.my_properties.add_spotlight_rotation_checked:
                    # Set rotation values
                    rotation_quaternion = (
                        context.scene.add_spotlight_rotation[0],
                        context.scene.add_spotlight_rotation[1],
                        context.scene.add_spotlight_rotation[2],
                        context.scene.add_spotlight_rotation[3]
                    )

                # Set rotation mode to QUATERNION
                spot_light.rotation_mode = 'QUATERNION'

                if context.scene.my_properties.add_spotlight_rotation_checked:
                    # Assign the rotation directly
                    spot_light.rotation_quaternion = rotation_quaternion

                if context.scene.my_properties.spotlight_color_checked:
                    # Assign color to the SpotLight
                    color_values = context.scene.spotlight_color
                    spot_light.data.color = color_values
                    
                if all(not getattr(context.scene.my_properties, f"{prop}_checked") for prop in ["temperature", "castShadow", "enable", "new_spotlight_umbraAngle", "new_spotlight_penumbraAngle", "power", "add_spotlight_rotation", "spotlight_color"]):
                    self.report({'INFO'}, "Please select a value you wish to change on all currently selected SpotLights by ticking the checkboxes.")
                    return {'CANCELLED'}

        return {'FINISHED'}

def invoke_apply_properties_to_selected(self, context, event):
    return context.window_manager.invoke_props_dialog(self)

class SCENE_PT_spotlight_analyzer_panel(bpy.types.Panel):
    bl_label = "PES Lightmanager for PES 2020 / 2021"
    bl_idname = "PT_lightmanager_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout

        # Use the loaded icon if it exists
        custom_icon = icons_collection.get("titleimg")
        if custom_icon:
            # Create a row to center-align the box
            row = layout.row(align=True)
            
            # Create a box for the icons within the row
            box = row.box()

            # Add a label with the icon
            box.label(text="PES Lightmanager (v. 0.2.0d)", icon_value=custom_icon.icon_id)
            box.label(text="- Made by DAV on evoweb.com -")
        else:
            layout.label(text="Icon not found")

        # Upload XML button
        layout.operator("object.upload_xml")

        # Display the uploaded XML file name
        layout.label(text=f"Uploaded XML: {getattr(context.scene, 'uploaded_xml_name', 'None')}")

        # Create a horizontal row
        row = layout.row()

        # Export Button
        row.operator("object.save_xml", text="Export Lights")

        # Revert Button
        row.operator("object.revert_xml_operator", text="", icon='PLAY_REVERSE')

        # Display selected and total spotlight amounts
        layout.label(text=f"{context.scene.get('selected_spotlights_amount', 0)} / {context.scene.get('total_spotlights_amount', 0)} selected for Export")

        # Automatically populated "Export Path" field
        layout.prop(context.scene, "uploaded_xml_directory", text="Export Path:")
        
        layout.operator("object.add_spotlight")
        
        # Create a horizontal row
        row = layout.row()

        # Export Button
        row.operator("object.my_operator")

        # Add a "Tools" button in the same row
        row.operator("object.open_tools", text="", icon='TOOL_SETTINGS')  # Replace 'TOOL_SETTINGS' with the correct identifier

        # Access the global list where your script stores the values
        spotlight_values = context.scene.spotlight_values

        if spotlight_values:
            # Display the analyzed spotlight values in a box
            box = layout.box()
            box.label(text="Spotlight Values:")

            # Modify your draw function to include the show_details property
            for i, values in enumerate(spotlight_values):
                if i > 0:
                    # Add a separator after each group of values (except the first one)
                    box.separator()

                # Create a collapsible box for each spotlight
                sub_box = box.box()
                sub_box.label(text=f"Object: {values.object_name}", icon='OUTLINER_OB_LIGHT')

                # Create a separate box for smaller font labels
                sub_sub_box = sub_box.box()
                sub_sub_box.scale_y = 0.5  # Adjust the scale to make the text smaller

                # Display details in the collapsible box with smaller font size
                sub_sub_box.label(text=f"HEX Address: {values.addr}")
                sub_sub_box.label(text=f"HEX Address (transform): {values.transform}")

                # Check if the box should be expanded or collapsed
                if values.show_details:
                    sub_box.prop(values, "show_details", icon='TRIA_DOWN', icon_only=True, emboss=False)

                    # Create a sub-column for smaller font size
                    sub_col = sub_box.column(align=True)
                    sub_col.label(text=f"Color: {values.color}")
                    sub_col.label(text=f"Power (lumen): {values.lumen}")
                    sub_col.label(text=f"Size (umbraAngle): {values.umbraAngle}")
                    sub_col.label(text=f"Penumbra Angle: {values.penumbraAngle}")
                    sub_col.label(text=f"Temperature: {values.temperature}")
                    sub_col.label(text=f"Transform Translation: {values.transform_translation}")
                    sub_col.label(text=f"Transform Rotation Quaternion: {values.transform_rotation_quat}")
                    sub_col.label(text=f"Cast Shadow?: {values.castShadow}")
                    sub_col.label(text=f"Bounce Lights?: {values.isBounced}")
                    sub_col.label(text=f"Enabled?: {values.enabled}")
                    
                else:
                    sub_box.prop(values, "show_details", icon='TRIA_RIGHT', icon_only=True, emboss=False)
                    continue  # Skip drawing details if not expanded
        else:
            layout.label(text="No spotlight values found.")

def update_properties_from_selected(self, context):
    # Toggle the boolean property
    if context.scene.update_properties_checked:
        context.scene.update_properties_checked = False
    else:
        context.scene.update_properties_checked = True
    print(f"Check For Properties on Selected Object: {context.scene.update_properties_checked}")
    if context.scene.apply_properties_from_selected:
        selected_spotlight = context.active_object
        if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
            context.scene.temperature = selected_spotlight["temperature"]
            context.scene.castShadow = selected_spotlight["castShadow"]
            context.scene.isBounced = selected_spotlight["isBounced"]
            context.scene.enable = selected_spotlight["enable"]
            context.scene.power = selected_spotlight.data.energy
            context.scene.new_spotlight_umbraAngle = math.degrees(selected_spotlight.data.spot_size)
            context.scene.new_spotlight_penumbraAngle = selected_spotlight.data.spot_blend
            context.scene.spotlight_color = selected_spotlight.data.color
            
def update_location_from_selected(self, context):
    # Toggle the boolean property
    if context.scene.update_location_checked:
        context.scene.update_location_checked = False
    else:
        context.scene.update_location_checked = True
    print(f"Check For Location on Selected Object: {context.scene.update_location_checked}")
    if context.scene.apply_location_from_selected:
        selected_spotlight = context.active_object
        if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
            context.scene.add_spotlight_location[0] = selected_spotlight.location.x
            context.scene.add_spotlight_location[1] = selected_spotlight.location.y
            context.scene.add_spotlight_location[2] = selected_spotlight.location.z

def update_rotation_from_selected(self, context):
    # Toggle the boolean property
    if context.scene.update_rotation_checked:
        context.scene.update_rotation_checked = False
    else:
        context.scene.update_rotation_checked = True
    print(f"Check For Rotation on Selected Object: {context.scene.update_rotation_checked}")
    if context.scene.apply_rotation_from_selected:
        selected_spotlight = context.active_object
        if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
            context.scene.add_spotlight_rotation[0] = selected_spotlight.rotation_quaternion[0]
            context.scene.add_spotlight_rotation[1] = selected_spotlight.rotation_quaternion[1]
            context.scene.add_spotlight_rotation[2] = selected_spotlight.rotation_quaternion[2]
            context.scene.add_spotlight_rotation[3] = selected_spotlight.rotation_quaternion[3]

class OBJECT_OT_AddSpotlightOperator(bpy.types.Operator):
    bl_idname = "object.add_spotlight"
    bl_label = "Add SpotLight"

    # Register the update function for the Scene type
    bpy.types.Scene.update_properties_from_selected = bpy.props.BoolProperty(update=update_properties_from_selected)

    def update_properties_from_selected(self, context):
        print("Updating properties from selected - 2")
        if context.scene.apply_properties_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.temperature = selected_spotlight["temperature"]
                context.scene.castShadow = selected_spotlight["castShadow"]
                context.scene.isBounced = selected_spotlight["isBounced"]
                context.scene.enable = selected_spotlight["enable"]
                context.scene.power = selected_spotlight.data.energy
                context.scene.new_spotlight_umbraAngle = math.degrees(selected_spotlight.data.spot_size)
                context.scene.new_spotlight_penumbraAngle = selected_spotlight.data.spot_blend
                context.scene.spotlight_color = selected_spotlight.data.color
                
    def update_location_from_selected(self, context):
        print("Updating location from selected - 2")
        if context.scene.apply_location_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.add_spotlight_location[0] = selected_spotlight.location.x
                context.scene.add_spotlight_location[1] = selected_spotlight.location.y
                context.scene.add_spotlight_location[2] = selected_spotlight.location.z

    def update_rotation_from_selected(self, context):
        print("Updating rotation from selected - 2")
        if context.scene.apply_rotation_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.add_spotlight_rotation[0] = selected_spotlight.rotation_quaternion[0]
                context.scene.add_spotlight_rotation[1] = selected_spotlight.rotation_quaternion[1]
                context.scene.add_spotlight_rotation[2] = selected_spotlight.rotation_quaternion[2]
                context.scene.add_spotlight_rotation[3] = selected_spotlight.rotation_quaternion[3]

    def invoke(self, context, event):
        # Run your update functions here
        self.update_properties_from_selected(context)
        self.update_location_from_selected(context)
        self.update_rotation_from_selected(context)

        # Invoke the dialog
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout

        # Display the input field for SpotID
        layout.prop(context.scene, "spot_id_input")

        # Separator
        layout.separator()

        # Checkbox to apply properties from selected SpotLight
        layout.prop(context.scene, "apply_properties_from_selected", text="Apply properties from currently selected SpotLight", toggle=False)

        # Additional properties for the new SpotLight
        self.custom_prop(layout, context.scene, "temperature", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "castShadow", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "isBounced", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "enable", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "power", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "new_spotlight_umbraAngle", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "new_spotlight_penumbraAngle", not context.scene.update_properties_checked)
        
        # Color property
        self.custom_prop(layout, context.scene, "spotlight_color", text="Color", enable=not context.scene.update_color_checked)

        # Separator
        layout.separator()

        # Text labels for location
        layout.label(text="Location:")
        layout.prop(context.scene, "apply_location_from_selected", text="Apply location from currently selected SpotLight", toggle=False)
        self.custom_prop(layout, context.scene, "add_spotlight_location", index=0, text="X", enable=not context.scene.update_location_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_location", index=1, text="Y", enable=not context.scene.update_location_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_location", index=2, text="Z", enable=not context.scene.update_location_checked)

        # Separator
        layout.separator()

        # Text label for rotation
        layout.label(text="Rotation:")
        layout.prop(context.scene, "apply_rotation_from_selected", text="Apply rotation from currently selected SpotLight", toggle=False)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=0, text="W", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=1, text="X", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=2, text="Y", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=3, text="Z", enable=not context.scene.update_rotation_checked)

    def custom_prop(self, layout, scene, prop_name, enable=True, **kwargs):
        row = layout.row()
        row.prop(scene, prop_name, **kwargs)
        if not enable:
            row.enabled = False

    def execute(self, context):
    
        # Check if the "Real Lights" collection exists, create it if not
        real_lights_collection = bpy.data.collections.get("Real Lights")
        if not real_lights_collection:
            real_lights_collection = bpy.data.collections.new("Real Lights")
            bpy.context.scene.collection.children.link(real_lights_collection)
            
        # Select the "Real Lights" collection
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["Real Lights"]

        # Use the user-input SpotID if available, otherwise use the incremented SpotID
        spot_id = context.scene.spot_id_input if context.scene.spot_id_input != 0 else context.scene.spot_id

        # Add SpotLight to the scene
        bpy.ops.object.light_add(
            type='SPOT',
            align='WORLD',
            location=(
                context.scene.add_spotlight_location[0],
                context.scene.add_spotlight_location[1],
                context.scene.add_spotlight_location[2]
            )
        )

        spot_light = bpy.context.active_object

        if spot_light:
            spot_light.name = f"EXT_Light_{spot_id:03}"

            # Set custom properties for the SpotLight
            spot_light["addr"] = 200000 + spot_id
            spot_light["castShadow"] = context.scene.castShadow
            spot_light["enable"] = context.scene.enable
            spot_light["isBounced"] = context.scene.isBounced
            spot_light["temperature"] = context.scene.temperature
            spot_light["transform"] = 201000 + spot_id
            
            # Convert radians to degrees
            umbra_angle_degrees = math.degrees(context.scene.new_spotlight_umbraAngle)
            penumbra_angle_degrees = math.degrees(context.scene.new_spotlight_penumbraAngle)

            # Set spot shape size (Spot Size) - convert from degrees to radians
            spot_light.data.spot_size = math.radians(context.scene.new_spotlight_umbraAngle)
            print("UmbraAngle:", context.scene.new_spotlight_umbraAngle)

            # Set spot blend using new_spotlight_penumbraAngle (converted to degrees)
            spot_light.data.spot_blend = context.scene.new_spotlight_penumbraAngle
            print("penUmbraAngle:", context.scene.new_spotlight_penumbraAngle)
            
            # Set power to the user-input value
            spot_light.data.energy = context.scene.power

            print("Before setting rotation:", context.scene.add_spotlight_rotation)

            # Set rotation values
            rotation_quaternion = (
                context.scene.add_spotlight_rotation[0],
                context.scene.add_spotlight_rotation[1],
                context.scene.add_spotlight_rotation[2],
                context.scene.add_spotlight_rotation[3]
            )

            # Set rotation mode to QUATERNION
            spot_light.rotation_mode = 'QUATERNION'

            # Assign the rotation directly
            spot_light.rotation_quaternion = rotation_quaternion

            print("After setting rotation:", spot_light.rotation_quaternion)
            print(f"Updating location from selected - 3                 Current Status: {context.scene.update_properties_checked}")
            print(f"Updating location from selected - 3                 Current Status: {context.scene.update_location_checked}")
            print(f"Updating location from selected - 3                 Current Status: {context.scene.update_rotation_checked}")

            # Assign color to the SpotLight
            color_values = context.scene.spotlight_color
            spot_light.data.color = color_values

            # Increment SpotID for the next SpotLight
            context.scene.spot_id_input += 1

            # Set value limits for custom properties
            spot_light["_RNA_UI"] = {
                "addr": {"min": 200000, "max": 200999},
                "castShadow": {"min": 0, "max": 1},
                "enable": {"min": 0, "max": 1},
                "isBounced": {"min": 0, "max": 1},
                "temperature": {"min": 1000, "max": 40000},
                "transform": {"min": 201000, "max": 201999},
            }

        return {'FINISHED'}

# Define the spotlight_properties property for the Scene type
bpy.types.Scene.spotlight_properties = bpy.props.PointerProperty(type=bpy.types.PropertyGroup)
        
# Define the spot_id property for the Scene type
bpy.types.Scene.spot_id = bpy.props.IntProperty()
        
class OBJECT_OT_IncrementSpotIDOperator(bpy.types.Operator):
    bl_idname = "object.increment_spotid"
    bl_label = "Increment SpotID"

    def execute(self, context):
        if context.scene.spot_id_input_enabled:
            context.scene.spot_id_input += 1
        else:
            context.scene.spot_id += 1
        return {'FINISHED'}

class OBJECT_OT_DecrementSpotIDOperator(bpy.types.Operator):
    bl_idname = "object.decrement_spotid"
    bl_label = "Decrement SpotID"

    def execute(self, context):
        if context.scene.spot_id_input_enabled:
            context.scene.spot_id_input -= 1
        else:
            context.scene.spot_id -= 1
        return {'FINISHED'}

def load_icon(icon_name, directory):
    global icons_collection

    # Check if the collection is not initialized
    if icons_collection is None:
        icons_collection = bpy.utils.previews.new()

    # Load the icon and return its icon ID
    icon_path = os.path.join(directory, f"{icon_name}.png")

    # Load the icon and store its icon ID
    icons_collection.load(icon_name, icon_path, 'IMAGE')
    return icons_collection.get(icon_name)

# Register the operators
classes = (
    OBJECT_OT_OpenToolsOperator,
    OBJECT_OT_Function1Operator,
    OBJECT_OT_Function2Operator,
    OBJECT_OT_Function3Operator,
    OBJECT_OT_ChangeSpotlightOperator,
    OBJECT_OT_Function2ExecuteOperator,
    OBJECT_OT_Function3ExecuteOperator,
    OBJECT_OT_Function4Operator,
    OBJECT_OT_Function4ExecuteOperator,
    OBJECT_OT_AddWavingFlagAOperator,
    OBJECT_OT_AddWavingFlagCOperator,
    OBJECT_OT_AddWavingFlagDOperator,
    OBJECT_OT_AddTreeA0Operator,
    OBJECT_OT_AddTreeB0Operator,
    CustomPathOperator,
)

def menu_func(self, context):
    self.layout.operator(OBJECT_OT_OpenToolsOperator.bl_idname)
    layout = self.layout
    layout.operator("object.change_spotlight")

def register():
    global icons_collection
    
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)

    bpy.utils.register_class(SpotlightValuePropertyGroup)
    bpy.utils.register_class(OBJECT_OT_my_operator)
    bpy.utils.register_class(OBJECT_OT_upload_xml)
    bpy.utils.register_class(OBJECT_OT_save_xml)
    bpy.utils.register_class(OBJECT_OT_AddSpotlightOperator)
    bpy.utils.register_class(OBJECT_OT_IncrementSpotIDOperator)
    bpy.utils.register_class(OBJECT_OT_DecrementSpotIDOperator)
    bpy.utils.register_class(SCENE_PT_spotlight_analyzer_panel)
    bpy.utils.register_class(OBJECT_OT_RevertXMLOperator)
    
    bpy.types.Scene.objectaddfeature_filename = bpy.props.StringProperty(name="Selected Texture", default="")
    bpy.types.Scene.objectaddfeature_filepath = bpy.props.StringProperty(name="Selected Texture Path", default="")

    bpy.types.Scene.update_properties_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.update_location_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.update_rotation_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.update_color_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.apply_properties_from_selected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.apply_location_from_selected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.apply_rotation_from_selected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.spot_id_input_enabled = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.uploaded_xml_directory = bpy.props.StringProperty(name="Uploaded XML Directory", subtype='DIR_PATH')
    bpy.types.Scene.uploaded_stadium_directory = bpy.props.StringProperty(name="Uploaded Stadium Directory", subtype='NONE')
    bpy.types.Scene.spotlight_values = bpy.props.CollectionProperty(type=SpotlightValuePropertyGroup)
    bpy.types.Scene.uploaded_xml_name = bpy.props.StringProperty(name="Uploaded XML Name")
    bpy.types.Scene.uploaded_fpkd_name = bpy.props.StringProperty()
    bpy.types.Scene.uploaded_fpkd_directory = bpy.props.StringProperty()
    bpy.types.Scene.spot_id_input = bpy.props.IntProperty(
        name="SpotID",
        default=0,
        min=0,
        max=999,
        description="Enter the desired SpotID",
    )
    
    # Define the Vector property for location
    bpy.types.Scene.add_spotlight_location = bpy.props.FloatVectorProperty(
        name="Location",
        subtype='TRANSLATION',
        size=3,  # 3 components for X, Y, Z
    )

    # Define the Quaternion property for rotation
    bpy.types.Scene.add_spotlight_rotation = bpy.props.FloatVectorProperty(
        name="Rotation",
        subtype='QUATERNION',
        size=4,  # 4 components for W, X, Y, Z
        default=(1.0, 0.0, 0.0, 0.0),  # Set initial values for W, X, Y, Z
    )
    
    # Temperature property
    bpy.types.Scene.temperature = bpy.props.IntProperty(
        name="Temperature",
        default=5000,
        min=1000,
        max=40000,
    )

    # Cast Shadow property
    bpy.types.Scene.castShadow = bpy.props.IntProperty(
        name="Cast Shadow",
        default=0,
        min=0,
        max=1,
    )

    # Bounce Lights property
    bpy.types.Scene.isBounced = bpy.props.IntProperty(
        name="Bounce Lights",
        default=0,
        min=0,
        max=1,
    )

    # Enabled property
    bpy.types.Scene.enable = bpy.props.IntProperty(
        name="Enabled",
        default=1,
        min=0,
        max=1,
    )

    # Power property
    bpy.types.Scene.power = bpy.props.FloatProperty(
        name="Power",
        default=4000,
        min=0,
        max=10000000,
    )

    # UmbraAngle property
    bpy.types.Scene.new_spotlight_umbraAngle = bpy.props.FloatProperty(
        name="Umbra Angle",
        default=100,
        min=1,
        max=180,
    )

    # penUmbraAngle property
    bpy.types.Scene.new_spotlight_penumbraAngle = bpy.props.FloatProperty(
        name="Penumbra Angle",
        default=0.5,
        min=0,
        max=1,
    )
    
    # Color property
    bpy.types.Scene.spotlight_color = bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,  # Three components for R, G, B
        default=(1.0, 1.0, 1.0),  # Default color is white
        min=0.0,  # Minimum value for R, G, B
        max=1.0,  # Maximum value for R, G, B
    )
    
    # IconValue For Manul :)
    bpy.types.Scene.custom_icon = bpy.props.IntProperty(
        name="Custom Icon",
        default=0,
        min=0,
        max=100,
        description="Custom icon value for the image box"
    )

    # Define the directory where your icons are stored
    directory = os.path.join(os.path.dirname(__file__), "resources-peslightmanager")

    # Initialize the previews collection
    icons_collection = bpy.utils.previews.new()

    # Load the custom icon and store its ID
    load_icon("titleimg", directory)
   
    bpy.types.Scene.update_properties_from_selected = bpy.props.BoolProperty(update=update_properties_from_selected)
    bpy.types.Scene.new_spotlight_umbraAngle = bpy.props.FloatProperty(name="UmbraAngle", default=67.5, min=1, max=180)
    bpy.types.Scene.new_spotlight_penumbraAngle = bpy.props.FloatProperty(name="penUmbraAngle", default=0.81, min=0, max=1)
    bpy.types.Scene.spotlight_properties = bpy.props.PointerProperty(type=bpy.types.PropertyGroup)
    bpy.utils.register_class(OBJECT_OT_ExportObjectsOperator)
    bpy.types.Scene.apply_properties_from_selected = bpy.props.BoolProperty(update=update_properties_from_selected)
    bpy.types.Scene.apply_location_from_selected = bpy.props.BoolProperty(update=update_location_from_selected)
    bpy.types.Scene.apply_rotation_from_selected = bpy.props.BoolProperty(update=update_rotation_from_selected)
    
    # Initialize mirror properties if they don't exist
    if "mirror_x" not in bpy.types.WindowManager.bl_rna.properties:
        bpy.types.WindowManager.mirror_x = bpy.props.BoolProperty(name="Mirror X", default=True)
    if "mirror_y" not in bpy.types.WindowManager.bl_rna.properties:
        bpy.types.WindowManager.mirror_y = bpy.props.BoolProperty(name="Mirror Y", default=False)
    
    bpy.types.Scene.active_tool_operator = bpy.props.StringProperty()
    bpy.utils.register_class(OBJECT_OT_ApplyPropertiesToSelectedOperator)
    
    bpy.utils.register_class(MySceneProperties)
    bpy.types.Scene.my_properties = bpy.props.PointerProperty(type=MySceneProperties)
    bpy.types.Scene.custom_export_path = bpy.props.StringProperty(name="Export Path")
    bpy.types.Scene.objectaddfeature_filename = bpy.props.StringProperty(name="Selected Texture", default="")
    bpy.types.Scene.objectaddfeature_filepath = bpy.props.StringProperty(name="Selected Texture Path", default="")
    bpy.types.Scene.addOBJ_tex_filename = bpy.props.StringProperty(name="Uploaded Texture Directory", subtype='DIR_PATH')
    bpy.types.Scene.addOBJ_tex_filepath = bpy.props.StringProperty(name="Export Path")
    bpy.types.Scene.addOBJ_label_text = bpy.props.StringProperty(default="Current Flag Texture Selected: None")

def unregister():
    global icons_collection
    
    bpy.utils.unregister_class(MySceneProperties)
    del bpy.types.Scene.my_properties
    
    bpy.utils.unregister_class(SpotlightValuePropertyGroup)
    bpy.utils.unregister_class(OBJECT_OT_my_operator)
    bpy.utils.unregister_class(OBJECT_OT_upload_xml)
    bpy.utils.unregister_class(OBJECT_OT_save_xml)
    bpy.utils.unregister_class(OBJECT_OT_AddSpotlightOperator)
    bpy.utils.unregister_class(OBJECT_OT_IncrementSpotIDOperator)
    bpy.utils.unregister_class(OBJECT_OT_ExportObjectsOperator)
    bpy.utils.unregister_class(OBJECT_OT_DecrementSpotIDOperator)
    bpy.utils.unregister_class(SCENE_PT_spotlight_analyzer_panel)
    bpy.utils.unregister_class(OBJECT_OT_RevertXMLOperator)
    del bpy.types.Scene.spotlight_values
    del bpy.types.Scene.uploaded_xml_name
    del bpy.types.Scene.spot_id_input
    del bpy.types.Scene.spotlight_properties
    del bpy.types.Scene.custom_icon
    del bpy.types.Scene.uploaded_fpkd_name
    del bpy.types.Scene.uploaded_fpkd_directory
    del bpy.types.Scene.active_tool_operator
    bpy.utils.previews.remove(icons_collection)
    bpy.utils.unregister_class(OBJECT_OT_ApplyPropertiesToSelectedOperator)
    
    del bpy.types.Scene.objectaddfeature_filename
    del bpy.types.Scene.objectaddfeature_filepath
    del bpy.types.Scene.addOBJ_tex_filename
    del bpy.types.Scene.addOBJ_tex_filepath
    
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()