bl_info = {
    "name": "PES Lightmanager for PES 2020 / 2021",
    "blender": (2, 80, 0),
    "category": "Scene",
}

import bpy
import math
import os
import shutil
import subprocess
from mathutils import Quaternion
from bpy_extras.io_utils import ImportHelper
from glob import glob

icons_collection = None

class SpotlightValuePropertyGroup(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(name="Object Name")
    addr: bpy.props.StringProperty(name="HEX Address")
    transform: bpy.props.StringProperty(name="HEX Address (transform)")
    color: bpy.props.StringProperty(name="Color")
    lumen: bpy.props.FloatProperty(name="Power (lumen)")
    umbraAngle: bpy.props.FloatProperty(name="Size (umbraAngle)")
    penumbraAngle: bpy.props.FloatProperty(name="Penumbra Angle")
    temperature: bpy.props.FloatProperty(name="Temperature")
    transform_translation: bpy.props.StringProperty(name="Transform Translation")
    transform_rotation_quat: bpy.props.StringProperty(name="Transform Rotation Quaternion")
    enabled: bpy.props.StringProperty(name="Enabled?")
    isBounced: bpy.props.StringProperty(name="Bounce Light?")
    castShadow: bpy.props.StringProperty(name="Cast Shadow?")
    show_details: bpy.props.BoolProperty(name="Show Details", default=False)

class OBJECT_OT_my_operator(bpy.types.Operator):
    bl_idname = "object.my_operator"
    bl_label = "Select SpotLights for Export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Clear previous spotlight values
        context.scene.spotlight_values.clear()

        # Initialize counters
        selected_spotlights_amount = 0
        total_spotlights_amount = 0

        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object is a spotlight
            if obj.type == 'LIGHT' and obj.data.type == 'SPOT':
                total_spotlights_amount += 1

                # Check if the spotlight is selected
                if obj.select_get():
                    selected_spotlights_amount += 1

                    # Check if the custom properties exist on the object
                    if all(prop in obj for prop in ["addr", "enable", "castShadow", "isBounced", "transform"]):
                        # Access the custom property values
                        addr_value = obj["addr"]
                        enable_value = "true" if obj["enable"] == 1 else "false"
                        cast_shadow_value = "true" if obj["castShadow"] == 1 else "false"
                        is_bounced_value = "true" if obj["isBounced"] == 1 else "false"
                        temperature_value = obj["temperature"]
                        transform_value = obj["transform"]

                    # Get the RGB color values
                    color = obj.data.color
                    r_value, g_value, b_value = [round(channel, 5) for channel in color[:3]]
                    color_value = f'<value r=\"{r_value}\" g=\"{g_value}\" b=\"{b_value}\" a=\"1\" />'

                    # Get the Power (lumen)
                    lumen_value = obj.data.energy
                    lumen_value = lumen_value * 50

                    # Get the Size (umbraAngle) and Blend value from light data
                    light_data = obj.data
                    umbra_angle_value = round(math.degrees(light_data.spot_size))
                    blend_value = light_data.spot_blend
                    blend_value = round(1.0 - blend_value, 3)

                    # Calculate penumbraAngle
                    penumbra_angle_value = round(umbra_angle_value * blend_value)

                    # Extract translation and rotation components from the transform matrix
                    transform_translation = obj.matrix_world.translation
                    transform_rotation = obj.matrix_world.to_quaternion()

                    # Round the rotation components
                    transform_rotation_w = round(transform_rotation.w, 5)
                    transform_rotation_x = round(transform_rotation.x, 5)
                    transform_rotation_y = round(transform_rotation.y, 5)
                    transform_rotation_z = round(transform_rotation.z, 5)

                    # Round the translation components
                    transform_translation_x = round(transform_translation.x, 5)
                    transform_translation_y = round(transform_translation.y, 5)
                    transform_translation_z = round(transform_translation.z, 5)

                    # Switch X, Y, Z, W for rotation
                    transform_rotation_formatted = f'<value x="{transform_rotation_x}" y="{transform_rotation_z}" z="{-transform_rotation_y}" w="{transform_rotation_w}" />'

                    # Switch X, Y, Z for translation
                    transform_translation_formatted = f'<value x="{transform_translation_x}" y="{transform_translation_z}" z="{-transform_translation_y}" w="0" />'

                    # Print the values alongside the object name
                    print(f"Object: '{obj.name}'")
                    print(f"addr: 0x00{addr_value}, transform: 0x00{transform_value}, enable: {enable_value}, castShadow: {cast_shadow_value}, isBounced: {is_bounced_value}")
                    print(f"Color: <value r=\"{r_value}\" g=\"{g_value}\" b=\"{b_value}\" a=\"1\" />")
                    print(f"Power (lumen): {lumen_value}")
                    print(f"Size (umbraAngle): {umbra_angle_value}")
                    print(f"Penumbra Angle: {penumbra_angle_value}")
                    print(f"Temperature: {temperature_value}")
                    print(f"Transform Translation: {transform_translation_formatted}")
                    print(f"Transform Rotation Quaternion: {transform_rotation_formatted}")
                    print("---------------------------")

                    # Append individual values to the scene property list
                    spotlight_values_entry = context.scene.spotlight_values.add()
                    spotlight_values_entry.object_name = obj.name
                    spotlight_values_entry.addr = f'0x00{addr_value}'
                    spotlight_values_entry.transform = f'0x00{transform_value}'
                    spotlight_values_entry.transform_translation = transform_translation_formatted
                    spotlight_values_entry.transform_rotation_quat = transform_rotation_formatted
                    spotlight_values_entry.color = color_value
                    spotlight_values_entry.lumen = lumen_value
                    spotlight_values_entry.umbraAngle = umbra_angle_value
                    spotlight_values_entry.penumbraAngle = penumbra_angle_value
                    spotlight_values_entry.temperature = temperature_value
                    spotlight_values_entry.castShadow = cast_shadow_value
                    spotlight_values_entry.isBounced = is_bounced_value
                    spotlight_values_entry.enabled = enable_value
                else:
                    # Print a message if any of the custom properties are missing
                    print(f"Custom properties are missing on object '{obj.name}'.")
            else:
                # Print a message if the object is not a spotlight
                print(f"Object '{obj.name}' is not a spotlight.")
        
        # Get the selected objects in the active scene
        selected_objects = bpy.context.selected_objects

        # Check if all selected objects are Light objects
        all_lights = all(obj.type == 'LIGHT' for obj in selected_objects)

        if all_lights:
            selected_objects_count = len(selected_objects)
            
            if selected_objects_count == 1:
                self.report({'INFO'}, f"{selected_objects_count} Spotlight selected.")
            elif selected_objects_count > 1:
                self.report({'INFO'}, f"{selected_objects_count} Spotlights selected.")
            else:
                self.report({'INFO'}, "No Spotlights selected.")
        else:
            self.report({'ERROR'}, "Not all selected objects are lights. Please select only light objects.")
        
        bpy.types.Scene.selected_spotlights_amount = bpy.props.IntProperty()
        bpy.types.Scene.total_spotlights_amount = bpy.props.IntProperty()
        
        # Update the scene properties
        context.scene.selected_spotlights_amount = selected_spotlights_amount
        context.scene.total_spotlights_amount = total_spotlights_amount

        return {'FINISHED'}
        
# Function to run GzsTool.exe with the exported XML file path
def run_gzs_tool(xml_file_path):
    # Get the directory of the uploaded XML file
    xml_file_directory = os.path.dirname(xml_file_path)

    # Go back 7 directories from the XML file directory
    parent_directory = os.path.abspath(os.path.join(xml_file_directory, "..\\..\\..\\..\\..\\..\\.."))

    # Find all files ending with ".fpkd.xml" in the specified directory
    fpkd_files = glob(os.path.join(parent_directory, "*.fpkd.xml"))

    # Run GzsTool.exe with each found .fpkd.xml file
    gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")
    
    if os.path.exists(gzs_tool_path):
        for fpkd_file in fpkd_files:
            command2 = [gzs_tool_path, fpkd_file]
            subprocess.run(command2, check=True)
            print(f"GzsTool.exe executed for file: {fpkd_file}")
    else:
        print("GzsTool.exe not found. Make sure the path is correct.")

class OBJECT_OT_upload_xml(bpy.types.Operator, ImportHelper):
    bl_idname = "object.upload_xml"
    bl_label = "Upload .fpkd or .xml"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".xml; .fpkd"

    def execute(self, context):
        file_ext = os.path.splitext(self.filepath)[1].lower()

        if file_ext == '.xml':
            # Set the uploaded XML file name to a custom property
            context.scene.uploaded_xml_name = os.path.basename(self.filepath)

            # Set the directory property to the directory of the uploaded file
            context.scene.uploaded_xml_directory = os.path.dirname(self.filepath)

            self.report({'INFO'}, f"Uploaded XML: {self.filepath}")
        elif file_ext == '.fpkd':
            # Set the uploaded FPKD file name to a custom property
            context.scene.uploaded_fpkd_name = os.path.basename(self.filepath)

            # Set the directory property to the directory of the uploaded file
            context.scene.uploaded_fpkd_directory = os.path.dirname(self.filepath)

            # Extract using GzsTool.exe
            gzs_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "Gzs", "GzsTool.exe")
            if os.path.exists(gzs_tool_path):
                # Run GzsTool.exe to extract the .fpkd file
                command = [gzs_tool_path, self.filepath]
                subprocess.run(command, check=True)
                self.report({'INFO'}, f"Extracted FPKD: {self.filepath}")

                # Get the directory where the FPKD was extracted
                extracted_folder = os.path.join(context.scene.uploaded_fpkd_directory, f"{context.scene.uploaded_fpkd_name.replace('.fpkd', '_fpkd')}")

                # Navigate to the 'Assets/pes16/model/bg' folder inside the extracted folder
                model_folder = os.path.join(extracted_folder, "Assets", "pes16", "model", "bg")

                # Find all subdirectories in the 'bg' folder
                subdirectories = [d for d in os.listdir(model_folder) if os.path.isdir(os.path.join(model_folder, d))]

                if subdirectories:
                    # Assuming there's only one subdirectory, navigate to it
                    subdirectory = subdirectories[0]
                    subdirectory_path = os.path.join(model_folder, subdirectory)

                    # Navigate to the 'light' folder inside the subdirectory
                    light_folder = os.path.join(subdirectory_path, "light")

                    # Find all .fox2 files in the 'light' folder
                    fox2_files = [f for f in os.listdir(light_folder) if f.lower().endswith('.fox2')]

                    if len(fox2_files) == 1:
                        # Run FoxTool.exe to convert .fox2 to .xml
                        fox_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "FoxTool", "FoxTool.exe")
                        if os.path.exists(fox_tool_path):
                            fox2_file_path = os.path.join(light_folder, fox2_files[0])
                            command = [fox_tool_path, fox2_file_path]
                            subprocess.run(command, check=True)

                            # Set the uploaded XML file name and directory
                            # Set the uploaded XML file name by appending ".xml" to the found .fox2 file name
                            context.scene.uploaded_xml_name = os.path.splitext(fox2_files[0])[0] + ".fox2.xml"

                            # Set the directory property to the directory where the .fox2 file is located
                            context.scene.uploaded_xml_directory = light_folder

                            self.report({'INFO'}, f"Converted to XML: {fox2_file_path}")
                        else:
                            self.report({'ERROR'}, "FoxTool.exe not found. Make sure the path is correct.")
                    else:
                        self.report({'ERROR'}, "Expected exactly one .fox2 file in the 'light' folder.")
                else:
                    self.report({'ERROR'}, "No subdirectories found in 'model/bg'.")
            else:
                self.report({'ERROR'}, "GzsTool.exe not found. Make sure the path is correct.")

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
        
class OBJECT_OT_save_xml(bpy.types.Operator):
    bl_idname = "object.save_xml"
    bl_label = "Export Lights"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Enable the button only when there is an uploaded XML file
        return getattr(context.scene, 'uploaded_xml_name', None) is not None

    def execute(self, context):
    
        # Check if there is an uploaded XML
        if getattr(context.scene, 'uploaded_xml_name', None):
            # Construct the full file path
            file_path = os.path.join(context.scene.uploaded_xml_directory, context.scene.uploaded_xml_name)

            # Load the XML content
            with open(file_path, 'r') as file:
                xml_content = file.readlines()

            # Check if the XML already contains the specified key
            if any('key="EXT_Light_' in line for line in xml_content):
                self.report({'ERROR'}, "This file already has converted lights. Please click on revert and try exporting again.")
                return {'CANCELLED'}
                
            xml_file_name = context.scene.uploaded_xml_name  # Replace with the actual XML file name
            xml_file_path = os.path.join(context.scene.uploaded_xml_directory, xml_file_name)

            # Create a backup before editing
            self.create_backup(context, xml_file_path)

            # Find the line number where the "dataList" property starts
            try:
                start_data_list = next(i for i, line in enumerate(xml_content) if '<property name="dataList"' in line) + 1
            except StopIteration:
                self.report({'ERROR'}, "Could not find the specified line in the XML file. (IN DATALIST)")
                return {'CANCELLED'}

            # Find the line number where the "dataList" property ends
            try:
                end_data_list = xml_content.index('        </property>\n', start_data_list)
            except ValueError:
                self.report({'ERROR'}, "Could not find the specified line in the XML file.")
                return {'CANCELLED'}

            # Insert the initial line before the "dataList" property
            xml_content.insert(start_data_list, '          <value key="ExtraLights">0x00100000</value>\n')

            # Iterate through all spotlights in the scene
            for obj in bpy.context.scene.objects:
                # Check if the object is a spotlight with a name starting with "EXT_Light_"
                if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_"):
                    # Get the object name and address
                    object_name = obj.name
                    address = f'0x00{obj["addr"]}' if "addr" in obj else "UNKNOWN"

                    # Insert new lines after the last occurrence for each spotlight within "dataList" property
                    xml_content.insert(end_data_list, f'          <value key="{object_name}">{address}</value>\n')

            # Find the line number where "</fox>" starts
            start_fox = None
            for i, line in enumerate(xml_content):
                if line.strip().startswith('</fox>'):
                    start_fox = i
                    break

            if start_fox is None:
                # Print lines for debugging
                print("XML Content:")
                for i, line in enumerate(xml_content):
                    print(f"{i}: {line}")

                print("Could not find the specified line in the XML file. (FOX2-START)")
                self.report({'ERROR'}, "Could not find the specified line in the XML file. (FOX2-START)")
                return {'CANCELLED'}

            # Find the line number where "</fox>" ends
            end_fox = None
            for i, line in reversed(list(enumerate(xml_content))):
                if line.strip().startswith('</fox>'):
                    end_fox = i
                    break

            if end_fox is None:
                print("Could not find the specified line in the XML file. (FOX2-END)")
                self.report({'ERROR'}, "Could not find the specified line in the XML file. (FOX2-END)")
                return {'CANCELLED'}

            # Get the addresses of the spotlights
            spotlight_addresses = [f'0x00{obj["addr"]}' if "addr" in obj else "UNKNOWN" for obj in bpy.context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_")]

            # Insert the Locator Entity code two lines before "</fox>"
            xml_content.insert(end_fox - 1, '    <entity class="Locator" classVersion="0" addr="0x00100000" unknown1="320" unknown2="0">\n')
            xml_content.insert(end_fox, '      <staticProperties>\n')
            xml_content.insert(end_fox + 1, '        <property name="name" type="String" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 2, '          <value>ExtraLights</value>\n')
            xml_content.insert(end_fox + 3, '        </property>\n')
            xml_content.insert(end_fox + 4, '        <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 5, '          <value>0x00000100</value>\n')
            xml_content.insert(end_fox + 6, '        </property>\n')
            xml_content.insert(end_fox + 7, '        <property name="parent" type="EntityHandle" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 8, '          <value>0x00000000</value>\n')
            xml_content.insert(end_fox + 9, '        </property>\n')
            xml_content.insert(end_fox + 10, '        <property name="transform" type="EntityPtr" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 11, f'          <value>0x00100001</value>\n')
            xml_content.insert(end_fox + 12, '        </property>\n')
            xml_content.insert(end_fox + 13, '        <property name="shearTransform" type="EntityPtr" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 14, '          <value>0x00000000</value>\n')
            xml_content.insert(end_fox + 15, '        </property>\n')
            xml_content.insert(end_fox + 16, '        <property name="pivotTransform" type="EntityPtr" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 17, '''          <value>0x00000000</value>
        </property>\n''')
            xml_content.insert(end_fox + 18, f'        <property name="children" type="EntityHandle" container="List" arraySize="{len(spotlight_addresses) + 1}">\n')
            xml_content.insert(end_fox + 20, '        </property>\n')
            xml_content.insert(end_fox + 21, '        <property name="flags" type="uint32" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 22, '          <value>6</value>\n')
            xml_content.insert(end_fox + 23, '        </property>\n')
            xml_content.insert(end_fox + 24, '        <property name="size" type="float" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 25, '          <value>1</value>\n')
            xml_content.insert(end_fox + 26, '        </property>\n')
            xml_content.insert(end_fox + 27, '      </staticProperties>\n')
            xml_content.insert(end_fox + 28, '      <dynamicProperties />\n')
            xml_content.insert(end_fox + 29, '    </entity>\n')
            xml_content.insert(end_fox + 30, '    <entity class="TransformEntity" classVersion="0" addr="0x00100001" unknown1="96" unknown2="0">\n')
            xml_content.insert(end_fox + 31, '      <staticProperties>\n')
            xml_content.insert(end_fox + 32, '        <property name="owner" type="EntityHandle" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 33, '          <value>0x00100000</value>\n')
            xml_content.insert(end_fox + 34, '        </property>\n')
            xml_content.insert(end_fox + 35, '        <property name="transform_scale" type="Vector3" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 36, '          <value x="1" y="1" z="1" w="0" />\n')
            xml_content.insert(end_fox + 37, '        </property>\n')
            xml_content.insert(end_fox + 38, '        <property name="transform_rotation_quat" type="Quat" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 39, '          <value x="0" y="0" z="0" w="1" />\n')
            xml_content.insert(end_fox + 40, '        </property>\n')
            xml_content.insert(end_fox + 41, '        <property name="transform_translation" type="Vector3" container="StaticArray" arraySize="1">\n')
            xml_content.insert(end_fox + 42, '          <value x="0" y="0" z="0" w="0" />\n')
            xml_content.insert(end_fox + 43, '        </property>\n')
            xml_content.insert(end_fox + 44, '      </staticProperties>\n')
            xml_content.insert(end_fox + 45, '      <dynamicProperties />\n')
            xml_content.insert(end_fox + 46, '    </entity>\n')

            # Find the line number where the last </entity> ends
            try:
                end_entity = next(i for i, line in enumerate(reversed(xml_content)) if '</entity>' in line)
            except StopIteration:
                print("Could not find the specified line in the XML file.")
                self.report({'ERROR'}, "Could not find the specified line in the XML file.")
                return {'CANCELLED'}

            # Get the addresses of the spotlights
            spotlight_addresses = [f'0x00{obj["addr"]}' if "addr" in obj else "UNKNOWN" for obj in bpy.context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_")]

            # Remove the unwanted </entities> line
            xml_content.pop(end_fox + 19)

            # Insert the children values with correct indentation
            indentation = ' ' * 10  # Adjust the number of spaces based on your XML structure
            for address in spotlight_addresses:
                xml_content.insert(end_fox + 19, f'{indentation}<value>{address}</value>\n')
                
            # Count the SpotLights with the name "EXT_Light_"
            spotlight_amount = sum(1 for obj in bpy.context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT' and obj.name.startswith("EXT_Light_"))
            
            # Find the line number where the Locator Entity code ends
            end_locator_entity = start_fox + 47 + spotlight_amount # Assuming the Locator Entity code has 32 lines
            
            # Set the updated indentation to 4 spaces
            indentation = ' ' * 4
            print(f"Total: '{bpy.context.scene.spotlight_values}'.")
            
            # Find and remove </entities> and </fox> at the end of the XML document
            entities_index = None
            fox_index = None

            for i, line in enumerate(reversed(xml_content)):
                if '</entities>' in line:
                    entities_index = len(xml_content) - i - 1
                elif '</fox>' in line:
                    fox_index = len(xml_content) - i - 1

            # Remove </entities> and </fox> lines if found
            if entities_index is not None:
                del xml_content[entities_index]
            if fox_index is not None:
                del xml_content[fox_index]
            
            # Iterate through each spotlight value and insert the corresponding XML code
            for values in bpy.context.scene.spotlight_values:
                # XML code for SpotLight entity
                spot_light_xml = f'''{indentation}<entity class="SpotLight" classVersion="16" addr="{values.addr}" unknown1="560" unknown2="0">
{indentation}  <staticProperties>
{indentation}    <property name="name" type="String" container="StaticArray" arraySize="1">
{indentation}      <value>{values.object_name}</value>
{indentation}    </property>
{indentation}    <property name="dataSet" type="EntityHandle" container="StaticArray" arraySize="1">
{indentation}      <value>0x00000100</value>
{indentation}    </property>
{indentation}    <property name="parent" type="EntityHandle" container="StaticArray" arraySize="1">
{indentation}      <value>0x00100000</value>
{indentation}    </property>
{indentation}    <property name="transform" type="EntityPtr" container="StaticArray" arraySize="1">
{indentation}      <value>{values.transform}</value>
{indentation}    </property>
{indentation}    <property name="shearTransform" type="EntityPtr" container="StaticArray" arraySize="1">
{indentation}      <value>0x00000000</value>
{indentation}    </property>
{indentation}    <property name="pivotTransform" type="EntityPtr" container="StaticArray" arraySize="1">
{indentation}      <value>0x00000000</value>
{indentation}    </property>
{indentation}    <property name="children" type="EntityHandle" container="List" />
{indentation}    <property name="flags" type="uint32" container="StaticArray" arraySize="1">
{indentation}      <value>6</value>
{indentation}    </property>
{indentation}    <property name="lightArea" type="EntityLink" container="StaticArray" arraySize="1">
{indentation}      <value packagePathHash="0xB8A0BF169F98" archivePathHash="0xB8A0BF169F98" nameInArchiveHash="0xB8A0BF169F98">0x00000000</value>
{indentation}    </property>
{indentation}    <property name="enable" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>{values.enabled}</value>
{indentation}    </property>
{indentation}    <property name="lookAtPoint" type="EntityLink" container="StaticArray" arraySize="1">
{indentation}      <value packagePathHash="0xB8A0BF169F98" archivePathHash="0xB8A0BF169F98" nameInArchiveHash="0xB8A0BF169F98">0x00000000</value>
{indentation}    </property>
{indentation}    <property name="reachPoint" type="Vector3" container="StaticArray" arraySize="1">
{indentation}      <value x="0" y="-5" z="0" w="0" />
{indentation}    </property>
{indentation}    <property name="innerRange" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>5</value>
{indentation}    </property>
{indentation}    <property name="outerRange" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>70</value>
{indentation}    </property>
{indentation}    <property name="color" type="Color" container="StaticArray" arraySize="1">
          {values.color}
{indentation}    </property>
{indentation}    <property name="temperature" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.temperature}</value>
{indentation}    </property>
{indentation}    <property name="colorDeflection" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0.01</value>
{indentation}    </property>
{indentation}    <property name="lumen" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.lumen}</value>
{indentation}    </property>
{indentation}    <property name="lightSize" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>20</value>
{indentation}    </property>
{indentation}    <property name="umbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.umbraAngle}</value>
{indentation}    </property>
{indentation}    <property name="penumbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>{values.penumbraAngle}</value>
{indentation}    </property>
{indentation}    <property name="attenuationExponent" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>1.2</value>
{indentation}    </property>
{indentation}    <property name="shadowUmbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>120</value>
{indentation}    </property>
{indentation}    <property name="shadowPenumbraAngle" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>120</value>
{indentation}    </property>
{indentation}    <property name="shadowAttenuationExponent" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>1.2</value>
{indentation}    </property>
{indentation}    <property name="dimmer" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="shadowBias" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="viewBias" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>-25</value>
{indentation}    </property>
{indentation}    <property name="powerScale" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>4</value>
{indentation}    </property>
{indentation}    <property name="LodFarSize" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="LodNearSize" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="LodShadowDrawRate" type="float" container="StaticArray" arraySize="1">
{indentation}      <value>1</value>
{indentation}    </property>
{indentation}    <property name="lodRadiusLevel" type="int32" container="StaticArray" arraySize="1">
{indentation}      <value>7</value>
{indentation}    </property>
{indentation}    <property name="lodFadeType" type="uint8" container="StaticArray" arraySize="1">
{indentation}      <value>0</value>
{indentation}    </property>
{indentation}    <property name="castShadow" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>{values.castShadow}</value>
{indentation}    </property>
{indentation}    <property name="isBounced" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>{values.isBounced}</value>
{indentation}    </property>
{indentation}    <property name="showObject" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>true</value>
{indentation}    </property>
{indentation}    <property name="showRange" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>true</value>
{indentation}    </property>
{indentation}    <property name="isDebugLightVolumeBound" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>false</value>
{indentation}    </property>
{indentation}    <property name="useAutoDimmer" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>false</value>
{indentation}    </property>
{indentation}    <property name="hasSpecular" type="bool" container="StaticArray" arraySize="1">
{indentation}      <value>false</value>
{indentation}    </property>
{indentation}  </staticProperties>
{indentation}  <dynamicProperties />
{indentation}</entity>
{indentation}<entity class="TransformEntity" classVersion="0" addr="{values.transform}" unknown1="96" unknown2="0">
{indentation}  <staticProperties>
{indentation}    <property name="owner" type="EntityHandle" container="StaticArray" arraySize="1">
{indentation}      <value>{values.addr}</value>
{indentation}    </property>
{indentation}    <property name="transform_scale" type="Vector3" container="StaticArray" arraySize="1">
{indentation}      <value x="1" y="1" z="1" w="0" />
{indentation}    </property>
{indentation}    <property name="transform_rotation_quat" type="Quat" container="StaticArray" arraySize="1">
          {values.transform_rotation_quat}
{indentation}    </property>
{indentation}    <property name="transform_translation" type="Vector3" container="StaticArray" arraySize="1">
          {values.transform_translation}
{indentation}    </property>
{indentation}  </staticProperties>
{indentation}  <dynamicProperties />
{indentation}</entity>
'''

                # Insert the spotlight XML code right after the Locator Entity
                xml_content.insert(end_locator_entity, spot_light_xml)
                
                # Update the end_locator_entity position for the next iteration
                end_locator_entity += 36  # Assuming the spotlight XML code has 36 lines
                
            # Append </entities> and </fox> back at the very end of the script
            xml_content.append('  </entities>\n')
            xml_content.append('</fox>')

            # Write the modified content back to the file
            with open(file_path, 'w') as file:
                file.writelines(xml_content)

            # Run FoxTool.exe with the exported XML file
            fox_tool_path = os.path.join(os.path.dirname(__file__), "resources-peslightmanager", "FoxTool", "FoxTool.exe")
            if os.path.exists(fox_tool_path):
                xml_file_path = bpy.path.abspath(file_path)
                command = [
                    fox_tool_path,
                    xml_file_path
                ]

                subprocess.run(command, check=True)
                self.report({'INFO'}, f"Saved XML: {xml_file_name}, Converted to FPKD (Ready to use ingame)")
                # Run GzsTool.exe with the exported XML file path
                run_gzs_tool(xml_file_path)
            else:
                self.report({'ERROR'}, "FoxTool.exe not found. Make sure the path is correct.")

        return {'FINISHED'}
        
    def create_backup(self, context, xml_file_path):
    
        xml_file_name = context.scene.uploaded_xml_name  # Replace with the actual XML file name
        xml_file_path = os.path.join(context.scene.uploaded_xml_directory, xml_file_name)
    
        backup_path = bpy.path.abspath(os.path.join(context.scene.uploaded_xml_directory, "backup"))
        print(f"Saving Backup at: {backup_path}")
        os.makedirs(backup_path, exist_ok=True)

        # Backup the XML file
        shutil.copy(xml_file_path, os.path.join(backup_path, f"{xml_file_name}_backup.xml"))
        print("Backup created successfully.")
        
class OBJECT_OT_RevertXMLOperator(bpy.types.Operator):
    bl_idname = "object.revert_xml_operator"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}  # Include in toolbar and make it square

    def execute(self, context):
        # Get the path to the XML file
        xml_file_name = context.scene.uploaded_xml_name  # Replace with the actual XML file name
        xml_file_path = os.path.join(context.scene.uploaded_xml_directory, xml_file_name)

        # Get the path to the backup XML file
        backup_path = bpy.path.abspath(os.path.join(context.scene.uploaded_xml_directory, "backup"))
        backup_file_path = os.path.join(backup_path, f"{xml_file_name}_backup.xml")

        # Revert the XML file from the backup
        shutil.copy(backup_file_path, xml_file_path)
        
        self.report({'INFO'}, f"Revert successful: {xml_file_name}")

        return {'FINISHED'}
        
    def draw(self, context):
        layout = self.layout
        layout.operator("object.revert_xml_operator", icon='FILE_REFRESH')

class OBJECT_OT_CustomImageOperator(bpy.types.Operator):
    bl_idname = "object.custom_image_operator"
    bl_label = "Custom Image Operator"
    
    def execute(self, context):
        # This function is called when the operator is executed
        return {'FINISHED'}

    def draw(self, context):
        # This function is responsible for drawing the UI elements for the operator
        layout = self.layout
        custom_icon = icons_collection.get("titleimg")

        if custom_icon:
            layout.image(custom_icon.icon_id, icon_value=custom_icon.icon_id, size=(400, 200))  # Adjust size as needed
        else:
            layout.label(text="Icon not found")

class SCENE_PT_spotlight_analyzer_panel(bpy.types.Panel):
    bl_label = "PES Lightmanager for PES 2020 / 2021"
    bl_idname = "PT_lightmanager_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout

        # Use the loaded icon if it exists
        custom_icon = icons_collection.get("titleimg")
        if custom_icon:
            # Create a row to center-align the box
            row = layout.row(align=True)
            
            # Create a box for the icons within the row
            box = row.box()

            # Add a label with the icon
            box.label(text="PES Lightmanager (v. 0.1.6a)", icon_value=custom_icon.icon_id)
            box.label(text="- Made by DAV on evoweb.com -")
        else:
            layout.label(text="Icon not found")

        # Upload XML button
        layout.operator("object.upload_xml")

        # Display the uploaded XML file name
        layout.label(text=f"Uploaded XML: {getattr(context.scene, 'uploaded_xml_name', 'None')}")

        # Create a horizontal row
        row = layout.row()

        # Export Button
        row.operator("object.save_xml", text="Export Lights")

        # Revert Button
        row.operator("object.revert_xml_operator", text="", icon='PLAY_REVERSE')

        # Display selected and total spotlight amounts
        layout.label(text=f"{context.scene.get('selected_spotlights_amount', 0)} / {context.scene.get('total_spotlights_amount', 0)} selected for Export")

        # Automatically populated "Export Path" field
        layout.prop(context.scene, "uploaded_xml_directory", text="Export Path:")
        
        layout.operator("object.add_spotlight")

        # Execute the spotlight script button
        layout.operator("object.my_operator")

        # Access the global list where your script stores the values
        spotlight_values = context.scene.spotlight_values

        if spotlight_values:
            # Display the analyzed spotlight values in a box
            box = layout.box()
            box.label(text="Spotlight Values:")

            # Modify your draw function to include the show_details property
            for i, values in enumerate(spotlight_values):
                if i > 0:
                    # Add a separator after each group of values (except the first one)
                    box.separator()

                # Create a collapsible box for each spotlight
                sub_box = box.box()
                sub_box.label(text=f"Object: {values.object_name}", icon='OUTLINER_OB_LIGHT')

                # Create a separate box for smaller font labels
                sub_sub_box = sub_box.box()
                sub_sub_box.scale_y = 0.5  # Adjust the scale to make the text smaller

                # Display details in the collapsible box with smaller font size
                sub_sub_box.label(text=f"HEX Address: {values.addr}")
                sub_sub_box.label(text=f"HEX Address (transform): {values.transform}")

                # Check if the box should be expanded or collapsed
                if values.show_details:
                    sub_box.prop(values, "show_details", icon='TRIA_DOWN', icon_only=True, emboss=False)

                    # Create a sub-column for smaller font size
                    sub_col = sub_box.column(align=True)
                    sub_col.label(text=f"Color: {values.color}")
                    sub_col.label(text=f"Power (lumen): {values.lumen}")
                    sub_col.label(text=f"Size (umbraAngle): {values.umbraAngle}")
                    sub_col.label(text=f"Penumbra Angle: {values.penumbraAngle}")
                    sub_col.label(text=f"Temperature: {values.temperature}")
                    sub_col.label(text=f"Transform Translation: {values.transform_translation}")
                    sub_col.label(text=f"Transform Rotation Quaternion: {values.transform_rotation_quat}")
                    sub_col.label(text=f"Cast Shadow?: {values.castShadow}")
                    sub_col.label(text=f"Bounce Lights?: {values.isBounced}")
                    sub_col.label(text=f"Enabled?: {values.enabled}")
                    
                else:
                    sub_box.prop(values, "show_details", icon='TRIA_RIGHT', icon_only=True, emboss=False)
                    continue  # Skip drawing details if not expanded
        else:
            layout.label(text="No spotlight values found.")

def update_properties_from_selected(self, context):
    # Toggle the boolean property
    if context.scene.update_properties_checked:
        context.scene.update_properties_checked = False
    else:
        context.scene.update_properties_checked = True
    print(f"Check For Properties on Selected Object: {context.scene.update_properties_checked}")
    if context.scene.apply_properties_from_selected:
        selected_spotlight = context.active_object
        if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
            context.scene.temperature = selected_spotlight["temperature"]
            context.scene.castShadow = selected_spotlight["castShadow"]
            context.scene.isBounced = selected_spotlight["isBounced"]
            context.scene.enable = selected_spotlight["enable"]
            context.scene.power = selected_spotlight.data.energy
            context.scene.new_spotlight_umbraAngle = math.degrees(selected_spotlight.data.spot_size)
            context.scene.new_spotlight_penumbraAngle = selected_spotlight.data.spot_blend
            context.scene.spotlight_color = selected_spotlight.data.color
            
def update_location_from_selected(self, context):
    # Toggle the boolean property
    if context.scene.update_location_checked:
        context.scene.update_location_checked = False
    else:
        context.scene.update_location_checked = True
    print(f"Check For Location on Selected Object: {context.scene.update_location_checked}")
    if context.scene.apply_location_from_selected:
        selected_spotlight = context.active_object
        if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
            context.scene.add_spotlight_location[0] = selected_spotlight.location.x
            context.scene.add_spotlight_location[1] = selected_spotlight.location.y
            context.scene.add_spotlight_location[2] = selected_spotlight.location.z

def update_rotation_from_selected(self, context):
    # Toggle the boolean property
    if context.scene.update_rotation_checked:
        context.scene.update_rotation_checked = False
    else:
        context.scene.update_rotation_checked = True
    print(f"Check For Rotation on Selected Object: {context.scene.update_rotation_checked}")
    if context.scene.apply_rotation_from_selected:
        selected_spotlight = context.active_object
        if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
            context.scene.add_spotlight_rotation[0] = selected_spotlight.rotation_quaternion[0]
            context.scene.add_spotlight_rotation[1] = selected_spotlight.rotation_quaternion[1]
            context.scene.add_spotlight_rotation[2] = selected_spotlight.rotation_quaternion[2]
            context.scene.add_spotlight_rotation[3] = selected_spotlight.rotation_quaternion[3]

class OBJECT_OT_AddSpotlightOperator(bpy.types.Operator):
    bl_idname = "object.add_spotlight"
    bl_label = "Add SpotLight"

    # Register the update function for the Scene type
    bpy.types.Scene.update_properties_from_selected = bpy.props.BoolProperty(update=update_properties_from_selected)

    def update_properties_from_selected(self, context):
        print("Updating properties from selected - 2")
        if context.scene.apply_properties_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.temperature = selected_spotlight["temperature"]
                context.scene.castShadow = selected_spotlight["castShadow"]
                context.scene.isBounced = selected_spotlight["isBounced"]
                context.scene.enable = selected_spotlight["enable"]
                context.scene.power = selected_spotlight.data.energy
                context.scene.new_spotlight_umbraAngle = math.degrees(selected_spotlight.data.spot_size)
                context.scene.new_spotlight_penumbraAngle = selected_spotlight.data.spot_blend
                context.scene.spotlight_color = selected_spotlight.data.color
                
    def update_location_from_selected(self, context):
        print("Updating location from selected - 2")
        if context.scene.apply_location_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.add_spotlight_location[0] = selected_spotlight.location.x
                context.scene.add_spotlight_location[1] = selected_spotlight.location.y
                context.scene.add_spotlight_location[2] = selected_spotlight.location.z

    def update_rotation_from_selected(self, context):
        print("Updating rotation from selected - 2")
        if context.scene.apply_rotation_from_selected:
            selected_spotlight = context.active_object
            if selected_spotlight and selected_spotlight.type == 'LIGHT' and selected_spotlight.data.type == 'SPOT':
                context.scene.add_spotlight_rotation[0] = selected_spotlight.rotation_quaternion[0]
                context.scene.add_spotlight_rotation[1] = selected_spotlight.rotation_quaternion[1]
                context.scene.add_spotlight_rotation[2] = selected_spotlight.rotation_quaternion[2]
                context.scene.add_spotlight_rotation[3] = selected_spotlight.rotation_quaternion[3]

    def invoke(self, context, event):
        # Run your update functions here
        self.update_properties_from_selected(context)
        self.update_location_from_selected(context)
        self.update_rotation_from_selected(context)

        # Invoke the dialog
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout

        # Display the input field for SpotID
        layout.prop(context.scene, "spot_id_input")

        # Separator
        layout.separator()

        # Checkbox to apply properties from selected SpotLight
        layout.prop(context.scene, "apply_properties_from_selected", text="Apply properties from currently selected SpotLight", toggle=False)

        # Additional properties for the new SpotLight
        self.custom_prop(layout, context.scene, "temperature", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "castShadow", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "isBounced", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "enable", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "power", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "new_spotlight_umbraAngle", not context.scene.update_properties_checked)
        self.custom_prop(layout, context.scene, "new_spotlight_penumbraAngle", not context.scene.update_properties_checked)
        
        # Color property
        self.custom_prop(layout, context.scene, "spotlight_color", text="Color", enable=not context.scene.update_color_checked)

        # Separator
        layout.separator()

        # Text labels for location
        layout.label(text="Location:")
        layout.prop(context.scene, "apply_location_from_selected", text="Apply location from currently selected SpotLight", toggle=False)
        self.custom_prop(layout, context.scene, "add_spotlight_location", index=0, text="X", enable=not context.scene.update_location_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_location", index=1, text="Y", enable=not context.scene.update_location_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_location", index=2, text="Z", enable=not context.scene.update_location_checked)

        # Separator
        layout.separator()

        # Text label for rotation
        layout.label(text="Rotation:")
        layout.prop(context.scene, "apply_rotation_from_selected", text="Apply rotation from currently selected SpotLight", toggle=False)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=0, text="W", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=1, text="X", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=2, text="Y", enable=not context.scene.update_rotation_checked)
        self.custom_prop(layout, context.scene, "add_spotlight_rotation", index=3, text="Z", enable=not context.scene.update_rotation_checked)

    def custom_prop(self, layout, scene, prop_name, enable=True, **kwargs):
        row = layout.row()
        row.prop(scene, prop_name, **kwargs)
        if not enable:
            row.enabled = False

    def execute(self, context):
    
        # Check if the "Real Lights" collection exists, create it if not
        real_lights_collection = bpy.data.collections.get("Real Lights")
        if not real_lights_collection:
            real_lights_collection = bpy.data.collections.new("Real Lights")
            bpy.context.scene.collection.children.link(real_lights_collection)
            
        # Select the "Real Lights" collection
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children["Real Lights"]

        # Use the user-input SpotID if available, otherwise use the incremented SpotID
        spot_id = context.scene.spot_id_input if context.scene.spot_id_input != 0 else context.scene.spot_id

        # Add SpotLight to the scene
        bpy.ops.object.light_add(
            type='SPOT',
            align='WORLD',
            location=(
                context.scene.add_spotlight_location[0],
                context.scene.add_spotlight_location[1],
                context.scene.add_spotlight_location[2]
            )
        )

        spot_light = bpy.context.active_object

        if spot_light:
            spot_light.name = f"EXT_Light_{spot_id:03}"

            # Set custom properties for the SpotLight
            spot_light["addr"] = 200000 + spot_id
            spot_light["castShadow"] = context.scene.castShadow
            spot_light["enable"] = context.scene.enable
            spot_light["isBounced"] = context.scene.isBounced
            spot_light["temperature"] = context.scene.temperature
            spot_light["transform"] = 201000 + spot_id
            
            # Convert radians to degrees
            umbra_angle_degrees = math.degrees(context.scene.new_spotlight_umbraAngle)
            penumbra_angle_degrees = math.degrees(context.scene.new_spotlight_penumbraAngle)

            # Set spot shape size (Spot Size) - convert from degrees to radians
            spot_light.data.spot_size = math.radians(context.scene.new_spotlight_umbraAngle)
            print("UmbraAngle:", context.scene.new_spotlight_umbraAngle)

            # Set spot blend using new_spotlight_penumbraAngle (converted to degrees)
            spot_light.data.spot_blend = context.scene.new_spotlight_penumbraAngle
            print("penUmbraAngle:", context.scene.new_spotlight_penumbraAngle)
            
            # Set power to the user-input value
            spot_light.data.energy = context.scene.power

            print("Before setting rotation:", context.scene.add_spotlight_rotation)

            # Set rotation values
            rotation_quaternion = (
                context.scene.add_spotlight_rotation[0],
                context.scene.add_spotlight_rotation[1],
                context.scene.add_spotlight_rotation[2],
                context.scene.add_spotlight_rotation[3]
            )

            # Set rotation mode to QUATERNION
            spot_light.rotation_mode = 'QUATERNION'

            # Assign the rotation directly
            spot_light.rotation_quaternion = rotation_quaternion

            print("After setting rotation:", spot_light.rotation_quaternion)
            print(f"Updating location from selected - 3                 Current Status: {context.scene.update_properties_checked}")
            print(f"Updating location from selected - 3                 Current Status: {context.scene.update_location_checked}")
            print(f"Updating location from selected - 3                 Current Status: {context.scene.update_rotation_checked}")

            # Assign color to the SpotLight
            color_values = context.scene.spotlight_color
            spot_light.data.color = color_values

            # Increment SpotID for the next SpotLight
            context.scene.spot_id_input += 1

            # Set value limits for custom properties
            spot_light["_RNA_UI"] = {
                "addr": {"min": 200000, "max": 200999},
                "castShadow": {"min": 0, "max": 1},
                "enable": {"min": 0, "max": 1},
                "isBounced": {"min": 0, "max": 1},
                "temperature": {"min": 1000, "max": 40000},
                "transform": {"min": 201000, "max": 201999},
            }

        return {'FINISHED'}

# Define the spotlight_properties property for the Scene type
bpy.types.Scene.spotlight_properties = bpy.props.PointerProperty(type=bpy.types.PropertyGroup)
        
# Define the spot_id property for the Scene type
bpy.types.Scene.spot_id = bpy.props.IntProperty()
        
class OBJECT_OT_IncrementSpotIDOperator(bpy.types.Operator):
    bl_idname = "object.increment_spotid"
    bl_label = "Increment SpotID"

    def execute(self, context):
        if context.scene.spot_id_input_enabled:
            context.scene.spot_id_input += 1
        else:
            context.scene.spot_id += 1
        return {'FINISHED'}

class OBJECT_OT_DecrementSpotIDOperator(bpy.types.Operator):
    bl_idname = "object.decrement_spotid"
    bl_label = "Decrement SpotID"

    def execute(self, context):
        if context.scene.spot_id_input_enabled:
            context.scene.spot_id_input -= 1
        else:
            context.scene.spot_id -= 1
        return {'FINISHED'}

def load_icon(icon_name, directory):
    global icons_collection

    # Check if the collection is not initialized
    if icons_collection is None:
        icons_collection = bpy.utils.previews.new()

    # Load the icon and return its icon ID
    icon_path = os.path.join(directory, f"{icon_name}.png")

    # Load the icon and store its icon ID
    icons_collection.load(icon_name, icon_path, 'IMAGE')
    return icons_collection.get(icon_name)

def register():
    global icons_collection
    
    bpy.utils.register_class(SpotlightValuePropertyGroup)
    bpy.utils.register_class(OBJECT_OT_my_operator)
    bpy.utils.register_class(OBJECT_OT_upload_xml)
    bpy.utils.register_class(OBJECT_OT_save_xml)
    bpy.utils.register_class(OBJECT_OT_AddSpotlightOperator)
    bpy.utils.register_class(OBJECT_OT_IncrementSpotIDOperator)
    bpy.utils.register_class(OBJECT_OT_DecrementSpotIDOperator)
    bpy.utils.register_class(SCENE_PT_spotlight_analyzer_panel)
    bpy.utils.register_class(OBJECT_OT_RevertXMLOperator)
    bpy.types.Scene.update_properties_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.update_location_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.update_rotation_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.update_color_checked = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.apply_properties_from_selected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.apply_location_from_selected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.apply_rotation_from_selected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.spot_id_input_enabled = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.uploaded_xml_directory = bpy.props.StringProperty(name="Uploaded XML Directory", subtype='DIR_PATH')
    bpy.types.Scene.spotlight_values = bpy.props.CollectionProperty(type=SpotlightValuePropertyGroup)
    bpy.types.Scene.uploaded_xml_name = bpy.props.StringProperty(name="Uploaded XML Name")
    bpy.types.Scene.uploaded_fpkd_name = bpy.props.StringProperty()
    bpy.types.Scene.uploaded_fpkd_directory = bpy.props.StringProperty()
    bpy.types.Scene.spot_id_input = bpy.props.IntProperty(
        name="SpotID",
        default=0,
        min=0,
        max=999,
        description="Enter the desired SpotID",
    )
    
    # Define the Vector property for location
    bpy.types.Scene.add_spotlight_location = bpy.props.FloatVectorProperty(
        name="Location",
        subtype='TRANSLATION',
        size=3,  # 3 components for X, Y, Z
    )

    # Define the Quaternion property for rotation
    bpy.types.Scene.add_spotlight_rotation = bpy.props.FloatVectorProperty(
        name="Rotation",
        subtype='QUATERNION',
        size=4,  # 4 components for W, X, Y, Z
        default=(1.0, 0.0, 0.0, 0.0),  # Set initial values for W, X, Y, Z
    )
    
    # Temperature property
    bpy.types.Scene.temperature = bpy.props.IntProperty(
        name="Temperature",
        default=5000,
        min=1000,
        max=40000,
    )

    # Cast Shadow property
    bpy.types.Scene.castShadow = bpy.props.IntProperty(
        name="Cast Shadow",
        default=1,
        min=0,
        max=1,
    )

    # Bounce Lights property
    bpy.types.Scene.isBounced = bpy.props.IntProperty(
        name="Bounce Lights",
        default=0,
        min=0,
        max=1,
    )

    # Enabled property
    bpy.types.Scene.enable = bpy.props.IntProperty(
        name="Enabled",
        default=1,
        min=0,
        max=1,
    )

    # Power property
    bpy.types.Scene.power = bpy.props.FloatProperty(
        name="Power",
        default=4000,
        min=0,
        max=10000000,
    )

    # UmbraAngle property
    bpy.types.Scene.new_spotlight_umbraAngle = bpy.props.FloatProperty(
        name="Umbra Angle",
        default=100,
        min=1,
        max=180,
    )

    # penUmbraAngle property
    bpy.types.Scene.new_spotlight_penumbraAngle = bpy.props.FloatProperty(
        name="Penumbra Angle",
        default=0.5,
        min=0,
        max=1,
    )
    
    # Color property
    bpy.types.Scene.spotlight_color = bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=3,  # Three components for R, G, B
        default=(1.0, 1.0, 1.0),  # Default color is white
        min=0.0,  # Minimum value for R, G, B
        max=1.0,  # Maximum value for R, G, B
    )
    
    # IconValue For Manul :)
    bpy.types.Scene.custom_icon = bpy.props.IntProperty(
        name="Custom Icon",
        default=0,
        min=0,
        max=100,
        description="Custom icon value for the image box"
    )

    # Define the directory where your icons are stored
    directory = os.path.join(os.path.dirname(__file__), "resources-peslightmanager")

    # Initialize the previews collection
    icons_collection = bpy.utils.previews.new()

    # Load the custom icon and store its ID
    load_icon("titleimg", directory)
   
    bpy.types.Scene.update_properties_from_selected = bpy.props.BoolProperty(update=update_properties_from_selected)
    bpy.types.Scene.new_spotlight_umbraAngle = bpy.props.FloatProperty(name="UmbraAngle", default=67.5, min=1, max=180)
    bpy.types.Scene.new_spotlight_penumbraAngle = bpy.props.FloatProperty(name="penUmbraAngle", default=0.81, min=0, max=1)
    bpy.types.Scene.spotlight_properties = bpy.props.PointerProperty(type=bpy.types.PropertyGroup)
    bpy.types.Scene.apply_properties_from_selected = bpy.props.BoolProperty(update=update_properties_from_selected)
    bpy.types.Scene.apply_location_from_selected = bpy.props.BoolProperty(update=update_location_from_selected)
    bpy.types.Scene.apply_rotation_from_selected = bpy.props.BoolProperty(update=update_rotation_from_selected)

def unregister():
    global icons_collection
    
    bpy.utils.unregister_class(SpotlightValuePropertyGroup)
    bpy.utils.unregister_class(OBJECT_OT_my_operator)
    bpy.utils.unregister_class(OBJECT_OT_upload_xml)
    bpy.utils.unregister_class(OBJECT_OT_save_xml)
    bpy.utils.unregister_class(OBJECT_OT_AddSpotlightOperator)
    bpy.utils.unregister_class(OBJECT_OT_IncrementSpotIDOperator)
    bpy.utils.unregister_class(OBJECT_OT_DecrementSpotIDOperator)
    bpy.utils.unregister_class(SCENE_PT_spotlight_analyzer_panel)
    bpy.utils.unregister_class(OBJECT_OT_RevertXMLOperator)
    del bpy.types.Scene.spotlight_values
    del bpy.types.Scene.uploaded_xml_name
    del bpy.types.Scene.spot_id_input
    del bpy.types.Scene.spotlight_properties
    del bpy.types.Scene.custom_icon
    del bpy.types.Scene.uploaded_fpkd_name
    del bpy.types.Scene.uploaded_fpkd_directory
    bpy.utils.previews.remove(icons_collection)

if __name__ == "__main__":
    register()